# AllInOne Emu

Emulator all-in-one untuk Android (GBA, Sega Genesis, SNES, Arcade) berbasis libretro.
Gratis, tanpa iklan, tanpa batasan.

- Core: mGBA, Genesis Plus GX, Snes9x, FBNeo (diunduh dari buildbot resmi libretro saat CI)
- ROM: dimuat dari folder milik pengguna. Aplikasi ini tidak menyertakan atau mengunduh ROM komersial.
- Lisensi core berbeda-beda (sebagian non-komersial): periksa sebelum mendistribusikan.

## Build
Push ke GitHub, lalu buka tab Actions > Build APK > unduh artifact `allinone-debug-apk`.

## Roadmap
- Kontrol layar sentuh
- Save state & pengaturan per sistem
- Katalog ROM legal (homebrew/domain publik) di dalam aplikasi
- Cover art & pencarian
