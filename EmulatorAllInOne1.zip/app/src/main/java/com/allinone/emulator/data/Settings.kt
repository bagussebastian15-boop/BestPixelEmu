package com.allinone.emulator.data

import android.content.Context
import com.swordfish.libretrodroid.ShaderConfig

class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var fastForward: Int
        get() = p.getInt("ff", 2)
        set(v) = p.edit().putInt("ff", v).apply()

    /** Hanya diterapkan pada core yang punya opsi frameskip (saat ini mGBA). */
    var frameSkip: Int
        get() = p.getInt("frameskip", 0)
        set(v) = p.edit().putInt("frameskip", v).apply()

    /** Profil performa game arcade: 0 = standar core, 1 = seimbang, 2 = maksimal. Berlaku saat game dimulai. */
    var arcadePerf: Int
        get() = p.getInt("arcadeperf", 1)
        set(v) = p.edit().putInt("arcadeperf", v).apply()

    /** Kecepatan CPU emulasi arcade (%). Di atas 100 = kurangi slowdown bawaan game, tapi lebih berat. */
    var arcadeCpu: Int
        get() = p.getInt("arcadecpu", 200)
        set(v) = p.edit().putInt("arcadecpu", v).apply()

    var skipDuplicateFrames: Boolean
        get() = p.getBoolean("skipdup", false)
        set(v) = p.edit().putBoolean("skipdup", v).apply()

    /**
     * Kunci layar ke 60 Hz saat bermain. Game berjalan ±57-60 fps; di layar 90/120 Hz LibretroDroid memakai pengatur waktu
     * sendiri (bukan vsync) sehingga durasi tiap frame tidak rata (patah-patah) walau FPS terbaca stabil.
     * Berlaku saat game dimulai.
     */
    var lock60Hz: Boolean
        get() = p.getBoolean("lock60hz", true)
        set(v) = p.edit().putBoolean("lock60hz", v).apply()

    /** Penghitung FPS di pojok layar game (diagnostik performa). */
    var showFps: Boolean
        get() = p.getBoolean("showfps", false)
        set(v) = p.edit().putBoolean("showfps", v).apply()

    var padOpacity: Int
        get() = p.getInt("padopacity", 60)
        set(v) = p.edit().putInt("padopacity", v).apply()

    /** Kontrol arah di layar: false = D-pad 8 arah (termasuk serong), true = stik analog. */
    var analogPad: Boolean
        get() = p.getBoolean("analogpad", false)
        set(v) = p.edit().putBoolean("analogpad", v).apply()

    var autoHidePad: Boolean
        get() = p.getBoolean("autohide", true)
        set(v) = p.edit().putBoolean("autohide", v).apply()

    /** Saat gamepad fisik terhubung: gambar game diregangkan memenuhi seluruh layar (rasio asli tidak dipertahankan). */
    var stretchWithPad: Boolean
        get() = p.getBoolean("stretchpad", true)
        set(v) = p.edit().putBoolean("stretchpad", v).apply()

    /** Latar bergambar (Bit©ade) untuk game arcade. Berlaku saat game dimulai. */
    var arcadeBg: Boolean
        get() = p.getBoolean("arcadebg", true)
        set(v) = p.edit().putBoolean("arcadebg", v).apply()

    /** Tombol kombo di panel arcade: satu sentuhan menekan beberapa tombol aksi (1-6) sekaligus. */
    var arcadeCombo: Boolean
        get() = p.getBoolean("arcadecombo", true)
        set(v) = p.edit().putBoolean("arcadecombo", v).apply()

    /** Isi kombo 1 dan 2: nomor tombol dipisah "+", mis. "4+5+6" (tiga pukulan) atau "1+2+3" (tiga tendangan). Kosong = tombol disembunyikan. */
    var arcadeCombo1: String
        get() = p.getString("arcadecombo1", "4+5+6") ?: ""
        set(v) = p.edit().putString("arcadecombo1", v).apply()

    var arcadeCombo2: String
        get() = p.getString("arcadecombo2", "1+2+3") ?: ""
        set(v) = p.edit().putString("arcadecombo2", v).apply()

    /** Tombol kombo di pad SNES: satu sentuhan menekan beberapa tombol (A B X Y L R) sekaligus. */
    var snesCombo: Boolean
        get() = p.getBoolean("snescombo", true)
        set(v) = p.edit().putBoolean("snescombo", v).apply()

    /** Isi kombo SNES, huruf dipisah "+", mis. "A+B". Kosong = tombol disembunyikan. */
    var snesCombo1: String
        get() = p.getString("snescombo1", "A+B") ?: ""
        set(v) = p.edit().putString("snescombo1", v).apply()

    var snesCombo2: String
        get() = p.getString("snescombo2", "X+Y") ?: ""
        set(v) = p.edit().putString("snescombo2", v).apply()

    var haptics: Boolean
        get() = p.getBoolean("haptics", true)
        set(v) = p.edit().putBoolean("haptics", v).apply()

    /** Bahasa teks game untuk terjemahan: auto, en, latin, ja, zh, ko. */
    var translateSource: String
        get() = p.getString("tr_src", "auto") ?: "auto"
        set(v) = p.edit().putString("tr_src", v).apply()

    /** true = hanya baca 45% layar bagian bawah (tempat kotak dialog biasanya berada). */
    var translateBottomOnly: Boolean
        get() = p.getBoolean("tr_bottom", false)
        set(v) = p.edit().putBoolean("tr_bottom", v).apply()

    /** Satu-satunya filter: bilinear halus (selalu aktif). */
    fun shaderConfig(): ShaderConfig = ShaderConfig.Default
}
