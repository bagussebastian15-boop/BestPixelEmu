# Emulator All-in-One (Android 5.0+)

Frontend emulator berbasis **libretro** + [LibretroDroid](https://github.com/Swordfish90/LibretroDroid).
Sistem: GBA (mGBA), SNES (Snes9x), Sega Genesis/Mega Drive (Genesis Plus GX),
Arcade (FBNeo dan MAME 2003-Plus). Gratis, tanpa iklan, ROM milik pengguna sendiri.

## Cara build

### Opsi A: GitHub Actions (tanpa install apa pun)
1. Push folder ini ke repo GitHub.
2. Tab **Actions** -> workflow **Build APK** jalan otomatis (atau *Run workflow*).
3. Unduh APK dari **Artifacts** (`EmulatorAllInOne-debug-apk`).

### Opsi B: Android Studio
1. Jalankan `bash scripts/fetch_cores.sh` (mengunduh core ke `app/src/main/jniLibs/`).
2. Buka folder ini di Android Studio -> Run.

## Fitur
| Fitur | Implementasi |
|---|---|
| Save/Load state | 5 slot + slot otomatis (disimpan saat pause/keluar); SRAM in-game disimpan terpisah |
| Controller map & plug n play | Deteksi gamepad otomatis, port pemain 1-4, peta tombol per perangkat, kontrol layar otomatis sembunyi saat gamepad terhubung |
| Upscaling & grafis | Skala layar penuh + filter bilinear halus (selalu aktif, tanpa shader lain) |
| API grafis | OpenGL ES 2.0+ (lihat catatan Vulkan) |
| Fast forward & frame skip | 2x/3x/4x/8x; frame skip (mGBA) + lewati frame duplikat |
| Cheat | Per game, tambah/aktif/hapus; format kode mengikuti core |
| Terjemahan dialog | Tombol 🌐 (atau R3 di gamepad, atau menu game -> Terjemahkan layar): layar ditangkap, dibaca OCR, lalu diterjemahkan ke Bahasa Indonesia. Lihat bagian "Terjemahan dialog" |
| Kontrol layar | Multi-touch; tata letak bisa digeser/diubah ukurannya (menu game -> Atur tata letak kontrol), tersimpan terpisah potret/lanskap; transparansi dan getar bisa diatur |

## Terjemahan dialog
- **Cara pakai**: ketuk 🌐 di pojok kanan atas saat dialog tampil. Game dijeda, panel terjemahan muncul di bawah.
  Ketuk **Teks asli** untuk melihat hasil OCR, **Baca ulang (teliti)** untuk mencoba semua varian gambar dan semua aksara, **Tutup** untuk lanjut main.
- **Mesin**: ML Kit on-device. OCR Latin, Jepang, Mandarin, Korea; deteksi bahasa; terjemahan ke Indonesia.
  Model terjemahan (±30 MB per bahasa) diunduh sekali saat pertama dipakai (butuh internet), setelah itu jalan offline.
- **Font retro/buram**: sebelum OCR, gambar dinormalkan ukurannya lalu dibuat 5 varian (warna asli, abu-abu + kontras, dipertajam,
  dibalik untuk teks terang di kotak gelap, hitam-putih Otsu). Hasil dengan skor kepercayaan tertinggi yang dipakai.
- **Pengaturan**: Bahasa teks game (Otomatis/Inggris/Latin lain/Jepang/Mandarin/Korea) dan Area baca (seluruh layar / 45% bawah).
  Memilih bahasa sumber secara spesifik lebih cepat dan lebih akurat daripada Otomatis.
- **Batas**: butuh Android 7.0+ (PixelCopy) untuk menangkap layar; font dekoratif sangat kecil/berlatar ramai tetap bisa salah baca;
  terjemahan on-device kurang halus dibanding layanan online.

## Catatan jujur (perlu dicek)
- Fitur terjemahan juga **belum di-build/diuji**. Versi dependensi ML Kit ada di `app/build.gradle.kts`; sesuaikan bila gagal resolve.
- **Belum di-build/diuji** di lingkungan pembuatan (tanpa Android SDK/jaringan). Jika ada error kompilasi,
  hampir pasti di nama API LibretroDroid yang berubah antarversi: ubah `libretroDroidVersion`
  di `app/build.gradle.kts` (lihat jitpack.io/#Swordfish90/LibretroDroid) dan sesuaikan
  `EmulatorActivity.kt` / `Settings.kt` (`ShaderConfig`, `setCheat`, `getGLRetroEvents`).
- **Vulkan** belum disertakan: hanya OpenGL ES. Perlu versi LibretroDroid yang mendukung Vulkan.
- **Upscaling**: core 2D punya resolusi internal tetap, jadi "upscale" = skala + shader, bukan render ulang.
- **Filter**: hanya bilinear halus (default LibretroDroid), selalu aktif.
- **Frame skip** per core: baru mGBA (`mgba_frameskip`). Core lain bisa ditambah di `EmulatorActivity.onCreate`.
- **Arcade** butuh set ROM yang cocok dengan versi core (FBNeo vs MAME 2003-Plus). Coba core lain lewat
  tekan-lama pada game. BIOS (mis. `neogeo.zip`) diimpor sebagai file zip biasa ke folder yang sama.
- **Lisensi core**: Snes9x, Genesis Plus GX, FBNeo, MAME 2003-Plus berlisensi non-komersial; aplikasi ini
  hanya boleh dibagikan gratis. Cek lisensi masing-masing core sebelum merilis.

## Struktur
```
app/src/main/java/com/allinone/emulator/
  data/   Console, Paths, RomLibrary, Settings, CheatStore
  input/  KeyMap, VirtualPadView
  ui/     LibraryActivity, EmulatorActivity, Menus
scripts/fetch_cores.sh        unduh core libretro
.github/workflows/build.yml   build APK otomatis
```
