# Emulator All-in-One (Android 5.0+)

Frontend emulator berbasis **libretro** + [LibretroDroid](https://github.com/Swordfish90/LibretroDroid).
Sistem: GBA (mGBA), SNES (Snes9x), Sega Genesis/Mega Drive (Genesis Plus GX),
Arcade (FBNeo dan MAME 2003-Plus). Gratis, tanpa iklan, ROM milik pengguna sendiri.

## Cara build

### Opsi A: GitHub Actions (tanpa install apa pun)
1. Push folder ini ke repo GitHub.
2. Tab **Actions** -> workflow **Build APK** jalan otomatis (atau *Run workflow*).
3. Unduh APK dari **Artifacts** (`EmulatorAllInOne-debug-apk`).

### Opsi B: Android Studio
1. Jalankan `bash scripts/fetch_cores.sh` (mengunduh core ke `app/src/main/jniLibs/`).
2. Buka folder ini di Android Studio -> Run.

## Fitur
| Fitur | Implementasi |
|---|---|
| Save/Load state | 5 slot + slot otomatis (disimpan saat pause/keluar); SRAM in-game disimpan terpisah |
| Controller map & plug n play | Deteksi gamepad otomatis, port pemain 1-4, peta tombol per perangkat, kontrol layar otomatis sembunyi saat gamepad terhubung |
| Upscaling & grafis | Skala layar penuh + filter bilinear halus (selalu aktif, tanpa shader lain) |
| API grafis | OpenGL ES 2.0+ (lihat catatan Vulkan) |
| Fast forward & frame skip | 2x/3x/4x/8x; frame skip (mGBA) + lewati frame duplikat |
| Cheat | Per game, tambah/aktif/hapus; format kode mengikuti core |
| Terjemahan dialog | Tombol 🌐 (atau R3 di gamepad, atau menu game -> Terjemahkan layar): layar ditangkap, dibaca OCR, lalu diterjemahkan ke Bahasa Indonesia dan ditimpa di atas teks game. Lihat bagian "Terjemahan dialog" |
| Kontrol layar | Multi-touch; tata letak bisa digeser/diubah ukurannya (menu game -> Atur tata letak kontrol), tersimpan terpisah potret/lanskap; transparansi dan getar bisa diatur |

## Terjemahan dialog
- **Cara pakai**: ketuk 🌐 di pojok kanan atas saat dialog tampil (atau R3 di gamepad, atau menu game -> Terjemahkan layar).
  Game dijeda dan terjemahan Indonesia **digambar langsung di atas teks asli** di layar game; tidak ada panel atau tombol tambahan di layar.
  Ketuk 🌐 lagi (atau tombol Kembali) untuk menutup dan melanjutkan game.
- **Teks asli / terjemahan**: saat terjemahan tampil, buka ☰ -> Pengaturan. Di bagian bawah daftar ada "Teks di layar: terjemahan/asli"
  (untuk bolak-balik) dan "Baca ulang terjemahan (mode teliti)" (coba semua varian gambar dan semua aksara). Pesan status berupa toast singkat.
- **Meniru gaya game**: kotak latar memakai warna latar teks asli, teks memakai warna teks asli, ukuran mengikuti tinggi baris asli
  (mengecil otomatis bila terjemahan lebih panjang), outline dipasang bila game memakainya, huruf besar semua bila game memakainya,
  tebal bila goresan huruf tebal. Pengaturan -> Gaya huruf: "ikuti game" atau "piksel" (eksperimental, huruf dirender kasar ala retro).
  Font asli game tidak bisa disalin persis; yang ditiru adalah warna, ukuran, outline, tebal, dan huruf besar/kecil.
- **Slang & idiom**: Inggris Amerika dan Britania (gonna, ain't, y'all, knackered, gutted, innit, bloody hell, piece of cake, dll.)
  diubah dulu ke Inggris baku sebelum diterjemahkan. Baris dialog yang berdekatan digabung jadi satu paragraf supaya konteks utuh.
  Teks HURUF BESAR semua diubah ke huruf biasa sebelum diterjemahkan (hasil lebih akurat). Nama pembicara seperti "CLOUD:" tidak diterjemahkan.
- **Kamus pribadi**: buat `slang_user.txt` di folder data aplikasi (Android/data/com.allinone.emulator/files/), satu aturan per baris:
  `slang=padanan baku`, mis. `gonna=going to` atau `the wyrm=the dragon`. Aturan pribadi didahulukan; baris berawalan `#` diabaikan.
- **Mesin**: ML Kit on-device (OCR Latin/Jepang/Mandarin/Korea, deteksi bahasa, terjemahan ke Indonesia).
  Model terjemahan (±30 MB per bahasa) diunduh sekali saat pertama dipakai (butuh internet), setelah itu offline.
- **Font retro/buram**: gambar dinormalkan lalu dibuat 5 varian (warna asli, abu-abu + kontras, dipertajam, dibalik, hitam-putih Otsu);
  hasil OCR dengan skor kepercayaan tertinggi yang dipakai.
- **Pengaturan**: Bahasa teks game, Area baca (seluruh layar / 45% bawah), Gaya huruf.
- **Batas**: butuh Android 7.0+ (PixelCopy); latar bergambar/gradasi membuat kotak penutup terlihat sebagai tambalan;
  terjemahan on-device bukan LLM, jadi slang di luar kamus bisa tetap salah; font dekoratif sangat kecil bisa salah baca.

## Catatan jujur (perlu dicek)
- Fitur terjemahan juga **belum di-build/diuji**. Versi dependensi ML Kit ada di `app/build.gradle.kts`; sesuaikan bila gagal resolve.
- **Belum di-build/diuji** di lingkungan pembuatan (tanpa Android SDK/jaringan). Jika ada error kompilasi,
  hampir pasti di nama API LibretroDroid yang berubah antarversi: ubah `libretroDroidVersion`
  di `app/build.gradle.kts` (lihat jitpack.io/#Swordfish90/LibretroDroid) dan sesuaikan
  `EmulatorActivity.kt` / `Settings.kt` (`ShaderConfig`, `setCheat`, `getGLRetroEvents`).
- **Vulkan** belum disertakan: hanya OpenGL ES. Perlu versi LibretroDroid yang mendukung Vulkan.
- **Upscaling**: core 2D punya resolusi internal tetap, jadi "upscale" = skala + shader, bukan render ulang.
- **Filter**: hanya bilinear halus (default LibretroDroid), selalu aktif.
- **Frame skip** per core: baru mGBA (`mgba_frameskip`). Core lain bisa ditambah di `EmulatorActivity.onCreate`.
- **Arcade** butuh set ROM yang cocok dengan versi core (FBNeo vs MAME 2003-Plus). Coba core lain lewat
  tekan-lama pada game. BIOS (mis. `neogeo.zip`) diimpor sebagai file zip biasa ke folder yang sama.
- **Lisensi core**: Snes9x, Genesis Plus GX, FBNeo, MAME 2003-Plus berlisensi non-komersial; aplikasi ini
  hanya boleh dibagikan gratis. Cek lisensi masing-masing core sebelum merilis.

## Struktur
```
app/src/main/java/com/allinone/emulator/
  data/   Console, Paths, RomLibrary, Settings, CheatStore
  input/  KeyMap, VirtualPadView
  ui/     LibraryActivity, EmulatorActivity, Menus
scripts/fetch_cores.sh        unduh core libretro
.github/workflows/build.yml   build APK otomatis
```
