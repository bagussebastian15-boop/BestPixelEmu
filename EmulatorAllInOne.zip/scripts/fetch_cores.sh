#!/usr/bin/env bash
# Mengunduh core libretro (build Android) dari buildbot resmi libretro
# ke app/src/main/jniLibs/<abi>/lib<core>_libretro_android.so
# Server libretro kadang memutus koneksi ("Connection reset by peer"), jadi tiap file dicoba ulang beberapa kali.
# Opsional: ABIS="arm64-v8a armeabi-v7a" bash scripts/fetch_cores.sh  (hanya ABI tertentu, lebih cepat)
set -euo pipefail

BASE="https://buildbot.libretro.com/nightly/android/latest"
CORES=(mgba snes9x genesis_plus_gx fbneo mame2003_plus)
if [ -n "${ABIS:-}" ]; then read -r -a ABI_LIST <<< "$ABIS"; else ABI_LIST=(armeabi-v7a arm64-v8a x86 x86_64); fi
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/jniLibs"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

download() {  # download <url> <output>
  local url="$1" out="$2" try
  for try in 1 2 3 4 5 6 7 8; do
    if curl -fsSL --http1.1 --connect-timeout 20 --max-time 180 \
         -A "Mozilla/5.0 (X11; Linux x86_64) fetch_cores" "$url" -o "$out"; then
      return 0
    fi
    echo "   gagal (percobaan $try/8), ulangi dalam $((try * 5)) detik..." >&2
    sleep $((try * 5))
  done
  return 1
}

for abi in "${ABI_LIST[@]}"; do
  mkdir -p "$DEST/$abi"
  for core in "${CORES[@]}"; do
    target="$DEST/$abi/lib${core}_libretro_android.so"
    if [ -s "$target" ]; then echo "-> sudah ada: $abi/$core"; continue; fi
    url="$BASE/$abi/${core}_libretro_android.so.zip"
    echo "-> $url"
    download "$url" "$TMP/$core.zip" || { echo "Gagal mengunduh $url" >&2; exit 1; }
    rm -rf "$TMP/x" && mkdir -p "$TMP/x"
    unzip -oq "$TMP/$core.zip" -d "$TMP/x"
    mv "$TMP/x/${core}_libretro_android.so" "$target"
    sleep 1
  done
done
echo "Selesai: core tersimpan di $DEST"
