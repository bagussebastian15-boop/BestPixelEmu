#!/usr/bin/env bash
# Mengunduh core libretro (build Android) dari buildbot resmi libretro
# ke app/src/main/jniLibs/<abi>/lib<core>_libretro_android.so
set -euo pipefail

BASE="https://buildbot.libretro.com/nightly/android/latest"
CORES=(mgba snes9x genesis_plus_gx fbneo mame2003_plus)
ABIS=(armeabi-v7a arm64-v8a x86 x86_64)
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/jniLibs"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

for abi in "${ABIS[@]}"; do
  mkdir -p "$DEST/$abi"
  for core in "${CORES[@]}"; do
    url="$BASE/$abi/${core}_libretro_android.so.zip"
    echo "-> $url"
    curl -fsSL "$url" -o "$TMP/$core.zip"
    rm -rf "$TMP/x" && mkdir -p "$TMP/x"
    unzip -oq "$TMP/$core.zip" -d "$TMP/x"
    mv "$TMP/x/${core}_libretro_android.so" "$DEST/$abi/lib${core}_libretro_android.so"
  done
done
echo "Selesai: core tersimpan di $DEST"
