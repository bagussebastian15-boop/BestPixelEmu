package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/**
 * Terjemahan online lewat Gemini API (opsional, API key milik pengguna).
 *
 * Mengapa lebih akurat daripada ML Kit: model bahasa besar memahami konteks dialog, slang, nama, dan nada bicara,
 * dan (mode teks + gambar) ikut MELIHAT tangkapan layar sehingga salah baca OCR pada font piksel dikoreksi sendiri.
 * Yang dikirim: teks hasil OCR (+ gambar layar bila mode 2). Tidak ada yang dikirim bila memakai mode offline.
 */
object CloudTranslator {

    /** Satu potongan teks hasil OCR beserta posisinya (persen layar) supaya model tahu bagian gambar yang dimaksud. */
    class Item(val id: Int, val text: String, val x: Int, val y: Int, val w: Int, val h: Int)

    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/"

    private const val SYSTEM = """You are a professional video-game localizer. Translate the dialogue/text of a retro game into natural Indonesian (Bahasa Indonesia).

Input: a numbered list of text snippets read by OCR from a screenshot of the game (the screenshot may be attached). OCR is imperfect: letters may be confused (O/0, I/l/1, rn/m), dropped, or merged, and ALL-CAPS pixel fonts are common. When the screenshot is attached, it is the SOURCE OF TRUTH: read the text yourself from the image, letter by letter, and use the OCR text only as a hint about which snippet is where. If the OCR text differs from what is visibly written, trust the image. Restore dropped letters and apostrophes (for example OCR 'M JUST' is really I'M JUST). Never invent words that are not on screen. Italic, wide-spaced pixel fonts are common, so read them carefully. Translate idioms by meaning, not word for word (an exclamation like 'Game over, man' expresses despair; it is not about 'manusia'). Then translate that intended text.

Rules:
- Return ONLY a JSON array of strings: exactly one translation per input item, same order, same length.
- Translate meaning and tone (slang, rudeness, politeness, humor, regional dialect), not word-for-word. Use natural, informal-but-clear Indonesian suited to game dialogue, unless the speaker is clearly formal.
- Keep character names, place names, item/skill/spell names, and speaker labels such as "CLOUD:" as in the original, unless the game has a well-known Indonesian name.
- Keep numbers, button names (A, B, START), HP/MP/EXP abbreviations, and placeholders like %s, {0}, [NAME] unchanged.
- Keep each translation about as short as the original so it fits the dialogue box. No notes, no explanations, no quotation marks added.
- If an item is not real text (noise, HUD numbers, a single symbol) or is already Indonesian, return it unchanged.
- Earlier lines of the same conversation and a glossary may be provided: stay consistent with them."""

    suspend fun translate(
        apiKey: String,
        model: String,
        gameTitle: String,
        items: List<Item>,
        history: List<Pair<String, String>>,
        glossary: String,
        screenshot: Bitmap?
    ): List<String> = withContext(Dispatchers.IO) {
        val prompt = StringBuilder()
        prompt.append("Game: ").append(gameTitle).append('\n')
        if (glossary.isNotBlank()) prompt.append("Glossary (term=meaning to respect):\n").append(glossary).append('\n')
        if (history.isNotEmpty()) {
            prompt.append("Previous lines (original => Indonesian), for consistency only, do not translate again:\n")
            for ((o, t) in history) prompt.append("- ").append(o).append(" => ").append(t).append('\n')
        }
        prompt.append("\nItems to translate (id, position on screen in % of width/height as x,y,w,h, OCR text):\n")
        for (it in items) {
            prompt.append("[").append(it.id).append("] (").append(it.x).append(',').append(it.y).append(',')
                .append(it.w).append(',').append(it.h).append(") ").append(it.text.replace('\n', ' ')).append('\n')
        }
        prompt.append("\nReturn a JSON array with ").append(items.size).append(" strings.")

        val parts = JSONArray().put(JSONObject().put("text", prompt.toString()))
        if (screenshot != null) {
            parts.put(JSONObject().put("inlineData", JSONObject()
                .put("mimeType", "image/jpeg")
                .put("data", jpegBase64(screenshot))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject()
                .put("temperature", 0.2)
                .put("responseMimeType", "application/json")
                .put("responseSchema", JSONObject()
                    .put("type", "ARRAY")
                    .put("items", JSONObject().put("type", "STRING"))))

        val conn = URL(ENDPOINT + model + ":generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 45_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)       // di header, bukan di URL
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException(describeError(code, text))
            parse(text, items.size)
        } finally {
            conn.disconnect()
        }
    }

    private fun describeError(code: Int, body: String): String {
        val msg = try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) { "" }
        return when (code) {
            400, 403 -> "API key / model ditolak ($code). ${msg.take(120)}"
            404 -> "Model tidak ditemukan. Ganti di Pengaturan → Model Gemini."
            429 -> "Kuota Gemini habis atau terlalu cepat (429). Coba lagi sebentar."
            else -> "Server Gemini error $code. ${msg.take(120)}"
        }
    }

    private fun parse(resp: String, expected: Int): List<String> {
        val root = JSONObject(resp)
        val cand = root.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw IllegalStateException("Gemini tidak mengembalikan hasil (mungkin diblokir filter konten).")
        val partArr = cand.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("Jawaban Gemini kosong.")
        val sb = StringBuilder()
        for (i in 0 until partArr.length()) sb.append(partArr.getJSONObject(i).optString("text"))
        var t = sb.toString().trim()
        if (t.startsWith("```")) t = t.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONArray(t)
        if (arr.length() != expected) {
            throw IllegalStateException("Jumlah hasil tidak cocok (${arr.length()} dari $expected).")
        }
        return List(expected) { arr.optString(it, "").trim() }
    }

    private fun jpegBase64(src: Bitmap): String {
        val side = max(src.width, src.height)
        val bmp = if (side > 1600) {
            val k = 1600f / side
            Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
        } else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
        if (bmp !== src) bmp.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
