package com.allinone.emulator.translate

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/** ScrollView dengan tinggi maksimum, supaya panel tidak menutupi seluruh layar game. */
class MaxHeightScrollView(ctx: Context, private val maxPx: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val limit = min(maxPx, MeasureSpec.getSize(heightMeasureSpec).takeIf { it > 0 } ?: maxPx)
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(limit, MeasureSpec.AT_MOST))
    }
}

class TranslationPanel(ctx: Context, maxBodyPx: Int) : LinearLayout(ctx) {

    var onClose: (() -> Unit)? = null
    var onRetry: (() -> Unit)? = null
    /** Dipakai pada mode "di atas teks game": true = tampilkan teks asli (sembunyikan terjemahan). */
    var onShowOriginal: ((Boolean) -> Unit)? = null
    /** true = hanya baris tombol (terjemahan digambar langsung di atas game). */
    var compact = false

    private val title = TextView(ctx)
    private val body = TextView(ctx)
    private lateinit var scroll: MaxHeightScrollView
    private val toggle = makeButton("Teks asli")
    private val retry = makeButton("Baca ulang (teliti)")
    private val close = makeButton("Tutup")
    private var result: TranslationEngine.Result? = null
    private var showingOriginal = false

    init {
        orientation = VERTICAL
        isClickable = true                      // sentuhan tidak tembus ke kontrol layar
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = GradientDrawable().apply {
            setColor(0xEE12141C.toInt())
            cornerRadius = dp(14).toFloat()
        }

        title.apply { textSize = 12f; setTextColor(0xFF9FB4FF.toInt()) }
        body.apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            setLineSpacing(0f, 1.15f)
            setTextIsSelectable(true)
        }
        scroll = MaxHeightScrollView(ctx, maxBodyPx).apply {
            addView(body)
            setPadding(0, dp(6), 0, dp(6))
        }
        val row = LinearLayout(ctx).apply {
            gravity = Gravity.END
            addView(toggle); addView(retry); addView(close)
        }
        addView(title); addView(scroll); addView(row)

        toggle.setOnClickListener {
            val r = result ?: return@setOnClickListener
            showingOriginal = !showingOriginal
            if (compact) {
                toggle.text = if (showingOriginal) "Terjemahan" else "Teks asli"
                onShowOriginal?.invoke(showingOriginal)
            } else render(r)
        }
        retry.setOnClickListener { onRetry?.invoke() }
        close.setOnClickListener { onClose?.invoke() }
        visibility = View.GONE
    }

    fun showLoading(msg: String) {
        result = null
        visibility = View.VISIBLE
        title.visibility = View.VISIBLE
        scroll.visibility = View.VISIBLE
        title.text = "🌐 Terjemahan"
        body.text = msg
        toggle.visibility = View.GONE
        retry.visibility = View.GONE
    }

    fun showError(msg: String) {
        result = null
        visibility = View.VISIBLE
        title.visibility = View.VISIBLE
        scroll.visibility = View.VISIBLE
        title.text = "🌐 Terjemahan"
        body.text = msg
        toggle.visibility = View.GONE
        retry.visibility = View.VISIBLE
    }

    fun showResult(r: TranslationEngine.Result) {
        result = r
        showingOriginal = false
        visibility = View.VISIBLE
        toggle.visibility = if (r.translated) View.VISIBLE else View.GONE
        retry.visibility = View.VISIBLE
        if (compact) {
            title.visibility = View.GONE
            scroll.visibility = View.GONE
            toggle.text = "Teks asli"
        } else {
            title.visibility = View.VISIBLE
            scroll.visibility = View.VISIBLE
            render(r)
        }
    }

    private fun render(r: TranslationEngine.Result) {
        title.text = if (r.translated) "🌐 ${r.sourceLabel} → Indonesia" else "🌐 Teks sudah berbahasa Indonesia"
        toggle.text = if (showingOriginal) "Terjemahan" else "Teks asli"
        body.text = r.blocks.joinToString("\n\n") { if (showingOriginal) it.original else it.translated }
    }

    private fun makeButton(label: String) = Button(context).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), dp(2), dp(10), dp(2))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
