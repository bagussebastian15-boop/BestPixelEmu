package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Mencari KOTAK DIALOG pada game apa pun, apa pun warna dan bentuknya:
 *  - balon putih bergaya komik berisi teks gelap (mis. Comix Zone),
 *  - kotak dialog solid berwarna apa saja (hitam, biru ala RPG, putih, krem, dll.) berisi teks yang kontras,
 *    termasuk kotak lebar di bawah layar yang menempel ke tepi (gaya Pokemon / Dragon Quest / Final Fantasy),
 *  - kotak dialog dengan latar GRADASI (biru tua -> biru muda ala Tales of Phantasia / Final Fantasy SNES), yang tidak
 *    bisa ditemukan lewat satu warna: dicari lewat penelusuran piksel bertetangga yang warnanya berubah pelan.
 * Tiap kotak dibaca OCR sendiri-sendiri pada potongan kecil yang bersih (jauh lebih akurat daripada membaca seluruh
 * layar yang penuh gambar) dan diterjemahkan SEBAGAI SATU BLOK, sehingga satu kotak dialog = satu terjemahan.
 */
object BubbleFinder {

    /** crop = area yang dibaca OCR, cover = area yang ditimpa terjemahan. Keduanya dalam piksel layar game. */
    class Region(val crop: Rect, val cover: Rect)

    private const val SMALL_W = 480
    private const val MAX_COLORS = 6          // jumlah warna dominan yang diperiksa sebagai calon warna kotak
    private const val COLOR_TOLERANCE = 48    // selisih warna (jumlah selisih R+G+B) yang masih dianggap warna kotak yang sama
    private const val TEXT_CONTRAST = 150     // selisih warna minimal agar sebuah piksel dianggap bagian teks/garis
    private const val SMOOTH_STEP = 12        // selisih warna antar piksel bertetangga yang masih dianggap "satu latar gradasi"

    private class Comp(val id: Int, val minX: Int, val maxX: Int, val minY: Int, val maxY: Int, val count: Int)

    fun find(frame: Bitmap): List<Region> {
        val scale = if (frame.width > SMALL_W) SMALL_W.toFloat() / frame.width else 1f
        val w = max(8, (frame.width * scale).toInt())
        val h = max(8, (frame.height * scale).toInt())
        val small = if (scale == 1f) frame else Bitmap.createScaledBitmap(frame, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== frame) small.recycle()

        val n = w * h
        val luma = IntArray(n)
        val bright = BooleanArray(n)
        val keyOf = IntArray(n)
        val keyCount = IntArray(512)
        for (i in 0 until n) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            luma[i] = (r * 299 + g * 587 + b * 114) / 1000
            bright[i] = luma[i] >= 205 && (max(r, max(g, b)) - min(r, min(g, b))) <= 40
            val k = ((r shr 5) shl 6) or ((g shr 5) shl 3) or (b shr 5)
            keyOf[i] = k
            keyCount[k]++
        }

        val found = ArrayList<Pair<Int, Region>>()

        // 1) Balon putih (komik): teks gelap di dalam area putih.
        found += scan(frame, scale, w, h, bright, { luma[it] < 90 }, 0.35f)

        // 2) Kotak solid berwarna apa saja: ambil beberapa warna paling dominan, lalu cari kotak berwarna itu yang
        //    berisi piksel kontras (teks) di dalamnya.
        val minCount = (n * 0.012f).toInt()
        val keys = (0 until 512).filter { keyCount[it] >= minCount }.sortedByDescending { keyCount[it] }.take(MAX_COLORS)
        for (k in keys) {
            var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0
            for (i in 0 until n) if (keyOf[i] == k) {
                val c = px[i]
                sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF; cnt++
            }
            if (cnt == 0) continue
            val mr = (sr / cnt).toInt(); val mg = (sg / cnt).toInt(); val mb = (sb / cnt).toInt()
            val mask = BooleanArray(n)
            for (i in 0 until n) {
                val c = px[i]
                mask[i] = abs(((c shr 16) and 0xFF) - mr) + abs(((c shr 8) and 0xFF) - mg) + abs((c and 0xFF) - mb) <= COLOR_TOLERANCE
            }
            found += scan(frame, scale, w, h, mask, {
                val c = px[it]
                abs(((c shr 16) and 0xFF) - mr) + abs(((c shr 8) and 0xFF) - mg) + abs((c and 0xFF) - mb) > TEXT_CONTRAST
            }, 0.55f)
        }

        // 3) Kotak dengan latar gradasi (warna berubah pelan dari atas ke bawah): satu warna saja tidak cukup.
        found += scanSmooth(frame, scale, w, h, px)

        // Buang kotak ganda (satu kotak bisa terdeteksi dua kali lewat cara berbeda): simpan yang terbesar.
        val kept = ArrayList<Pair<Int, Region>>()
        for (f in found.sortedByDescending { it.first }) {
            val r = f.second.cover
            val dup = kept.any { k ->
                val o = k.second.cover
                val ix = min(r.right, o.right) - max(r.left, o.left)
                val iy = min(r.bottom, o.bottom) - max(r.top, o.top)
                if (ix <= 0 || iy <= 0) false
                else {
                    val inter = ix.toFloat() * iy
                    val smaller = min(r.width().toFloat() * r.height(), o.width().toFloat() * o.height())
                    inter >= 0.6f * smaller
                }
            }
            if (!dup) kept += f
        }
        return kept.take(4).map { it.second }.sortedBy { it.cover.top }
    }

    /**
     * Cari kotak (komponen terhubung dari [mask]) yang berbentuk dialog: cukup besar, hampir persegi penuh,
     * dan berisi piksel kontras ([isText]) dalam jumlah wajar.
     */
    private fun scan(
        frame: Bitmap, scale: Float, w: Int, h: Int,
        mask: BooleanArray, isText: (Int) -> Boolean, minFill: Float
    ): List<Pair<Int, Region>> {
        val label = IntArray(w * h)
        val queue = IntArray(w * h)
        val comps = ArrayList<Comp>()
        var next = 0
        for (start in 0 until w * h) {
            if (!mask[start] || label[start] != 0) continue
            next++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = next
            var minX = w
            var maxX = 0
            var minY = h
            var maxY = 0
            var count = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                count++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && mask[p - 1] && label[p - 1] == 0) { label[p - 1] = next; queue[tail++] = p - 1 }
                if (x < w - 1 && mask[p + 1] && label[p + 1] == 0) { label[p + 1] = next; queue[tail++] = p + 1 }
                if (y > 0 && mask[p - w] && label[p - w] == 0) { label[p - w] = next; queue[tail++] = p - w }
                if (y < h - 1 && mask[p + w] && label[p + w] == 0) { label[p + w] = next; queue[tail++] = p + w }
            }
            if (count >= 200) comps += Comp(next, minX, maxX, minY, maxY, count)
        }

        val out = ArrayList<Pair<Int, Region>>()
        for (c in comps) {
            val bw = c.maxX - c.minX + 1
            val bh = c.maxY - c.minY + 1
            val area = bw * bh
            if (area < w * h * 0.012f || area > w * h * 0.40f) continue
            if (bw < w * 0.08f || bh < h * 0.04f) continue
            // Kotak dialog di bawah/atas layar boleh menempel ke tepi dan lebar penuh; yang ditolak hanya area tinggi
            // yang menempel ke tepi (margin/halaman komik, langit, latar).
            val touches = c.minX == 0 || c.minY == 0 || c.maxX == w - 1 || c.maxY == h - 1
            if (touches && bh > h * 0.5f) continue
            if (c.count.toFloat() / area < minFill) continue                 // bingkai berlubang, bukan kotak

            var ink = 0
            for (y in c.minY..c.maxY) {
                val row = y * w
                for (x in c.minX..c.maxX) if (isText(row + x)) ink++
            }
            val inkRatio = ink.toFloat() / area
            if (inkRatio < 0.04f || inkRatio > 0.45f) continue               // harus ada teks (kontras) di dalamnya

            makeRegion(frame, scale, w, label, c)?.let { out += area to it }
        }
        return out
    }

    /**
     * Badan kotak = baris-baris yang lebarnya mendekati maksimum (ekor balon dibuang), lalu diubah ke koordinat layar game.
     * [label] berisi nomor komponen tiap piksel; [c] komponen yang sudah lolos pemeriksaan bentuk.
     */
    private fun makeRegion(
        frame: Bitmap, scale: Float, w: Int, label: IntArray, c: Comp,
        cropInsetX: Float = 0.02f, cropInsetY: Float = 0.03f
    ): Region? {
        val bh = c.maxY - c.minY + 1
        val rowCount = IntArray(bh)
        for (y in c.minY..c.maxY) {
            val row = y * w
            for (x in c.minX..c.maxX) if (label[row + x] == c.id) rowCount[y - c.minY]++
        }
        val maxRow = rowCount.max()
        var y0 = -1
        var y1 = -1
        for (i in 0 until bh) if (rowCount[i] >= maxRow * 0.6f) { if (y0 < 0) y0 = i; y1 = i }
        if (y0 < 0) return null
        var x0 = w
        var x1 = 0
        for (y in (c.minY + y0)..(c.minY + y1)) {
            val row = y * w
            for (x in c.minX..c.maxX) if (label[row + x] == c.id) { if (x < x0) x0 = x; if (x > x1) x1 = x }
        }
        val bodyW = x1 - x0 + 1
        val bodyH = y1 - y0 + 1
        if (bodyW < 8 || bodyH < 5) return null
        val top = c.minY + y0

        fun rect(insetX: Float, insetY: Float): Rect {
            val l = (x0 + bodyW * insetX) / scale
            val t = (top + bodyH * insetY) / scale
            val r = (x1 + 1 - bodyW * insetX) / scale
            val b = (top + bodyH - bodyH * insetY) / scale
            val left = l.toInt().coerceIn(0, frame.width - 2)
            val tp = t.toInt().coerceIn(0, frame.height - 2)
            return Rect(
                left, tp,
                r.toInt().coerceIn(left + 1, frame.width),
                b.toInt().coerceIn(tp + 1, frame.height)
            )
        }
        return Region(rect(cropInsetX, cropInsetY), rect(maxOf(cropInsetX, 0.07f * cropInsetX / 0.02f), maxOf(cropInsetY, 0.09f * cropInsetY / 0.03f)))
    }

    private fun near(a: Int, b: Int): Boolean =
        abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)) + abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)) +
            abs((a and 0xFF) - (b and 0xFF)) <= SMOOTH_STEP

    /**
     * Kotak dialog dengan latar GRADASI. Piksel bertetangga yang warnanya hampir sama dihubungkan, jadi latar yang
     * berubah pelan (biru tua -> biru muda) tetap satu komponen, sedangkan huruf, bingkai kotak, dan gambar peta
     * yang ramai memutus/memecahnya. Teks = piksel yang jauh berbeda dari warna latar BARIS yang sama.
     */
    private fun scanSmooth(frame: Bitmap, scale: Float, w: Int, h: Int, px: IntArray): List<Pair<Int, Region>> {
        val n = w * h
        val label = IntArray(n)
        val queue = IntArray(n)
        val out = ArrayList<Pair<Int, Region>>()
        var next = 0
        for (start in 0 until n) {
            if (label[start] != 0) continue
            next++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = next
            var minX = w
            var maxX = 0
            var minY = h
            var maxY = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                val cp = px[p]
                if (x > 0 && label[p - 1] == 0 && near(cp, px[p - 1])) { label[p - 1] = next; queue[tail++] = p - 1 }
                if (x < w - 1 && label[p + 1] == 0 && near(cp, px[p + 1])) { label[p + 1] = next; queue[tail++] = p + 1 }
                if (y > 0 && label[p - w] == 0 && near(cp, px[p - w])) { label[p - w] = next; queue[tail++] = p - w }
                if (y < h - 1 && label[p + w] == 0 && near(cp, px[p + w])) { label[p + w] = next; queue[tail++] = p + w }
            }
            val count = tail
            if (count < 400) continue
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            val area = bw * bh
            if (area < w * h * 0.012f || area > w * h * 0.40f) continue
            if (bw < w * 0.25f || bh < h * 0.10f) continue             // kotak dialog gradasi: lebar dan tinggi layar yang wajar
            val touches = minX == 0 || minY == 0 || maxX == w - 1 || maxY == h - 1
            if (touches && bh > h * 0.5f) continue
            if (count.toFloat() / area < 0.6f) continue

            // Warna latar rata-rata tiap baris (hanya piksel komponen ini), lalu hitung piksel teks = jauh dari warna itu.
            val rr = IntArray(bh); val rg = IntArray(bh); val rb = IntArray(bh); val rn = IntArray(bh)
            for (y in minY..maxY) {
                val row = y * w
                for (x in minX..maxX) if (label[row + x] == next) {
                    val c = px[row + x]
                    rr[y - minY] += (c shr 16) and 0xFF; rg[y - minY] += (c shr 8) and 0xFF; rb[y - minY] += c and 0xFF; rn[y - minY]++
                }
            }
            var ink = 0
            for (y in minY..maxY) {
                val i = y - minY
                if (rn[i] == 0) continue
                val mr = rr[i] / rn[i]; val mg = rg[i] / rn[i]; val mb = rb[i] / rn[i]
                val row = y * w
                for (x in minX..maxX) {
                    val c = px[row + x]
                    if (abs(((c shr 16) and 0xFF) - mr) + abs(((c shr 8) and 0xFF) - mg) + abs((c and 0xFF) - mb) > TEXT_CONTRAST) ink++
                }
            }
            val inkRatio = ink.toFloat() / area
            if (inkRatio < 0.03f || inkRatio > 0.45f) continue              // harus ada teks (kontras) di dalamnya

            // Tepi komponen = bagian dalam bingkai kotak, jadi tidak perlu disisakan margin besar (huruf pertama sering menempel ke tepi).
            makeRegion(frame, scale, w, label, Comp(next, minX, maxX, minY, maxY, count), 0.004f, 0.01f)?.let { out += area to it }
        }
        return out
    }
}
