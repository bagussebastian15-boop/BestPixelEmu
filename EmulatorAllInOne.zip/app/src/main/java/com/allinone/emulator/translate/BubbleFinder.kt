package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * Mencari balon dialog bergaya komik (mis. Comix Zone): area putih yang cukup besar, dikelilingi garis hitam,
 * berisi teks gelap. Tiap balon dibaca OCR sendiri-sendiri pada potongan kecil yang bersih, jauh lebih akurat
 * daripada membaca seluruh layar yang penuh gambar.
 */
object BubbleFinder {

    /** crop = area yang dibaca OCR, cover = area yang ditimpa terjemahan. Keduanya dalam piksel layar game. */
    class Region(val crop: Rect, val cover: Rect)

    private const val SMALL_W = 480

    private class Comp(val id: Int, val minX: Int, val maxX: Int, val minY: Int, val maxY: Int, val count: Int)

    fun find(frame: Bitmap): List<Region> {
        val scale = if (frame.width > SMALL_W) SMALL_W.toFloat() / frame.width else 1f
        val w = max(8, (frame.width * scale).toInt())
        val h = max(8, (frame.height * scale).toInt())
        val small = if (scale == 1f) frame else Bitmap.createScaledBitmap(frame, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== frame) small.recycle()

        val luma = IntArray(w * h)
        val bright = BooleanArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            luma[i] = (r * 299 + g * 587 + b * 114) / 1000
            bright[i] = luma[i] >= 205 && (max(r, max(g, b)) - min(r, min(g, b))) <= 40
        }

        // Komponen terhubung dari piksel putih (flood fill dengan antrean).
        val label = IntArray(w * h)
        val queue = IntArray(w * h)
        val comps = ArrayList<Comp>()
        var next = 0
        for (start in 0 until w * h) {
            if (!bright[start] || label[start] != 0) continue
            next++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = next
            var minX = w
            var maxX = 0
            var minY = h
            var maxY = 0
            var count = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                count++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && bright[p - 1] && label[p - 1] == 0) { label[p - 1] = next; queue[tail++] = p - 1 }
                if (x < w - 1 && bright[p + 1] && label[p + 1] == 0) { label[p + 1] = next; queue[tail++] = p + 1 }
                if (y > 0 && bright[p - w] && label[p - w] == 0) { label[p - w] = next; queue[tail++] = p - w }
                if (y < h - 1 && bright[p + w] && label[p + w] == 0) { label[p + w] = next; queue[tail++] = p + w }
            }
            if (count >= 200) comps += Comp(next, minX, maxX, minY, maxY, count)
        }

        val found = ArrayList<Pair<Int, Region>>()
        for (c in comps) {
            val bw = c.maxX - c.minX + 1
            val bh = c.maxY - c.minY + 1
            val area = bw * bh
            if (area < w * h * 0.012f || area > w * h * 0.40f) continue
            if (bw < w * 0.08f || bh < h * 0.04f) continue
            val touches = c.minX == 0 || c.minY == 0 || c.maxX == w - 1 || c.maxY == h - 1
            if (touches && (bw > w * 0.5f || bh > h * 0.5f)) continue      // margin/halaman komik
            if (c.count.toFloat() / area < 0.35f) continue                 // bingkai berlubang, bukan balon

            var dark = 0
            for (y in c.minY..c.maxY) {
                val row = y * w
                for (x in c.minX..c.maxX) if (luma[row + x] < 90) dark++
            }
            val darkRatio = dark.toFloat() / area
            if (darkRatio < 0.04f || darkRatio > 0.45f) continue           // harus ada teks gelap di dalamnya

            // Badan balon = baris-baris yang lebarnya mendekati maksimum (ekor balon dibuang).
            val rowCount = IntArray(bh)
            for (y in c.minY..c.maxY) {
                val row = y * w
                for (x in c.minX..c.maxX) if (label[row + x] == c.id) rowCount[y - c.minY]++
            }
            val maxRow = rowCount.max()
            var y0 = -1
            var y1 = -1
            for (i in 0 until bh) if (rowCount[i] >= maxRow * 0.6f) { if (y0 < 0) y0 = i; y1 = i }
            if (y0 < 0) continue
            var x0 = w
            var x1 = 0
            for (y in (c.minY + y0)..(c.minY + y1)) {
                val row = y * w
                for (x in c.minX..c.maxX) if (label[row + x] == c.id) { if (x < x0) x0 = x; if (x > x1) x1 = x }
            }
            val bodyW = x1 - x0 + 1
            val bodyH = y1 - y0 + 1
            if (bodyW < 8 || bodyH < 5) continue
            val top = c.minY + y0

            fun rect(insetX: Float, insetY: Float): Rect {
                val l = (x0 + bodyW * insetX) / scale
                val t = (top + bodyH * insetY) / scale
                val r = (x1 + 1 - bodyW * insetX) / scale
                val b = (top + bodyH - bodyH * insetY) / scale
                val left = l.toInt().coerceIn(0, frame.width - 2)
                val tp = t.toInt().coerceIn(0, frame.height - 2)
                return Rect(
                    left, tp,
                    r.toInt().coerceIn(left + 1, frame.width),
                    b.toInt().coerceIn(tp + 1, frame.height)
                )
            }
            found += area to Region(rect(0.02f, 0.03f), rect(0.07f, 0.09f))
        }
        return found.sortedByDescending { it.first }.take(4)
            .map { it.second }
            .sortedBy { it.cover.top }
    }
}
