package com.allinone.emulator.translate

import java.io.File

/**
 * Penerjemah on-device sering salah pada slang. Solusinya: slang/idiom diubah dulu menjadi Inggris baku
 * (mis. "gonna" -> "going to", "knackered" -> "exhausted"), baru diterjemahkan ke Indonesia.
 *
 * Kamus pribadi: buat file slang_user.txt di folder data aplikasi (Android/data/com.allinone.emulator/files/),
 * satu aturan per baris dengan format  slang=padanan baku  (baris berawalan # diabaikan). Aturan pribadi didahulukan.
 */
object SlangNormalizer {

    private class Rule(val re: Regex, val rep: String)

    private val builtin: List<Rule> by lazy { parse(BUILTIN) }

    private var userCache: List<Rule> = emptyList()
    private var userStamp = -1L

    fun normalize(text: String, userFile: File?): String {
        var s = text.replace('’', '\'').replace('‘', '\'').replace('`', '\'').replace('´', '\'')
        // "goin'" -> "going", "nothin'" -> "nothing"
        s = Regex("\\b([A-Za-z]{2,})in'(?![A-Za-z])").replace(s) { it.groupValues[1] + "ing" }
        for (r in user(userFile)) s = apply(s, r)
        for (r in builtin) s = apply(s, r)
        return s
    }

    private fun apply(s: String, r: Rule): String = r.re.replace(s) { m ->
        val v = m.value
        if (v.isNotEmpty() && v[0].isUpperCase() && r.rep.isNotEmpty())
            r.rep.replaceFirstChar { it.uppercase() } else r.rep
    }

    private fun user(f: File?): List<Rule> {
        if (f == null || !f.exists()) return emptyList()
        val stamp = f.lastModified()
        if (stamp != userStamp) {
            userCache = try { parse(f.readText()) } catch (e: Exception) { emptyList() }
            userStamp = stamp
        }
        return userCache
    }

    private fun parse(src: String): List<Rule> =
        src.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
            .map { it.substringBefore('=').trim().lowercase() to it.substringAfter('=').trim() }
            .filter { it.first.isNotEmpty() }
            .sortedByDescending { it.first.length }          // frasa panjang dahulu
            .map { (k, v) ->
                Rule(Regex("(?<![A-Za-z'])" + Regex.escape(k) + "(?![A-Za-z'])", RegexOption.IGNORE_CASE), v)
            }
            .toList()

    private const val BUILTIN = """
# ---- kontraksi & ucapan lisan (AS) ----
gonna=going to
wanna=want to
gotta=have to
hafta=have to
gimme=give me
lemme=let me
dunno=don't know
kinda=kind of
sorta=sort of
outta=out of
lotta=lot of
lots of=many
whatcha=what are you
gotcha=understood
y'all=you all
you guys=you all
ya'll=you all
c'mon=come on
'cause=because
cuz=because
'til=until
'em=them
o'=of
tho=though
thru=through
nite=night
ya=you
yep=yes
yup=yes
yeah=yes
nope=no
nah=no
i ain't=I am not
you ain't=you are not
we ain't=we are not
they ain't=they are not
he ain't=he is not
she ain't=she is not
it ain't=it is not
ain't=is not
ain't it=isn't it
fixin' to=about to
fixing to=about to
# ---- slang Amerika ----
dude=my friend
bro=my friend
buddy=friend
pal=friend
gal=girl
kiddo=child
buck=dollar
bucks=dollars
cop=police officer
cops=police officers
legit=genuine
sketchy=suspicious
shady=suspicious
badass=tough
hella=very
freakin=very
freaking=very
freakin'=very
no biggie=it is not a big deal
my bad=my mistake
heads up=warning
hang out=spend time together
hanging out=spending time together
chill out=calm down
freak out=panic
freaking out=panicking
ticked off=angry
pissed off=very angry
screw up=make a mistake
screwed up=made a mistake
screwed=in trouble
busted=caught
bummer=too bad
crap=damn
darn=damn
dang=damn
gee=wow
golly=wow
whoa=wow
yikes=oh no
phew=what a relief
holy cow=wow
holy smoke=wow
holy moly=wow
howdy=hello
hiya=hello
g'day=hello
you bet=of course
for real=seriously
no way=impossible
what's up=how are you
wassup=how are you
sup=how are you
hang in there=be strong
hold your horses=wait a moment
take it easy=relax
give me a break=be reasonable
that sucks=that is terrible
sucks=is terrible
nailed it=did it perfectly
rip off=cheat
ripped off=cheated
beat it=go away
scram=go away
get lost=go away
shut up=be quiet
shut it=be quiet
loser=failure
jerk=bad person
creep=disgusting person
nuts=crazy
awesome=great
ma'am=madam
# ---- slang Britania ----
mate=friend
bloke=man
lad=boy
lass=girl
chap=man
old chap=my friend
guv=boss
guvnor=boss
bloody hell=damn it
bloody good=very good
bloody brilliant=very good
bloody idiot=complete idiot
sorted out=arranged
brilliant idea=excellent idea
blimey=wow
cor blimey=wow
crikey=wow
cheers=thank you
innit=isn't it
knackered=exhausted
gutted=devastated
chuffed=very pleased
daft=stupid
barmy=crazy
bonkers=crazy
quid=pounds
loo=toilet
lorry=truck
telly=television
fag=cigarette
crisps=potato chips
nicked=stole
bollocks=nonsense
rubbish=nonsense
sod off=go away
piss off=go away
bugger off=go away
bugger=damn
cheeky=impudent
reckon=think
ta-ra=goodbye
oi=hey
wanker=idiot
tosser=idiot
git=jerk
twit=fool
plonker=fool
skint=broke
cuppa=cup of tea
peckish=hungry
gobsmacked=astonished
dodgy=suspicious
naff=tacky
gaff=house
mum=mother
mummy=mother
fancy a=would you like a
jolly good=very good
jolly=very
cock up=mistake
cocked up=made a mistake
taking the mickey=making fun
take the mickey=make fun
bob's your uncle=and that is all
on the dole=unemployed
fortnight=two weeks
blighter=rascal
# ---- idiom umum ----
piece of cake=very easy
kick the bucket=die
kicked the bucket=died
break a leg=good luck
spill the beans=reveal the secret
spilled the beans=revealed the secret
under the weather=sick
an arm and a leg=a lot of money
hit the sack=go to sleep
hit the hay=go to sleep
call it a day=stop for today
let the cat out of the bag=reveal the secret
bite the bullet=endure it bravely
cut me some slack=be patient with me
cut some slack=be patient
once in a blue moon=very rarely
raining cats and dogs=raining heavily
the last straw=the final limit
throw in the towel=give up
pull someone's leg=joke with someone
pulling my leg=joking with me
it's a deal=agreed
fair enough=understood
fair dinkum=genuine
"""
}
