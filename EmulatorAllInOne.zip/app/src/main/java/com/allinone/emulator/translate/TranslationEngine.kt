package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.RectF
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Alur: layar game -> pra-pemrosesan (beberapa varian) -> OCR on-device (Latin/Jepang/Mandarin/Korea)
 * -> pilih hasil dengan skor kepercayaan terbaik -> baris digabung jadi paragraf dialog (dengan posisi di layar)
 * -> normalisasi slang -> terjemahan on-device ke Indonesia -> analisis gaya teks asli (warna, outline, dll).
 */
class TranslationEngine {

    companion object {
        /** Kunci pengaturan -> label. "en" memaksa bahasa Inggris (lebih akurat untuk dialog pendek). */
        val SOURCES = listOf(
            "auto" to "Otomatis (Latin, Jepang, Mandarin, Korea)",
            "en" to "Inggris (termasuk slang AS & Britania)",
            "latin" to "Latin lain (Spanyol, Prancis, Jerman, dll)",
            "ja" to "Jepang",
            "zh" to "Mandarin",
            "ko" to "Korea"
        )

        private const val GOOD_SCORE = 35f      // cukup bagus -> berhenti mencoba varian lain (mode cepat)
        private const val RETRY_BELOW = 15f     // di bawah ini -> coba pengenal aksara lain
        private const val MIN_SCORE = 4f        // di bawah ini -> dianggap tidak ada teks
        private const val BUBBLE_GOOD = 14f     // balon dialog: potongan kecil, cukup bagus lebih cepat tercapai
        private const val BUBBLE_RETRY = 6f
        private const val MIN_QUALITY = 0.4f    // di bawah ini teks OCR dianggap acak
        private const val MIN_COVERAGE = 0.9f   // bagian tinta gelap di balon yang harus sudah terbaca

        /** Singkatan umum game yang tidak boleh ikut menjadi huruf kecil saat teks HURUF BESAR dinormalkan. */
        private val ACRONYMS = setOf(
            "hp", "mp", "sp", "tp", "xp", "exp", "lv", "lvl", "atk", "def", "str", "agi", "int", "vit", "luk",
            "ok", "tv", "usa", "uk", "npc", "cpu", "pc", "id", "ii", "iii", "iv", "vi", "vii", "viii", "ix", "gba", "snes"
        )

        private val NAME_LINE = Regex("^\\p{Lu}[\\p{L}0-9 .'’-]{1,15}:?$")
        private val NAME_LABEL = Regex("^\\p{L}[\\p{L}0-9 .'-]{0,15}:$")
    }

    /** box = posisi di layar game (piksel view); null bila tidak perlu ditimpa (nama pembicara, angka, dll). */
    data class Block(
        val original: String, val translated: String, val box: RectF?, val style: TextStyle?,
        val fixed: Boolean = false,     // true = area terbatas (isi balon dialog), jangan diperluas
        val textBox: RectF? = null      // area teks asli di dalam kotak dialog (untuk margin dan lebar baris yang sama)
    )
    data class Result(
        val blocks: List<Block>, val sourceLabel: String, val translated: Boolean,
        val frameW: Int, val frameH: Int,
        val failed: Int = 0     // jumlah teks yang dilewati karena terbaca acak/terjemahan rusak
    )

    private class RawLine(val text: String, val rect: Rect)
    private class Scored(
        val lines: List<RawLine>, val score: Float, val script: String,
        val quality: Float = 1f, val coverage: Float = 1f
    ) {
        /** Skor akhir: jumlah huruf x kepercayaan, dikurangi bila teks mirip acak atau masih ada tinta yang belum terbaca. */
        val adj: Float get() = score * (0.3f + 0.7f * quality) * (0.35f + 0.65f * coverage)
        fun text(cjk: Boolean): String =
            lines.sortedBy { it.rect.top }.joinToString(if (cjk) "" else " ") { it.text }
    }
    private class Para(val lines: MutableList<RawLine>) {
        fun rect(): Rect {
            val r = Rect(lines[0].rect)
            for (l in lines) r.union(l.rect)
            return r
        }
    }

    private fun minScore(script: String) = if (script == "latin") MIN_SCORE else 0.3f   // dialog Jepang bisa hanya 2-3 huruf ("よし！")

    // Diagnostik: apa yang dibaca OCR saat gagal (ditampilkan di pesan "tidak ada teks")
    private var dbgCalls = 0
    private var dbgRaw = ""
    private var dbgScript = ""
    private var dbgFill = ""
    /** Hasil baca OCR terakhir (untuk diagnosis di Pengaturan > Terjemahan). */
    @Volatile var lastDebug = ""
    fun debugSummary(): String =
        if (dbgCalls == 0) "[v3 OCR tidak jalan]" else if (dbgRaw.isBlank()) "[v3 OCR ${dbgCalls}x: kosong]"
        else "[v3 OCR ${dbgScript}: \"${dbgRaw.replace('\n', ' ').take(12)}\"]"

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val japanese by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val chinese by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val korean by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val langId by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.3f).build())
    }
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>()

    /** true = HANYA Google Translate (online); false = HANYA ML Kit (offline). Tidak ada pindah otomatis. Diatur dari Pengaturan. */
    @Volatile var online = true
    @Volatile var jaGlossaryFile: File? = null
    private val onlineCache = HashMap<String, String>()

    /**
     * true = mode "Menu awal game": seluruh layar dibaca, tiap tulisan (Start, Option, Load, ...) diterjemahkan
     * sendiri-sendiri dan ditimpa di tempatnya. false = mode "Dialog" (balon/kotak dialog). Dua mode terpisah.
     */
    @Volatile var menuMode = false


    private fun recognizer(script: String): TextRecognizer = when (script) {
        "ja" -> japanese
        "zh" -> chinese
        "ko" -> korean
        else -> latin
    }

    /** Pasangan (aksara, jumlah varian gambar yang dicoba). */
    private fun plan(source: String, thorough: Boolean): List<Pair<String, Int>> {
        val n = FramePrep.VARIANT_COUNT
        return when (source) {
            "en", "latin" -> listOf("latin" to n)
            "ja" -> listOf("ja" to n)
            "zh" -> listOf("zh" to n)
            "ko" -> listOf("ko" to n)
            else -> if (thorough) listOf("latin" to n, "ja" to n, "zh" to n, "ko" to n)
            // Jepang dicoba dulu dengan 2 varian saja (hasil tanpa huruf Jepang dibuang, lihat readImage); bila bukan
            // teks Jepang, Latin tetap dibaca penuh seperti biasa.
            else listOf("ja" to 3, "latin" to n, "ja" to 6, "zh" to 4, "ko" to 4)
        }
    }

    /** Satu potongan teks (balon dialog atau paragraf) beserta posisinya di layar game. */
    private class Seg(
        val text: String, val box: RectF, val lineH: Float, val fixed: Boolean = false,
        val textBox: RectF? = null, val pitch: Float = 0f,
        val speaker: String? = null     // nama tokoh di atas dialog (mis. "Ledah"); tidak diterjemahkan, ditampilkan "Nama: kalimat"
    )
    private class Found(val segs: List<Seg>, val script: String)

    suspend fun run(
        frame: Bitmap,
        source: String,
        bottomOnly: Boolean,
        thorough: Boolean,
        glossary: File?,
        onStatus: suspend (String) -> Unit
    ): Result? {
        dbgCalls = 0; dbgRaw = ""; dbgScript = ""; dbgFill = ""
        // 1) Balon dialog bergaya komik dibaca satu per satu; 2) bila tidak ada, baca seluruh layar.
        val found = if (menuMode) readMenu(frame, source, thorough, onStatus) ?: return null
            else readBubbles(frame, source, thorough, onStatus)
                ?: readFullFrame(frame, source, bottomOnly, thorough, onStatus)
                // Kotak dialog di ATAS layar (mis. RPG Jepang SNES) hilang bila hanya 45% bawah yang dibaca: ulangi seluruh layar.
                ?: (if (bottomOnly) readFullFrame(frame, source, false, thorough, onStatus) else null)
                ?: return null
        val segs = found.segs

        // Tanpa isi dialog, menimpa NAMA saja membuat layar setengah Indonesia setengah Jepang. Lebih baik gagal jelas
        // (dan diagnosis terisi) daripada hasil setengah-setengah.
        // Hanya berlaku untuk KOTAK DIALOG (fixed): di sana teks pendek tanpa tanda baca memang sering hanya nama tokoh.
        // Judul/teks bebas di atas gambar ("まばゆくかがやく水晶") juga pendek tanpa tanda baca tetapi bukan nama: tetap diterjemahkan.
        if (found.script != "latin" && !menuMode && segs.all { it.fixed && it.speaker == null && looksNameOnlyText(it.text) }) {
            lastDebug = "Hanya nama tokoh yang terbaca, isi dialog tidak.\n" +
                "baca: " + segs.joinToString(" | ") { it.text } + "\nfill: " + dbgFill
            return null
        }

        val reads = segs.map { cleanup(it.text) }
        if (reads.all { it.isBlank() }) return null

        // Mode menu: tulisan menu yang ada di kamus langsung diberi padanan baku, tidak lewat penerjemah mesin.
        val menuHits: List<String?> =
            if (menuMode) reads.map { MenuGlossary.lookup(it, jaGlossaryFile) } else reads.map { null }
        val caps = reads.map { isAllCaps(it) }
        val speakers = segs.map { it.speaker?.let { n -> cleanup(n) }?.takeIf { n -> n.isNotBlank() } }

        // Nama pembicara ("CLOUD:"), angka, dan teks terlalu pendek tidak diterjemahkan/ditimpa.
        var failed = 0
        val skip = reads.indices.map { i ->
            if (menuHits[i] != null) return@map false       // tulisan menu yang dikenal selalu diterjemahkan
            val unreadable = found.script == "latin" && !TextQuality.isReadable(reads[i], false, MIN_QUALITY)
            if (unreadable) failed++
            unreadable || NAME_LABEL.matches(reads[i]) || reads[i].count { it.isLetter() } < (if (found.script == "latin") 2 else 1)
        }

        val prep = reads.indices.map { i -> if (caps[i]) sentenceCase(reads[i]) else reads[i] }
        val lang = detectLang(prep.joinToString("\n"), found.script, source)
        val label = Locale(lang).getDisplayLanguage(Locale("id")).replaceFirstChar { it.uppercase() }
        val prepared = when (lang) {
            "en" -> prep.map { SlangNormalizer.normalize(it, glossary) }
            "ja" -> prep.map { JaPrep.normalize(it, jaGlossaryFile) }
            else -> prep
        }
        val translatedTexts =
            if (lang == "id") prepared
            else {
                val idxs = reads.indices.filter { !skip[it] && menuHits[it] == null }
                val out = translate(idxs.map { prepared[it] }, lang, onStatus)
                val m = prepared.toMutableList()
                idxs.forEachIndexed { n, i ->
                    var t = out[n]
                    if (!TextQuality.isReadable(t, true, 0.5f)) {
                        // hasil terjemahan rusak: coba lagi dari teks asli tanpa normalisasi, bila masih rusak jangan ditimpa
                        val alt = translate(listOf(reads[i]), lang, onStatus).first()
                        if (TextQuality.isReadable(alt, true, 0.5f)) t = alt else { t = reads[i]; failed++ }
                    }
                    m[i] = t
                }
                for (i in reads.indices) menuHits[i]?.let { m[i] = it }
                m
            }

        // Nama tokoh pada teks Jepang/Mandarin/Korea (mis. "クレスの父ミゲール") ikut diterjemahkan; nama Latin dibiarkan apa adanya.
        val speakerShown: List<String?> =
            if (found.script != "latin" && lang != "id" && speakers.any { it != null }) {
                val idx = speakers.indices.filter { speakers[it] != null && !skip[it] }
                val srcNames = idx.map { if (lang == "ja") JaPrep.normalize(speakers[it]!!, jaGlossaryFile) else speakers[it]!! }
                val outNames = translate(srcNames, lang, onStatus)
                val m = speakers.toMutableList()
                idx.forEachIndexed { n, i -> outNames[n].trim().takeIf { t -> t.isNotEmpty() }?.let { t -> m[i] = t } }
                m
            } else speakers

        val blocks = withContext(Dispatchers.Default) {
            reads.indices.map { i ->
                var shown = translatedTexts[i]
                if (caps[i]) shown = shown.uppercase(Locale("id"))
                val same = shown.trim().equals(reads[i].trim(), ignoreCase = true)
                if (skip[i] || same || lang == "id") {
                    Block(reads[i], reads[i], null, null)
                } else {
                    // Nama tokoh digabung dengan dialog memakai titik dua (semua bahasa): "Cless: Ibu! ..."
                    speakerShown[i]?.let { shown = "$it: $shown" }
                    var st = StyleAnalyzer.analyze(frame, segs[i].box, segs[i].lineH, caps[i]).copy(linePitch = segs[i].pitch)
                    // Kotak dialog bergradasi (biru tua -> biru muda): tiru warna latar per baris supaya tidak jadi tambalan rata.
                    if (segs[i].fixed) st = st.copy(bgStops = StyleAnalyzer.gradient(frame, segs[i].box))
                    // Kotak teks asli dari OCR sering kurang lebar (huruf tepi/miring): perluas sampai ujung tinta teks.
                    val cover = if (segs[i].fixed) segs[i].box else StyleAnalyzer.grow(frame, segs[i].box, st)
                    Block(reads[i], shown, cover, st, segs[i].fixed, segs[i].textBox)
                }
            }
        }
        val dbgLines = StringBuilder("bahasa=$lang skrip=${found.script} gagal=$failed\n")
        for (i in reads.indices) {
            val state = if (blocks[i].box == null) "TIDAK DITIMPA" else "ditimpa"
            dbgLines.append("#").append(i).append(" baca: ").append(reads[i].take(60)).append("\n")
                .append("   hasil: ").append(translatedTexts[i].take(60)).append("\n")
                .append("   ").append(state).append("\n")
        }
        dbgLines.append("fill: ").append(dbgFill)
        lastDebug = dbgLines.toString()
        return Result(blocks, label, lang != "id", frame.width, frame.height, failed)
    }

    /** Baca tiap balon dialog pada potongan gambar yang bersih. */
    private suspend fun readBubbles(
        frame: Bitmap, source: String, thorough: Boolean, onStatus: suspend (String) -> Unit
    ): Found? {
        val regions = withContext(Dispatchers.Default) { BubbleFinder.find(frame) }
        if (regions.isEmpty()) return null
        val segs = ArrayList<Seg>()
        var script = "latin"
        for (r in regions) {
            val c = r.crop
            val crop = Bitmap.createBitmap(frame, c.left, c.top, c.width(), c.height())
            val prepped = withContext(Dispatchers.Default) { FramePrep.normalizeSize(crop) }
            try {
                val best = readImage(prepped, source, thorough, BUBBLE_GOOD, BUBBLE_RETRY, onStatus, checkCoverage = true) ?: continue
                if (best.lines.isEmpty() || best.score < minScore(best.script)) continue
                if (best.script == "latin" && best.quality < MIN_QUALITY) continue    // teks acak: jangan ditimpa
                val sc = prepped.width.toFloat() / crop.width
                val sorted = best.lines.sortedBy { it.rect.top }
                val cjk = best.script != "latin"
                // RPG Jepang: baris pertama = nama tokoh, baris berikutnya = dialog berkurung 「…」. Dipisah supaya
                // nama tidak ikut menjadi satu kalimat dengan dialog.
                val (speaker, bodyLines) = if (cjk) splitSpeakerCjk(sorted) else null to sorted
                val text = bodyLines.joinToString(if (cjk) "" else " ") { it.text }
                val lineH = sorted.map { it.rect.height() }.average().toFloat() / sc
                // Kotak = kotak dialog asli (persis), area teks = gabungan baris OCR; jarak baris asli diukur dari OCR.
                val tb = RectF(
                    c.left + sorted.minOf { it.rect.left } / sc, c.top + sorted.minOf { it.rect.top } / sc,
                    c.left + sorted.maxOf { it.rect.right } / sc, c.top + sorted.maxOf { it.rect.bottom } / sc
                )
                val pitch = if (sorted.size >= 2) (sorted.last().rect.top - sorted.first().rect.top) / (sorted.size - 1) / sc else 0f
                segs += Seg(text, RectF(r.crop), lineH, true, tb, pitch, speaker)
                script = best.script
            } finally {
                if (prepped !== crop && !prepped.isRecycled) prepped.recycle()
                if (!crop.isRecycled) crop.recycle()
            }
        }
        if (segs.isEmpty()) return null
        // Ada kotak dialog: hanya kotak yang benar-benar berisi KALIMAT dialog yang diterjemahkan. Kotak lain berisi
        // label pendek (HUD, "TIME", angka, nama menu) diabaikan. Bila tidak ada yang berbentuk kalimat, ambil
        // kotak dengan teks terbanyak saja.
        val dialog = segs.filter { isDialogText(it.text) }
        var kept = if (dialog.isNotEmpty()) dialog else listOf(segs.maxByOrNull { sg -> sg.text.count { it.isLetter() } }!!)
        // Kotak palsu (lantai/sprite yang terbaca sebagai beberapa huruf acak) jauh lebih pendek dari dialog sungguhan: buang.
        if (kept.size > 1) {
            val most = kept.maxOf { sg -> sg.text.count { it.isLetter() } }
            kept = kept.filter { sg -> sg.text.count { it.isLetter() } * 4 >= most }
        }
        return Found(kept, script)
    }

    /** Teks berbentuk kalimat dialog (bukan label pendek seperti "TIME" atau "SCORE 0"). */
    private fun isDialogText(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        val words = t.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val cjk = t.any { it.code > 0x2E80 }
        return (cjk && letters >= 4) || (words >= 3 && letters >= 10)
    }

    /**
     * Nama tokoh biasanya satu baris pendek di atas dialog (mis. "Ledah" di atas "Riviera should be just ..."):
     * 1-2 kata berawalan huruf besar, tanpa tanda baca akhir kalimat, jauh lebih pendek dari baris dialog di bawahnya,
     * dan rata kiri dengannya. Hasil: (nama atau null, baris dialog).
     */
    private fun splitSpeaker(sorted: List<RawLine>): Pair<String?, List<RawLine>> {
        if (sorted.size < 2) return null to sorted
        val first = sorted[0]
        val rest = sorted.drop(1)
        val t = first.text.trim()
        val bare = t.trimEnd(':').trim()
        if (!NAME_LINE.matches(t) || bare.length < 2 || !bare.last().isLetterOrDigit()) return null to sorted
        if (bare.split(Regex("\\s+")).size > 2) return null to sorted
        val restW = rest.maxOf { it.rect.width() }
        val restH = rest.map { it.rect.height() }.average().toFloat()
        if (first.rect.width() > restW * 0.6f) return null to sorted
        if (abs(first.rect.left - rest.minOf { it.rect.left }) > restH * 1.5f) return null to sorted
        return bare to rest
    }

    private val JA_OPEN = "「『（(【“\"‘"
    private val JA_STOP = "。、！？!?…・」』）)】”\"’,.，"

    /**
     * Gaya RPG Jepang: baris pertama kotak dialog = nama tokoh (mis. "クレスの父ミゲール"), baris berikutnya = ucapan yang
     * diawali 「 atau 『. Nama = baris pendek tanpa tanda baca, rata kiri dengan dialog, dan dialog di bawahnya berkurung
     * (atau nama jelas lebih pendek dari baris dialog). Hasil: (nama atau null, baris dialog).
     */
    private fun splitSpeakerCjk(sorted: List<RawLine>): Pair<String?, List<RawLine>> {
        if (sorted.size < 2) return null to sorted
        val first = sorted[0]
        val name = first.text.replace(Regex("\\s+"), "")
        if (name.isEmpty() || name.length > 16) return null to sorted
        if (name.any { it in JA_OPEN || it in JA_STOP }) return null to sorted
        val rest = sorted.drop(1)
        val next = rest[0].text.trimStart()
        val bracketNext = next.isNotEmpty() && next[0] in JA_OPEN
        val h = first.rect.height().coerceAtLeast(1)
        val aligned = abs(first.rect.left - rest.minOf { it.rect.left }) <= h * 2
        val near = rest[0].rect.top - first.rect.bottom <= h * 2
        val shorter = first.rect.width() <= rest.maxOf { it.rect.width() } * 0.6f
        if (!aligned || !near) return null to sorted
        if (!bracketNext && !(shorter && name.length <= 10)) return null to sorted
        return name to rest
    }

    /** Baca seluruh layar (atau 45% bagian bawah), lalu gabungkan baris jadi paragraf. */
    /**
     * Mode menu awal game: baca SELURUH layar dan jadikan tiap baris hasil OCR satu tulisan tersendiri (tidak digabung
     * menjadi paragraf seperti dialog), lengkap dengan kotaknya, supaya tiap tulisan menu ditimpa di tempatnya.
     * Tulisan yang terlalu panjang (kalimat) dilewati: itu dialog, bukan menu.
     */
    private suspend fun readMenu(
        frame: Bitmap, source: String, thorough: Boolean, onStatus: suspend (String) -> Unit
    ): Found? {
        val base = withContext(Dispatchers.Default) { FramePrep.normalizeSize(frame) }
        try {
            val b = readImage(base, source, thorough, GOOD_SCORE, RETRY_BELOW, onStatus) ?: return null
            if (b.lines.isEmpty() || b.score < minScore(b.script)) return null
            val cjk = b.script != "latin"
            val sx = base.width.toFloat() / frame.width
            val sy = base.height.toFloat() / frame.height
            val segs = b.lines.sortedWith(compareBy({ it.rect.top }, { it.rect.left })).mapNotNull { l ->
                val t = if (cjk) l.text.replace(Regex("\\s+"), "") else l.text.trim()
                val letters = t.count { it.isLetterOrDigit() }
                if (letters < (if (cjk) 1 else 2) || letters > 24) return@mapNotNull null
                Seg(
                    t,
                    RectF(l.rect.left / sx, l.rect.top / sy, l.rect.right / sx, l.rect.bottom / sy),
                    l.rect.height().toFloat() / sy
                )
            }
            return if (segs.isEmpty()) null else Found(segs, b.script)
        } finally {
            if (base !== frame && !base.isRecycled) base.recycle()
        }
    }

    private suspend fun readFullFrame(
        frame: Bitmap, source: String, bottomOnly: Boolean, thorough: Boolean, onStatus: suspend (String) -> Unit
    ): Found? {
        val cropped = FramePrep.crop(frame, bottomOnly)
        val base = withContext(Dispatchers.Default) { FramePrep.normalizeSize(cropped) }
        try {
            val b = readImage(base, source, thorough, GOOD_SCORE, RETRY_BELOW, onStatus) ?: return null
            if (b.lines.isEmpty() || b.score < minScore(b.script)) return null
            val cjk = b.script != "latin"
            val sx = base.width.toFloat() / cropped.width
            val sy = base.height.toFloat() / cropped.height
            val y0 = if (cropped !== frame) (frame.height - cropped.height).toFloat() else 0f
            val segs = group(b.lines).filter { p ->
                cjk || TextQuality.isReadable(p.lines.sortedBy { it.rect.top }.joinToString(" ") { it.text }, false, MIN_QUALITY)
            }.map { p ->
                val sorted = p.lines.sortedBy { it.rect.top }
                val (speaker, body) = if (cjk) splitSpeakerCjk(sorted) else splitSpeaker(sorted)
                val text = body.joinToString(if (cjk) "" else " ") { it.text }
                val r = p.rect()
                Seg(
                    text,
                    RectF(r.left / sx, r.top / sy + y0, r.right / sx, r.bottom / sy + y0),
                    p.lines.map { it.rect.height() }.average().toFloat() / sy,
                    speaker = speaker
                )
            }
            return if (segs.isEmpty()) null else Found(segs, b.script)
        } finally {
            if (base !== cropped && !base.isRecycled) base.recycle()
            if (cropped !== frame && !cropped.isRecycled) cropped.recycle()
        }
    }

    /**
     * OCR satu gambar dengan beberapa varian pra-pemrosesan dan pengenal aksara; ambil skor terbaik.
     * Berhenti lebih awal hanya bila hasilnya cukup banyak, terbaca wajar (bukan huruf acak), dan - untuk balon
     * dialog - seluruh tinta teks sudah terbaca (checkCoverage). Ini mencegah bacaan setengah jadi diterima
     * (penyebab terjemahan terpotong).
     */
    private suspend fun readImage(
        base: Bitmap, source: String, thorough: Boolean, good: Float, retryBelow: Float,
        onStatus: suspend (String) -> Unit, checkCoverage: Boolean = false
    ): Scored? {
        val variants = FramePrep.Variants(base)
        try {
            var best: Scored? = null
            val steps = plan(source, thorough)
            outer@ for ((idx, step) in steps.withIndex()) {
                val (script, count) = step
                if (!thorough && idx > 0 && (best?.adj ?: 0f) >= retryBelow && (best?.quality ?: 0f) >= MIN_QUALITY) break
                for (i in 0 until count) {
                    val vi = FramePrep.ORDER[i]
                    val bmp = withContext(Dispatchers.Default) { variants.get(vi) }
                    var s = recognize(bmp, recognizer(script), script)
                    val shear = FramePrep.shearOf(vi)
                    if (shear > 0f && s.lines.isNotEmpty()) s = unshear(s, shear, base.width, base.height)
                    // Mode otomatis: pengenal Jepang/Mandarin/Korea yang hanya membaca huruf Latin dibuang (itu tugas pengenal Latin;
                    // hasilnya akan salah digabung tanpa spasi).
                    if (source == "auto" && script != "latin" && s.lines.none { l -> l.text.any { ch -> ch.code > 0x2E80 } }) continue
                    if (s.lines.isNotEmpty()) {
                        val q = if (script == "latin") TextQuality.score(s.text(false)) else 1f
                        val cov = if (checkCoverage) withContext(Dispatchers.Default) { inkCoverage(base, s.lines) } else 1f
                        s = Scored(s.lines, s.score, s.script, q, cov)
                    }
                    val cur = best
                    if (cur == null || s.adj > cur.adj) best = s
                    val b = best
                    if (!thorough && b != null && b.score >= good && b.quality >= 0.6f && b.coverage >= MIN_COVERAGE) break@outer
                }
            }
            // Teks Jepang/Mandarin/Korea: OCR sering hanya menangkap satu baris (mis. nama tokoh) dan melewatkan isi
            // dialog di bawahnya. Baris yang terlewat dibaca ulang satu per satu supaya dialog terjemahan utuh.
            val b0 = best
            if (b0 != null && b0.script != "latin" && !menuMode) {
                val filled = fillMissedRows(base, b0.lines, b0.script)
                val oldLetters = b0.lines.sumOf { l -> l.text.count { it.isLetterOrDigit() } }
                val newLetters = filled.sumOf { l -> l.text.count { it.isLetterOrDigit() } }
                if (newLetters > oldLetters) {
                    best = Scored(filled, b0.score + (newLetters - oldLetters) * 0.6f, b0.script, b0.quality, 1f)
                }
            }
            // Hanya nama tokoh yang terbaca (isi dialog hilang): ulangi dengan SEMUA varian gambar sebelum menyerah,
            // supaya tidak berakhir dengan nama saja yang diterjemahkan sementara dialognya tetap Jepang.
            val b1 = best
            if (b1 != null && b1.script != "latin" && !menuMode && !thorough && looksNameOnly(b1.lines)) {
                dbgFill += " [nama-saja: ulang teliti]"
                val retry = readImage(base, source, true, good, retryBelow, onStatus, checkCoverage)
                if (retry != null && retry.lines.sumOf { l -> l.text.count { it.isLetterOrDigit() } } >
                    b1.lines.sumOf { l -> l.text.count { it.isLetterOrDigit() } }) best = retry
            }
            return best
        } finally {
            variants.release()
        }
    }

    /** Teks pendek tanpa tanda baca dialog = kemungkinan besar hanya nama tokoh (mis. "クレスの父ミゲール"). */
    private fun looksNameOnlyText(text: String): Boolean {
        val t = text.replace(Regex("\\s+"), "")
        return t.length in 2..16 && t.none { it in JA_OPEN || it in JA_STOP }
    }

    private fun looksNameOnly(lines: List<RawLine>): Boolean =
        lines.size == 1 && looksNameOnlyText(lines[0].text) && lines[0].text.count { it.isLetterOrDigit() } <= 8

    /**
     * Cari baris teks yang terlewat tepat di bawah teks hasil OCR (kotak dialog: nama tokoh di baris pertama, isi
     * dialog di bawahnya). Baris ditemukan lewat proyeksi tinta (piksel terang/gelap), dipotong satu per satu,
     * diperbesar, lalu dibaca ulang. Pemindaian berhenti di garis tepi kotak dialog atau saat jarak antarbaris
     * terlalu jauh. Mengembalikan daftar baris asli ditambah baris baru di belakangnya.
     */
    private suspend fun fillMissedRows(base: Bitmap, found: List<RawLine>, script: String): List<RawLine> {
        if (found.isEmpty()) return found
        val w = base.width
        val h = base.height
        if (w < 32 || h < 32) return found
        val px = IntArray(w * h)
        base.getPixels(px, 0, w, 0, 0, w, h)
        fun lum(x: Int, y: Int): Int {
            val c = px[y * w + x]
            return (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
        val out = ArrayList<RawLine>(found)
        val rec = recognizer(script)
        dbgFill += "isi($script):" + found.joinToString("|") { it.text.take(14) + "@" + it.rect.top + "-" + it.rect.bottom }

        for (p in group(found)) {
            val u = p.rect()
            val lh = p.lines.map { it.rect.height() }.average().toFloat().coerceAtLeast(8f)
            val x0 = max(0, (u.left - lh).toInt())
            val y0 = (u.top - lh * 0.2f).toInt().coerceIn(0, h - 1)
            var y1 = min(h, (u.bottom + lh * 6f).toInt())
            if (y1 - y0 < lh * 0.6f) continue

            // Latar gelap (teks terang) atau latar terang (teks gelap): dilihat dari rata-rata kecerahan area teks.
            var sum = 0L
            var n = 0
            for (y in u.top.coerceIn(0, h - 1) until min(h, u.bottom)) {
                var x = u.left.coerceIn(0, w - 1)
                val xe = min(w, u.right)
                while (x < xe) { sum += lum(x, y); n++; x += 2 }
            }
            val inkLight = n == 0 || sum / n < 128
            fun ink(x: Int, y: Int): Boolean { val l = lum(x, y); return if (inkLight) l > 170 else l < 110 }

            // Garis tepi kotak dialog (baris yang hampir penuh tinta) menjadi batas bawah pemindaian.
            for (y in y0 until y1) {
                var c = 0
                for (x in x0 until w) if (ink(x, y)) c++
                if (c > (w - x0) * 0.6f) { y1 = y; break }
            }
            if (y1 - y0 < lh * 0.6f) continue

            // Kolom tepi vertikal kotak (tinta di hampir semua baris) diabaikan.
            val rowsN = y1 - y0
            val border = BooleanArray(w)
            for (x in x0 until w) {
                var c = 0
                for (y in y0 until y1) if (ink(x, y)) c++
                border[x] = c > rowsN * 0.7f
            }

            val minCount = max(2, w / 400)
            val inkRow = BooleanArray(rowsN)
            for (i in 0 until rowsN) {
                var c = 0
                for (x in x0 until w) if (!border[x] && ink(x, y0 + i)) c++
                inkRow[i] = c >= minCount
            }

            // Kelompokkan baris tinta berurutan menjadi pita (satu pita = satu baris teks).
            val bands = ArrayList<IntArray>()
            val closeGap = max(2, (lh * 0.15f).toInt())
            var i = 0
            while (i < rowsN) {
                if (!inkRow[i]) { i++; continue }
                val start = i
                var end = i
                var blank = 0
                while (i < rowsN && blank <= closeGap) {
                    if (inkRow[i]) { end = i; blank = 0 } else blank++
                    i++
                }
                bands += intArrayOf(y0 + start, y0 + end + 1)
                if (bands.size >= 6) break
            }

            var lastBottom = u.bottom
            var added = 0
            dbgFill += " pita=${bands.size}"
            for (b in bands) {
                val bh = b[1] - b[0]
                if (bh < lh * 0.35f || bh > lh * 3f) continue
                if (b[0] - lastBottom > lh * 2.5f) break          // jarak terlalu jauh: bukan lanjutan dialog
                val overl = out.filter { l -> min(l.rect.bottom, b[1]) - max(l.rect.top, b[0]) >= bh * 0.5f }
                var minX = w
                var maxX = -1
                for (y in b[0] until b[1]) for (x in x0 until w) if (!border[x] && ink(x, y)) { if (x < minX) minX = x; if (x > maxX) maxX = x }
                if (maxX < 0 || maxX - minX < lh * 0.8f) continue
                var lo = 0
                for (x in minX - 1 downTo x0) if (border[x]) { lo = x + 1; break }
                var hi = w
                for (x in maxX + 1 until w) if (border[x]) { hi = x; break }
                val pad = (lh * 0.4f).toInt().coerceAtLeast(4)
                val left = max(lo, minX - pad)
                val right = min(hi, maxX + pad)
                val top = max(0, b[0] - pad)
                val bottom = min(h, b[1] + pad)
                if (right - left < 8 || bottom - top < 8) continue

                val got = readCrop(base, left, top, right, bottom, lh, rec, script)
                if (got.isNotEmpty()) {
                    val gotLen = got.sumOf { l -> l.text.count { it.isLetterOrDigit() } }
                    val oldLen = overl.sumOf { l -> l.text.count { it.isLetterOrDigit() } }
                    if (overl.isEmpty()) {
                        out += got
                        added += got.size
                    } else if (gotLen > oldLen) {
                        out.removeAll(overl.toSet())
                        out += got
                        added += got.size
                    }
                    dbgFill += " [" + got.joinToString("|") { it.text.take(14) } + "]"
                    lastBottom = b[1]
                } else if (overl.isNotEmpty()) lastBottom = b[1]
            }
            // Cadangan: bila per-baris tidak menambah apa pun, baca seluruh area di bawah teks sekaligus (diperbesar).
            if (added == 0 && y1 - y0 >= lh * 1.2f) {
                var lo = 0
                for (x in u.left - 1 downTo x0) if (x in 0 until w && border[x]) { lo = x + 1; break }
                var hi = w
                for (x in u.right + 1 until w) if (border[x]) { hi = x; break }
                val left = max(lo, u.left - (lh * 0.5f).toInt())
                val got = readCrop(base, left, y0, hi, y1, lh, rec, script)
                    .filter { l -> out.none { o -> min(o.rect.bottom, l.rect.bottom) - max(o.rect.top, l.rect.top) >= l.rect.height() * 0.5f } }
                if (got.isNotEmpty()) {
                    out += got
                    dbgFill += " area[" + got.joinToString("|") { it.text.take(14) } + "]"
                }
            }
        }
        return out
    }

    /** OCR satu potongan gambar: diperbesar sampai tinggi huruf ~72 px, diberi margin, beberapa varian dicoba. */
    private suspend fun readCrop(
        base: Bitmap, left: Int, top: Int, right: Int, bottom: Int, lh: Float, rec: TextRecognizer, script: String
    ): List<RawLine> {
        if (right - left < 8 || bottom - top < 8) return emptyList()
        val crop = Bitmap.createBitmap(base, left, top, right - left, bottom - top)
        val scale = (72f / lh).coerceIn(1f, 4f)
        val margin = 24
        val bg = crop.getPixel(0, 0)
        val scaledW = (crop.width * scale).roundToInt().coerceAtLeast(1)
        val scaledH = (crop.height * scale).roundToInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(crop, scaledW, scaledH, true)
        val padded = Bitmap.createBitmap(scaledW + margin * 2, scaledH + margin * 2, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(padded)
        canvas.drawColor(bg)
        canvas.drawBitmap(scaled, margin.toFloat(), margin.toFloat(), null)
        val vs = FramePrep.Variants(padded)
        try {
            var bestRead: Scored? = null
            for (vi in intArrayOf(0, 1, 4, 5, 9)) {
                val r = recognize(vs.get(vi), rec, script)
                val cur = bestRead
                if (r.lines.isNotEmpty() && (cur == null || r.score > cur.score)) bestRead = r
                if (r.score >= 8f) break
            }
            return (bestRead?.lines ?: emptyList()).map { l ->
                RawLine(
                    l.text,
                    Rect(
                        left + ((l.rect.left - margin) / scale).roundToInt(),
                        top + ((l.rect.top - margin) / scale).roundToInt(),
                        left + ((l.rect.right - margin) / scale).roundToInt(),
                        top + ((l.rect.bottom - margin) / scale).roundToInt()
                    )
                )
            }
        } finally {
            vs.release()
            if (!padded.isRecycled) padded.recycle()
            if (scaled !== crop && !scaled.isRecycled) scaled.recycle()
            if (!crop.isRecycled) crop.recycle()
        }
    }

    /**
     * Seberapa besar bagian tinta gelap (teks) pada potongan balon yang sudah tercakup kotak baris hasil OCR.
     * Nilai rendah = ada teks yang terlewat (mis. baris kedua belum terbaca).
     */
    private fun inkCoverage(base: Bitmap, lines: List<RawLine>): Float {
        val w = base.width
        val h = base.height
        if (w < 8 || h < 8) return 1f
        val px = IntArray(w * h)
        base.getPixels(px, 0, w, 0, 0, w, h)
        val covered = BooleanArray(w * h)
        for (l in lines) {
            val m = max(4, (l.rect.height() * 0.35f).toInt())
            val x0 = (l.rect.left - m).coerceIn(0, w - 1)
            val x1 = (l.rect.right + m).coerceIn(0, w)
            val y0 = (l.rect.top - m).coerceIn(0, h - 1)
            val y1 = (l.rect.bottom + m).coerceIn(0, h)
            for (y in y0 until y1) java.util.Arrays.fill(covered, y * w + x0, y * w + x1, true)
        }
        val mx = (w * 0.04f).toInt()
        val my = (h * 0.06f).toInt()
        // Latar gelap (kotak dialog hitam, teks putih): tinta = piksel terang. Latar terang: tinta = piksel gelap.
        var darkPx = 0
        for (c in px) {
            val l = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            if (l < 100) darkPx++
        }
        val inkIsLight = darkPx > px.size / 2
        var ink = 0
        var seen = 0
        for (y in my until h - my) {
            val row = y * w
            for (x in mx until w - mx) {
                val c = px[row + x]
                val l = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
                if (if (inkIsLight) l > 150 else l < 100) { ink++; if (covered[row + x]) seen++ }
            }
        }
        if (ink < 40) return 1f
        return seen.toFloat() / ink
    }

    /** Kembalikan kotak baris hasil OCR pada gambar yang sudah diluruskan ke koordinat gambar asli. */
    private fun unshear(sc: Scored, shear: Float, w: Int, h: Int): Scored {
        val mid = h / 2f
        val off = shear * h / 2f
        val mapped = sc.lines.map { l ->
            val dx = (off + shear * (l.rect.centerY() - mid)).roundToInt()
            val left = (l.rect.left - dx).coerceIn(0, w - 1)
            val right = (l.rect.right - dx).coerceIn(left + 1, w)
            RawLine(l.text, Rect(left, l.rect.top, right, l.rect.bottom))
        }
        return Scored(mapped, sc.score, sc.script)
    }

    private suspend fun recognize(bmp: Bitmap, rec: TextRecognizer, script: String): Scored {
        val text = rec.process(InputImage.fromBitmap(bmp, 0)).await()
        dbgCalls++
        if (text.text.length > dbgRaw.length) { dbgRaw = text.text; dbgScript = script }
        var score = 0f
        val lines = ArrayList<RawLine>()
        for (b in text.textBlocks) {
            for (l in b.lines) {
                val t = l.text.trim()
                val letters = t.count { it.isLetterOrDigit() }
                if (letters == 0) continue
                val conf = l.confidence.let { if (it > 0f) it else 0.6f }
                if (conf < (if (script == "latin") 0.3f else 0.05f)) continue   // font piksel Jepang: kepercayaan ML Kit sering rendah
                val rect = l.boundingBox ?: continue
                score += conf * letters
                lines += RawLine(t, rect)
            }
        }
        return Scored(lines, score, script)
    }

    /** Gabungkan baris yang saling berdekatan dan sejajar menjadi satu paragraf dialog (konteks lebih baik). */
    private fun group(rawLines: List<RawLine>): List<Para> {
        val lines = mergeRows(rawLines)
        val sorted = lines.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        val paras = ArrayList<Para>()
        for (l in sorted) {
            var target: Para? = null
            var bestGap = Int.MAX_VALUE
            for (p in paras) {
                val last = p.lines.last().rect
                val h = max(last.height(), l.rect.height())
                val gap = l.rect.top - last.bottom
                val hr = l.rect.height().toFloat() / last.height().coerceAtLeast(1)
                if (hr < 0.5f || hr > 2.0f) continue
                val overlap = min(last.right, l.rect.right) - max(last.left, l.rect.left)
                val minW = min(last.width(), l.rect.width())
                val aligned = abs(last.left - l.rect.left) <= h * 1.5f
                val centered = abs(last.centerX() - l.rect.centerX()) <= h * 1.5f   // teks rata tengah
                // Dialog game retro sering berjarak baris renggang: jangan dipecah. Bila baris jelas sejajar
                // (rata kiri/tengah), jarak sampai ~6x tinggi huruf masih dianggap satu kalimat/paragraf.
                val maxGap = if (aligned || centered) h * 6f else h * 2.5f
                if (gap < -h / 2 || gap > maxGap) continue
                if (!(aligned || centered || overlap >= minW * 0.3f)) continue
                if (gap < bestGap) { bestGap = gap; target = p }
            }
            if (target != null) target.lines += l else paras += Para(mutableListOf(l))
        }
        return mergeNearby(paras)
    }

    /**
     * Segmen teks yang sebaris tetapi dipisah spasi lebar (kata berjauhan, perataan rata kiri-kanan, jarak huruf
     * lebar) digabung menjadi satu baris, urut dari kiri ke kanan, supaya kalimat tidak terpecah.
     */
    private fun mergeRows(lines: List<RawLine>): List<RawLine> {
        class Row(var text: String, val rect: Rect)
        val rows = ArrayList<Row>()
        for (l in lines.sortedBy { it.rect.left }) {
            val h = l.rect.height().coerceAtLeast(1)
            val target = rows.firstOrNull { r ->
                val rh = r.rect.height().coerceAtLeast(1)
                val vOverlap = min(r.rect.bottom, l.rect.bottom) - max(r.rect.top, l.rect.top)
                val hr = h.toFloat() / rh
                val gap = l.rect.left - r.rect.right
                vOverlap >= 0.6f * min(h, rh) && hr in 0.6f..1.7f && gap >= -0.3f * h && gap <= 8f * max(h, rh)
            }
            if (target == null) rows += Row(l.text, Rect(l.rect))
            else {
                val cjk = l.text.any { it.code > 0x2E80 } && target.text.any { it.code > 0x2E80 }
                target.text = target.text + (if (cjk) "" else " ") + l.text
                target.rect.union(l.rect)
            }
        }
        return rows.map { RawLine(it.text, it.rect) }
    }

    /**
     * Satu kotak dialog tidak boleh menjadi beberapa terjemahan yang saling menimpa. Paragraf yang bertumpuk
     * (jaraknya kurang dari satu tinggi huruf, dan lebarnya saling beririsan) digabung menjadi satu, diulang
     * sampai tidak ada lagi yang bisa digabung.
     */
    private fun mergeNearby(paras: List<Para>): List<Para> {
        val list = ArrayList(paras)
        fun avgH(p: Para) = p.lines.map { it.rect.height() }.average().toFloat()
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in list.indices) {
                for (j in i + 1 until list.size) {
                    val a = list[i]
                    val b = list[j]
                    val ha = avgH(a)
                    val hb = avgH(b)
                    val ra = a.rect()
                    val rb = b.rect()
                    // Potongan teks yang berada DI DALAM paragraf lain pasti bagian darinya (kotak dialog yang sama).
                    val inside = ra.contains(rb.centerX(), rb.centerY()) || rb.contains(ra.centerX(), ra.centerY())
                    val hr = ha / hb.coerceAtLeast(1f)
                    if (!inside && (hr < 0.5f || hr > 2.0f)) continue
                    val m = (max(ha, hb) * 2.5f).toInt()
                    val near = Rect(ra.left - m, ra.top - m, ra.right + m, ra.bottom + m)
                    if (!inside) {
                        if (!Rect.intersects(near, rb)) continue
                        val overlapX = min(ra.right, rb.right) - max(ra.left, rb.left)
                        if (overlapX < min(ra.width(), rb.width()) * 0.3f) continue
                    }
                    a.lines += b.lines
                    a.lines.sortWith(compareBy({ it.rect.top }, { it.rect.left }))
                    list.removeAt(j)
                    changed = true
                    break@loop
                }
            }
        }
        return list
    }

    /** Perbaikan kesalahan OCR yang umum pada font retro (hanya pola yang hampir pasti salah). */
    private fun cleanup(s0: String): String {
        var s = s0
            .replace(Regex("(?<=\\s|^)\\|(?=\\s|$)"), "I")
            .replace(Regex("(?<=\\p{L})\\|(?=\\p{L})"), "l")
            // angka yang terselip di dalam kata: "G0ING" -> "GOING", "he1lo" -> "hello", "TH1S" -> "THIS"
            .replace(Regex("(?<=\\p{Lu})0(?=\\p{Lu})"), "O")
            .replace(Regex("(?<=\\p{Ll})0(?=\\p{Ll})"), "o")
            .replace(Regex("(?<=\\p{Ll})1(?=\\p{Ll})"), "l")
            .replace(Regex("(?<=\\p{Lu})1(?=\\p{Lu})"), "I")
            // "1'm" / "l'm" / "l'll" -> "I'm" / "I'll"
            .replace(Regex("(?<![\\p{L}0-9])[1l]'(?=(m|ll|ve|d)(?![\\p{L}]))"), "I'")
            // "l" tunggal di antara spasi pada teks Latin -> "I"
            .replace(Regex("(?<=\\s|^)l(?=\\s)"), "I")
            // "M JUST" -> "I'M JUST" (apostrof dan I sering hilang pada font piksel)
            .replace(Regex("(?<![\\p{L}0-9'])M(?=\\s+(?:JUST|NOT|GOING|GONNA|SORRY|HERE|ALL|SO|IN|ON|AFRAID|READY|THE|A|AN|NO|YOUR|TOO)(?![\\p{L}]))"), "I'M")
            .replace(Regex("(?<![\\p{L}0-9'])m(?=\\s+(?:just|not|going|gonna|sorry|here|all|so|in|on|afraid|ready|the|a|an|no|your|too)(?![\\p{L}]))"), "I'm")
            // tanda seru miring pada font italic sering terbaca "/": "RELAX/ LET'S" -> "RELAX! LET'S"
            .replace(Regex("(?<=\\p{L})\\s*/(?=\\s+\\p{Lu}|\\s*$)"), "!")
            .replace(Regex("(?<=\\p{L})\\s*¡"), "!")
            // "HEI," -> "HEY,"
            .replace(Regex("(?<![\\p{L}])HEI(?![\\p{L}])"), "HEY")
            .replace(Regex("[ \\t]{2,}"), " ")
            .trim()
        // Tanda baca yang sering menempel di huruf: "word ,"  -> "word,"
        s = s.replace(Regex("\\s+([,.!?;:])"), "$1")
        return s
    }

    private fun isAllCaps(s: String): Boolean {
        val letters = s.filter { it.isLetter() }
        return letters.length >= 4 && letters.count { it.isUpperCase() } >= letters.length * 0.85f
    }

    /** Font retro sering HURUF BESAR semua; penerjemah lebih akurat dengan huruf biasa. */
    private fun sentenceCase(s: String): String {
        val sb = StringBuilder()
        var capNext = true
        for (ch in s.lowercase()) {
            if (capNext && ch.isLetter()) { sb.append(ch.uppercaseChar()); capNext = false } else sb.append(ch)
            if (ch == '.' || ch == '!' || ch == '?') capNext = true
        }
        return sb.toString().replace(Regex("\\bi\\b"), "I")
            .replace(Regex("\\b\\p{L}+\\b")) { m -> if (m.value.lowercase() in ACRONYMS) m.value.uppercase() else m.value }
    }

    private suspend fun detectLang(text: String, script: String, source: String): String {
        if (source == "en") return "en"
        val hasKana = text.any { it in '\u3040'..'\u30FF' }
        val hasHangul = text.any { it in '\uAC00'..'\uD7AF' || it in '\u1100'..'\u11FF' }
        val hasHan = text.any { it in '\u4E00'..'\u9FFF' }
        return when {
            hasKana -> "ja"
            hasHangul -> "ko"
            hasHan -> if (script == "ja") "ja" else "zh"
            else -> {
                // Teks dialog game pendek dan sering salah baca OCR, jadi deteksi bahasa mudah tertipu
                // (mis. "HEI" dianggap Finlandia). Kecuali sangat yakin, anggap Inggris.
                val letters = text.count { it.isLetter() }
                val cands = try { langId.identifyPossibleLanguages(text).await() } catch (e: Exception) { emptyList() }
                val top = cands.firstOrNull { it.languageTag != "und" }
                val en = cands.firstOrNull { it.languageTag == "en" }?.confidence ?: 0f
                when {
                    top == null -> "en"
                    top.languageTag == "en" -> "en"
                    letters >= 40 && top.confidence >= 0.9f && en < 0.2f -> top.languageTag.substringBefore('-')
                    else -> "en"
                }
            }
        }
    }

    private suspend fun translate(blocks: List<String>, lang: String, onStatus: suspend (String) -> Unit): List<String> {
        if (blocks.isEmpty()) return blocks
        // Dua mesin dipisah TOTAL (tanpa cadangan silang): online hanya Google Translate, offline hanya ML Kit.
        if (online) {
            return translateOnline(blocks, lang)
                ?: throw IllegalStateException("terjemahan online gagal, periksa internet atau pilih mesin Offline di Pengaturan")
        }
        val src = TranslateLanguage.fromLanguageTag(lang)
            ?: error("Bahasa '$lang' belum didukung penerjemah offline")
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.INDONESIAN)
                    .build()
            )
        }
        if (blocks.any { cache["$src|$it"] == null }) {
            // Beri tahu pengguna hanya saat model bahasa memang belum ada dan harus diunduh.
            val downloaded = RemoteModelManager.getInstance()
                .isModelDownloaded(TranslateRemoteModel.Builder(src).build()).await()
            if (!downloaded) onStatus("Mengunduh model bahasa (sekali saja, perlu internet)…")
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            if (!downloaded) onStatus("")      // unduhan selesai: tutup pesan
        }
        if (cache.size > 300) cache.clear()
        return blocks.map { t -> translateOne(tr, src, t) }
    }

    /** Google Translate (endpoint web tanpa kunci). Mengembalikan null bila gagal -> pakai penerjemah offline. */
    private suspend fun translateOnline(blocks: List<String>, lang: String): List<String>? = withContext(Dispatchers.IO) {
        try {
            val sl = if (lang == "zh") "zh-CN" else lang
            val out = ArrayList<String>(blocks.size)
            for (b in blocks) {
                val key = "$sl|$b"
                val hit = onlineCache[key]
                if (hit != null) { out += hit; continue }
                val t = googleTranslate(b, sl) ?: return@withContext null
                if (onlineCache.size > 300) onlineCache.clear()
                onlineCache[key] = t
                out += t
            }
            out
        } catch (_: Exception) { null }
    }

    private fun googleTranslate(text: String, sl: String): String? {
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=id&dt=t&q=" +
            URLEncoder.encode(text, "UTF-8"))
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (c.responseCode != 200) return null
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val segs = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) sb.append(segs.getJSONArray(i).optString(0, ""))
            return sb.toString().trim().ifEmpty { null }
        } finally {
            c.disconnect()
        }
    }

    private suspend fun translateParts(tr: Translator, parts: List<String>): String {
        val sb = StringBuilder()
        for (p in parts) {
            val t = tr.translate(p).await().trim()
            if (t.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(t)
        }
        return sb.toString()
    }

    private fun wordCount(s: String) = Regex("[\\p{L}\\p{N}][\\p{L}\\p{N}'’-]*").findAll(s).count()

    /**
     * Terjemahan per kalimat (penerjemah offline sering menjatuhkan kalimat/ujung teks bila inputnya panjang),
     * "..." di awal/akhir dipisahkan dulu, dan hasil yang jauh lebih pendek dari aslinya diulang per klausa.
     */
    private suspend fun translateOne(tr: Translator, src: String, text: String): String {
        val key = "$src|$text"
        cache[key]?.let { return it }
        val m = Regex("^(\\s*(?:\\.{2,}|…)\\s*)?(.*?)(\\s*(?:\\.{2,}|…)\\s*)?$", RegexOption.DOT_MATCHES_ALL).matchEntire(text)
        val lead = if (m != null && m.groupValues[1].isNotBlank()) "... " else ""
        val body = (m?.groupValues?.get(2) ?: text).trim()
        val trail = if (m != null && m.groupValues[3].isNotBlank()) "..." else ""
        if (body.isBlank()) return text

        val sentences = body.split(Regex("(?<=[.!?])\\s+|(?<=[。！？])")).filter { it.isNotBlank() }
        var joined = translateParts(tr, sentences)

        val sw = wordCount(body)
        if (sw >= 4 && wordCount(joined) < sw * 0.5f) {
            val clauses = body.split(Regex("(?<=[,;:])\\s+|\\s+[-–—]\\s+|\\s+(?=(?:and|but|or|so|because|then)\\b)", RegexOption.IGNORE_CASE))
                .filter { it.isNotBlank() }
            val parts = if (clauses.size > 1) clauses else {
                val words = body.split(Regex("\\s+"))
                words.chunked(4).map { it.joinToString(" ") }
            }
            val alt = translateParts(tr, parts)
            if (wordCount(alt) > wordCount(joined)) joined = alt
        }
        val out = (lead + joined + trail).trim()
        if (cache.size > 300) cache.clear()
        cache[key] = out
        return out
    }

    fun close() {
        try { latin.close() } catch (_: Exception) {}
        try { japanese.close() } catch (_: Exception) {}
        try { chinese.close() } catch (_: Exception) {}
        try { korean.close() } catch (_: Exception) {}
        try { langId.close() } catch (_: Exception) {}
        translators.values.forEach { try { it.close() } catch (_: Exception) {} }
        translators.clear()
    }
}
