package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.RectF
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Alur: layar game -> pra-pemrosesan (beberapa varian) -> OCR on-device (Latin/Jepang/Mandarin/Korea)
 * -> pilih hasil dengan skor kepercayaan terbaik -> baris digabung jadi paragraf dialog (dengan posisi di layar)
 * -> normalisasi slang -> terjemahan on-device ke Indonesia -> analisis gaya teks asli (warna, outline, dll).
 */
class TranslationEngine {

    companion object {
        /** Kunci pengaturan -> label. "en" memaksa bahasa Inggris (lebih akurat untuk dialog pendek). */
        val SOURCES = listOf(
            "auto" to "Otomatis (Latin, Jepang, Mandarin, Korea)",
            "en" to "Inggris (termasuk slang AS & Britania)",
            "latin" to "Latin lain (Spanyol, Prancis, Jerman, dll)",
            "ja" to "Jepang",
            "zh" to "Mandarin",
            "ko" to "Korea"
        )

        private const val GOOD_SCORE = 35f      // cukup bagus -> berhenti mencoba varian lain (mode cepat)
        private const val RETRY_BELOW = 15f     // di bawah ini -> coba pengenal aksara lain
        private const val MIN_SCORE = 4f        // di bawah ini -> dianggap tidak ada teks

        private val NAME_LABEL = Regex("^\\p{L}[\\p{L}0-9 .'-]{0,15}:$")
    }

    /** box = posisi di layar game (piksel view); null bila tidak perlu ditimpa (nama pembicara, angka, dll). */
    data class Block(val original: String, val translated: String, val box: RectF?, val style: TextStyle?)
    data class Result(
        val blocks: List<Block>, val sourceLabel: String, val translated: Boolean,
        val frameW: Int, val frameH: Int
    )

    private class RawLine(val text: String, val rect: Rect)
    private class Scored(val lines: List<RawLine>, val score: Float, val script: String)
    private class Para(val lines: MutableList<RawLine>) {
        fun rect(): Rect {
            val r = Rect(lines[0].rect)
            for (l in lines) r.union(l.rect)
            return r
        }
    }

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val japanese by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val chinese by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val korean by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val langId by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.3f).build())
    }
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>()

    private fun recognizer(script: String): TextRecognizer = when (script) {
        "ja" -> japanese
        "zh" -> chinese
        "ko" -> korean
        else -> latin
    }

    /** Pasangan (aksara, jumlah varian gambar yang dicoba). */
    private fun plan(source: String, thorough: Boolean): List<Pair<String, Int>> {
        val n = FramePrep.VARIANT_COUNT
        return when (source) {
            "en", "latin" -> listOf("latin" to n)
            "ja" -> listOf("ja" to n)
            "zh" -> listOf("zh" to n)
            "ko" -> listOf("ko" to n)
            else -> if (thorough) listOf("latin" to n, "ja" to n, "zh" to n, "ko" to n)
            else listOf("latin" to n, "ja" to 3, "zh" to 2, "ko" to 2)
        }
    }

    suspend fun run(
        frame: Bitmap,
        source: String,
        bottomOnly: Boolean,
        thorough: Boolean,
        glossary: File?,
        onStatus: suspend (String) -> Unit
    ): Result? {
        val cropped = FramePrep.crop(frame, bottomOnly)
        val base = withContext(Dispatchers.Default) { FramePrep.normalizeSize(cropped) }
        val variants = FramePrep.Variants(base)
        try {
            var best: Scored? = null
            val steps = plan(source, thorough)
            outer@ for ((idx, step) in steps.withIndex()) {
                val (script, count) = step
                if (!thorough && idx > 0 && (best?.score ?: 0f) >= RETRY_BELOW) break
                if (idx > 0) onStatus("Mencoba pengenal aksara lain…")
                for (i in 0 until count) {
                    val bmp = withContext(Dispatchers.Default) { variants.get(i) }
                    val s = recognize(bmp, recognizer(script), script)
                    val cur = best
                    if (cur == null || s.score > cur.score) best = s
                    if (!thorough && (best?.score ?: 0f) >= GOOD_SCORE) break@outer
                }
            }
            val b = best ?: return null
            if (b.lines.isEmpty() || b.score < MIN_SCORE) return null

            val cjk = b.script != "latin"
            val paras = group(b.lines)
            val reads = paras.map { p ->
                val sorted = p.lines.sortedBy { it.rect.top }
                cleanup(sorted.joinToString(if (cjk) "" else " ") { it.text })
            }
            if (reads.all { it.isBlank() }) return null

            // Geometri: koordinat varian -> koordinat layar game (frame)
            val sx = base.width.toFloat() / cropped.width
            val sy = base.height.toFloat() / cropped.height
            val y0 = if (cropped !== frame) (frame.height - cropped.height).toFloat() else 0f

            val caps = reads.map { isAllCaps(it) }
            val prep = reads.indices.map { i ->
                var t = reads[i]
                if (caps[i]) t = sentenceCase(t)
                t
            }

            val lang = detectLang(prep.joinToString("\n"), b.script, source)
            val label = Locale(lang).getDisplayLanguage(Locale("id")).replaceFirstChar { it.uppercase() }

            val prepared = if (lang == "en") prep.map { SlangNormalizer.normalize(it, glossary) } else prep

            // Nama pembicara ("CLOUD:"), angka, dan teks terlalu pendek tidak diterjemahkan/ditimpa.
            val skip = reads.indices.map { i ->
                NAME_LABEL.matches(reads[i]) || reads[i].count { it.isLetter() } < 2
            }

            val translatedTexts: List<String> =
                if (lang == "id") prepared
                else {
                    val idxs = reads.indices.filter { !skip[it] }
                    val out = translate(idxs.map { prepared[it] }, lang, onStatus)
                    val m = prepared.toMutableList()
                    idxs.forEachIndexed { n, i -> m[i] = out[n] }
                    m
                }

            val blocks = withContext(Dispatchers.Default) {
                reads.indices.map { i ->
                    val r = paras[i].rect()
                    val box = RectF(r.left / sx, r.top / sy + y0, r.right / sx, r.bottom / sy + y0)
                    val lineH = paras[i].lines.map { it.rect.height() }.average().toFloat() / sy
                    var shown = translatedTexts[i]
                    if (caps[i]) shown = shown.uppercase(Locale("id"))
                    val same = shown.trim().equals(reads[i].trim(), ignoreCase = true)
                    if (skip[i] || same || lang == "id") {
                        Block(reads[i], reads[i], null, null)
                    } else {
                        Block(reads[i], shown, box, StyleAnalyzer.analyze(frame, box, lineH, caps[i]))
                    }
                }
            }
            return Result(blocks, label, lang != "id", frame.width, frame.height)
        } finally {
            variants.release()
            if (base !== frame && !base.isRecycled && base !== cropped) base.recycle()
            if (cropped !== frame && !cropped.isRecycled) cropped.recycle()
        }
    }

    private suspend fun recognize(bmp: Bitmap, rec: TextRecognizer, script: String): Scored {
        val text = rec.process(InputImage.fromBitmap(bmp, 0)).await()
        var score = 0f
        val lines = ArrayList<RawLine>()
        for (b in text.textBlocks) {
            for (l in b.lines) {
                val t = l.text.trim()
                val letters = t.count { it.isLetterOrDigit() }
                if (letters == 0) continue
                val conf = l.confidence.let { if (it > 0f) it else 0.6f }
                if (conf < 0.3f) continue
                val rect = l.boundingBox ?: continue
                score += conf * letters
                lines += RawLine(t, rect)
            }
        }
        return Scored(lines, score, script)
    }

    /** Gabungkan baris yang saling berdekatan dan sejajar menjadi satu paragraf dialog (konteks lebih baik). */
    private fun group(lines: List<RawLine>): List<Para> {
        val sorted = lines.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        val paras = ArrayList<Para>()
        for (l in sorted) {
            var target: Para? = null
            var bestGap = Int.MAX_VALUE
            for (p in paras) {
                val last = p.lines.last().rect
                val h = max(last.height(), l.rect.height())
                val gap = l.rect.top - last.bottom
                if (gap < -h / 2 || gap > h * 0.9f) continue
                val hr = l.rect.height().toFloat() / last.height().coerceAtLeast(1)
                if (hr < 0.6f || hr > 1.7f) continue
                val overlap = min(last.right, l.rect.right) - max(last.left, l.rect.left)
                val minW = min(last.width(), l.rect.width())
                val aligned = abs(last.left - l.rect.left) <= h * 1.5f
                if (!(aligned || overlap >= minW * 0.4f)) continue
                if (gap < bestGap) { bestGap = gap; target = p }
            }
            if (target != null) target.lines += l else paras += Para(mutableListOf(l))
        }
        return paras
    }

    /** Perbaikan kecil kesalahan OCR yang umum pada font retro. */
    private fun cleanup(s: String): String =
        s.replace(Regex("(?<=\\s|^)\\|(?=\\s|$)"), "I")
            .replace(Regex("(?<=\\p{L})\\|(?=\\p{L})"), "l")
            .replace(Regex("[ \\t]{2,}"), " ")
            .trim()

    private fun isAllCaps(s: String): Boolean {
        val letters = s.filter { it.isLetter() }
        return letters.length >= 4 && letters.count { it.isUpperCase() } >= letters.length * 0.85f
    }

    /** Font retro sering HURUF BESAR semua; penerjemah lebih akurat dengan huruf biasa. */
    private fun sentenceCase(s: String): String {
        val sb = StringBuilder()
        var capNext = true
        for (ch in s.lowercase()) {
            if (capNext && ch.isLetter()) { sb.append(ch.uppercaseChar()); capNext = false } else sb.append(ch)
            if (ch == '.' || ch == '!' || ch == '?') capNext = true
        }
        return sb.toString().replace(Regex("\\bi\\b"), "I")
    }

    private suspend fun detectLang(text: String, script: String, source: String): String {
        if (source == "en") return "en"
        val hasKana = text.any { it in '\u3040'..'\u30FF' }
        val hasHangul = text.any { it in '\uAC00'..'\uD7AF' || it in '\u1100'..'\u11FF' }
        val hasHan = text.any { it in '\u4E00'..'\u9FFF' }
        return when {
            hasKana -> "ja"
            hasHangul -> "ko"
            hasHan -> if (script == "ja") "ja" else "zh"
            else -> {
                val tag = try { langId.identifyLanguage(text).await() } catch (e: Exception) { "und" }
                if (tag == "und") "en" else tag.substringBefore('-')
            }
        }
    }

    private suspend fun translate(blocks: List<String>, lang: String, onStatus: suspend (String) -> Unit): List<String> {
        if (blocks.isEmpty()) return blocks
        val src = TranslateLanguage.fromLanguageTag(lang)
            ?: error("Bahasa '$lang' belum didukung penerjemah offline")
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.INDONESIAN)
                    .build()
            )
        }
        if (blocks.any { cache["$src|$it"] == null }) {
            onStatus("Menyiapkan model bahasa (diunduh sekali, perlu internet)…")
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            onStatus("Menerjemahkan…")
        }
        if (cache.size > 300) cache.clear()
        return blocks.map { t ->
            val key = "$src|$t"
            cache[key] ?: tr.translate(t).await().also { cache[key] = it }
        }
    }

    fun close() {
        try { latin.close() } catch (_: Exception) {}
        try { japanese.close() } catch (_: Exception) {}
        try { chinese.close() } catch (_: Exception) {}
        try { korean.close() } catch (_: Exception) {}
        try { langId.close() } catch (_: Exception) {}
        translators.values.forEach { try { it.close() } catch (_: Exception) {} }
        translators.clear()
    }
}
