package com.allinone.emulator.translate

import android.graphics.Bitmap
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Alur: layar game -> pra-pemrosesan (beberapa varian) -> OCR on-device (Latin/Jepang/Mandarin/Korea)
 * -> pilih hasil dengan skor kepercayaan terbaik -> deteksi bahasa -> terjemahan on-device ke Indonesia.
 */
class TranslationEngine {

    companion object {
        /** Kunci pengaturan -> label. "en" memaksa bahasa Inggris (lebih akurat untuk dialog pendek). */
        val SOURCES = listOf(
            "auto" to "Otomatis (Latin, Jepang, Mandarin, Korea)",
            "en" to "Inggris",
            "latin" to "Latin lain (Spanyol, Prancis, Jerman, dll)",
            "ja" to "Jepang",
            "zh" to "Mandarin",
            "ko" to "Korea"
        )

        private const val GOOD_SCORE = 35f      // cukup bagus -> berhenti mencoba varian lain (mode cepat)
        private const val RETRY_BELOW = 15f     // di bawah ini -> coba pengenal aksara lain
        private const val MIN_SCORE = 4f        // di bawah ini -> dianggap tidak ada teks
    }

    data class Block(val original: String, val translated: String)
    data class Result(val blocks: List<Block>, val sourceLabel: String, val translated: Boolean)

    private class Scored(val blocks: List<String>, val score: Float, val script: String)

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val japanese by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val chinese by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val korean by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val langId by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.3f).build())
    }
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>()

    private fun recognizer(script: String): TextRecognizer = when (script) {
        "ja" -> japanese
        "zh" -> chinese
        "ko" -> korean
        else -> latin
    }

    /** Pasangan (aksara, jumlah varian gambar yang dicoba). */
    private fun plan(source: String, thorough: Boolean): List<Pair<String, Int>> {
        val n = FramePrep.VARIANT_COUNT
        return when (source) {
            "en", "latin" -> listOf("latin" to n)
            "ja" -> listOf("ja" to n)
            "zh" -> listOf("zh" to n)
            "ko" -> listOf("ko" to n)
            else -> if (thorough) listOf("latin" to n, "ja" to n, "zh" to n, "ko" to n)
            else listOf("latin" to n, "ja" to 3, "zh" to 2, "ko" to 2)
        }
    }

    suspend fun run(
        frame: Bitmap,
        source: String,
        bottomOnly: Boolean,
        thorough: Boolean,
        onStatus: suspend (String) -> Unit
    ): Result? {
        val cropped = FramePrep.crop(frame, bottomOnly)
        val base = withContext(Dispatchers.Default) { FramePrep.normalizeSize(cropped) }
        val variants = FramePrep.Variants(base)
        try {
            var best: Scored? = null
            val steps = plan(source, thorough)
            outer@ for ((idx, step) in steps.withIndex()) {
                val (script, count) = step
                if (!thorough && idx > 0 && (best?.score ?: 0f) >= RETRY_BELOW) break
                if (idx > 0) onStatus("Mencoba pengenal aksara lain…")
                for (i in 0 until count) {
                    val bmp = withContext(Dispatchers.Default) { variants.get(i) }
                    val s = recognize(bmp, recognizer(script), script)
                    val cur = best
                    if (cur == null || s.score > cur.score) best = s
                    if (!thorough && (best?.score ?: 0f) >= GOOD_SCORE) break@outer
                }
            }
            val b = best ?: return null
            if (b.blocks.isEmpty() || b.score < MIN_SCORE) return null

            val blocks = b.blocks.map { cleanup(it) }.filter { it.isNotBlank() }
            if (blocks.isEmpty()) return null

            val lang = detectLang(blocks.joinToString("\n"), b.script, source)
            val label = Locale(lang).getDisplayLanguage(Locale("id")).replaceFirstChar { it.uppercase() }
            if (lang == "id") return Result(blocks.map { Block(it, it) }, label, false)

            val out = translate(blocks, lang, onStatus)
            return Result(blocks.indices.map { Block(blocks[it], out[it]) }, label, true)
        } finally {
            variants.release()
            if (base !== frame && !base.isRecycled) base.recycle()
            if (cropped !== frame && cropped !== base && !cropped.isRecycled) cropped.recycle()
        }
    }

    private suspend fun recognize(bmp: Bitmap, rec: TextRecognizer, script: String): Scored {
        val text = rec.process(InputImage.fromBitmap(bmp, 0)).await()
        val cjk = script != "latin"
        var score = 0f
        val blocks = ArrayList<String>()
        for (b in text.textBlocks) {
            val lines = ArrayList<String>()
            for (l in b.lines) {
                val t = l.text.trim()
                val letters = t.count { it.isLetterOrDigit() }
                if (letters == 0) continue
                val conf = l.confidence.let { if (it > 0f) it else 0.6f }
                if (conf < 0.3f) continue
                score += conf * letters
                lines += t
            }
            if (lines.isNotEmpty()) blocks += lines.joinToString(if (cjk) "" else " ")
        }
        return Scored(blocks, score, script)
    }

    /** Perbaikan kecil kesalahan OCR yang umum pada font retro. */
    private fun cleanup(s: String): String =
        s.replace(Regex("(?<=\\s|^)\\|(?=\\s|$)"), "I")
            .replace(Regex("(?<=\\p{L})\\|(?=\\p{L})"), "l")
            .replace(Regex("[ \\t]{2,}"), " ")
            .trim()

    private suspend fun detectLang(text: String, script: String, source: String): String {
        if (source == "en") return "en"
        val hasKana = text.any { it in '\u3040'..'\u30FF' }
        val hasHangul = text.any { it in '\uAC00'..'\uD7AF' || it in '\u1100'..'\u11FF' }
        val hasHan = text.any { it in '\u4E00'..'\u9FFF' }
        return when {
            hasKana -> "ja"
            hasHangul -> "ko"
            hasHan -> if (script == "ja") "ja" else "zh"
            else -> {
                val tag = try { langId.identifyLanguage(text).await() } catch (e: Exception) { "und" }
                if (tag == "und") "en" else tag.substringBefore('-')
            }
        }
    }

    private suspend fun translate(blocks: List<String>, lang: String, onStatus: suspend (String) -> Unit): List<String> {
        val src = TranslateLanguage.fromLanguageTag(lang)
            ?: error("Bahasa '$lang' belum didukung penerjemah offline")
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.INDONESIAN)
                    .build()
            )
        }
        if (blocks.any { cache["$src|$it"] == null }) {
            onStatus("Menyiapkan model bahasa (diunduh sekali, perlu internet)…")
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            onStatus("Menerjemahkan…")
        }
        if (cache.size > 300) cache.clear()
        return blocks.map { t ->
            val key = "$src|$t"
            cache[key] ?: tr.translate(t).await().also { cache[key] = it }
        }
    }

    fun close() {
        try { latin.close() } catch (_: Exception) {}
        try { japanese.close() } catch (_: Exception) {}
        try { chinese.close() } catch (_: Exception) {}
        try { korean.close() } catch (_: Exception) {}
        try { langId.close() } catch (_: Exception) {}
        translators.values.forEach { try { it.close() } catch (_: Exception) {} }
        translators.clear()
    }
}
