package com.allinone.emulator.data

import android.content.Context
import java.io.File

/**
 * BIOS / zip pendukung MAME yang dibundel di assets/bios/*.zip.
 * Disalin ke folder ROM arcade (tempat core MAME mencari zip induk/BIOS) bila belum ada atau ukurannya beda.
 * File-file ini disembunyikan dari daftar game dan tidak diproses ulang oleh normalizeArchive.
 */
object BiosInstaller {
    private const val ASSET_DIR = "bios"
    @Volatile private var names: Set<String>? = null

    /** Nama file (huruf kecil) BIOS bawaan, mis. "aleck64.zip". */
    fun bundledNames(ctx: Context): Set<String> =
        names ?: (ctx.assets.list(ASSET_DIR).orEmpty().map { it.lowercase() }.toSet()).also { names = it }

    fun isBundled(ctx: Context, fileName: String) = fileName.lowercase() in bundledNames(ctx)

    /** Panggil di thread latar. Mengembalikan jumlah file yang disalin/diperbarui. */
    fun install(ctx: Context): Int {
        val dest = Paths.roms(ctx, Console.ARCADE_MAME)
        var copied = 0
        for (n in ctx.assets.list(ASSET_DIR).orEmpty()) {
            try {
                // .zip di assets dikompres aapt, jadi openFd tidak bisa dipakai: hitung ukuran lewat stream
                val size = ctx.assets.open("$ASSET_DIR/$n").use { i ->
                    var total = 0L; val buf = ByteArray(64 * 1024)
                    while (true) { val r = i.read(buf); if (r < 0) break; total += r }
                    total
                }
                val t = File(dest, n)
                if (t.isFile && t.length() == size) continue
                val part = File(dest, "$n.part")
                ctx.assets.open("$ASSET_DIR/$n").use { i -> part.outputStream().use { o -> i.copyTo(o) } }
                if ((t.delete() || !t.exists()) && part.renameTo(t)) copied++ else part.delete()
            } catch (e: Throwable) { /* lanjut ke BIOS berikutnya */ }
        }
        return copied
    }
}
