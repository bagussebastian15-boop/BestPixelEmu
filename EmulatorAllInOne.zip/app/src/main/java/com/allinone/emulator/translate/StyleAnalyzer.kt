package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor

/** Gaya teks asli di game, dipakai supaya teks terjemahan terlihat serupa. */
data class TextStyle(
    val textColor: Int,
    val bgColor: Int,
    val outlineColor: Int,
    val hasOutline: Boolean,
    val bold: Boolean,
    val allCaps: Boolean,
    val busyBackground: Boolean,   // latar tidak polos (gambar/gradasi)
    val lineHeight: Float,
    val slant: Float = 0f          // kemiringan huruf miring (0 = tegak), mis. 0.25
)

object StyleAnalyzer {

    fun analyze(frame: Bitmap, box: RectF, lineHeight: Float, allCaps: Boolean): TextStyle {
        val x0 = floor(box.left).toInt().coerceIn(0, frame.width - 1)
        val y0 = floor(box.top).toInt().coerceIn(0, frame.height - 1)
        val x1 = ceil(box.right).toInt().coerceIn(x0 + 1, frame.width)
        val y1 = ceil(box.bottom).toInt().coerceIn(y0 + 1, frame.height)
        val w = x1 - x0
        val h = y1 - y0
        val px = IntArray(w * h)
        frame.getPixels(px, 0, w, x0, y0, w, h)

        // 1) warna latar = warna paling dominan
        val cnt = IntArray(4096)
        val sr = LongArray(4096); val sg = LongArray(4096); val sb = LongArray(4096)
        for (c in px) {
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
            cnt[k]++; sr[k] += r.toLong(); sg[k] += g.toLong(); sb[k] += b.toLong()
        }
        val bgKey = argMax(cnt)
        val bg = avg(sr, sg, sb, cnt, bgKey)
        val busy = cnt[bgKey].toFloat() / px.size < 0.5f

        // 2) warna teks = warna paling dominan di antara piksel yang jauh dari warna latar
        val cnt2 = IntArray(4096)
        val tr = LongArray(4096); val tg = LongArray(4096); val tb = LongArray(4096)
        val bgR = Color.red(bg); val bgG = Color.green(bg); val bgB = Color.blue(bg)
        var distant = 0
        for (c in px) {
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            if (abs(r - bgR) + abs(g - bgG) + abs(b - bgB) >= 120) {
                val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
                cnt2[k]++; tr[k] += r.toLong(); tg[k] += g.toLong(); tb[k] += b.toLong(); distant++
            }
        }
        val text: Int
        var outline = contrast(bg)
        var hasOutline = false
        if (distant < 8) {
            text = contrast(bg)
        } else {
            val tKey = argMax(cnt2)
            text = avg(tr, tg, tb, cnt2, tKey)
            // 3) outline/bayangan = warna ketiga yang cukup banyak dan beda terang dari teks
            var oKey = -1
            for (k in 0 until 4096) {
                if (k == tKey || cnt2[k] < cnt2[tKey] * 0.25f) continue
                val c = avg(tr, tg, tb, cnt2, k)
                val l = luma(c)
                if (l in minOf(luma(text), luma(bg))..maxOf(luma(text), luma(bg))) continue   // tepi anti-alias, bukan outline
                if (abs(l - luma(text)) >= 80 && (oKey < 0 || cnt2[k] > cnt2[oKey])) oKey = k
            }
            if (oKey >= 0) { outline = avg(tr, tg, tb, cnt2, oKey); hasOutline = true }
        }
        val bold = distant.toFloat() / px.size > 0.20f
        val slant = if (distant in 60..250000) detectSlant(px, w, h, bgR, bgG, bgB) else 0f
        // Teks redup (mis. efek memudar) diganti warna kontras supaya terjemahan tetap terbaca.
        val readable = if (abs(luma(text) - luma(bg)) < 90) contrast(bg) else text
        return TextStyle(readable, bg, outline, hasOutline, bold, allCaps, busy, lineHeight, slant)
    }

    /**
     * Huruf miring (italic): geser tiap baris piksel teks sedikit demi sedikit, lalu pilih pergeseran yang membuat
     * goresan tegak paling "lurus" (proyeksi kolom paling tajam). Hanya kemiringan ke kanan yang dicari.
     */
    private fun detectSlant(px: IntArray, w: Int, h: Int, bgR: Int, bgG: Int, bgB: Int): Float {
        val slopes = floatArrayOf(0f, 0.1f, 0.2f, 0.3f, 0.4f)
        val cols = w + (h * 0.5f).toInt() + 4
        val hist = Array(slopes.size) { IntArray(cols) }
        val mid = h / 2f
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val c = px[row + x]
                val d = abs(((c shr 16) and 0xFF) - bgR) + abs(((c shr 8) and 0xFF) - bgG) + abs((c and 0xFF) - bgB)
                if (d < 120) continue
                for (k in slopes.indices) {
                    val xs = (x + slopes[k] * (y - mid) + h * 0.25f).toInt()
                    if (xs in 0 until cols) hist[k][xs]++
                }
            }
        }
        var bestK = 0
        var bestE = -1.0
        val energy = DoubleArray(slopes.size)
        for (k in slopes.indices) {
            var e = 0.0
            for (v in hist[k]) e += v.toDouble() * v
            energy[k] = e
            if (e > bestE) { bestE = e; bestK = k }
        }
        return if (bestK > 0 && bestE > energy[0] * 1.08) slopes[bestK] else 0f
    }

    private fun argMax(a: IntArray): Int {
        var best = 0
        for (i in a.indices) if (a[i] > a[best]) best = i
        return best
    }

    private fun avg(r: LongArray, g: LongArray, b: LongArray, n: IntArray, k: Int): Int {
        val c = n[k].coerceAtLeast(1)
        return Color.rgb((r[k] / c).toInt(), (g[k] / c).toInt(), (b[k] / c).toInt())
    }

    private fun luma(c: Int) = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
    private fun contrast(c: Int) = if (luma(c) > 128) Color.BLACK else Color.WHITE
}
