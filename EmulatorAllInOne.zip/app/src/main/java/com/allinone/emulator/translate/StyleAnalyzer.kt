package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor

/** Gaya teks asli di game, dipakai supaya teks terjemahan terlihat serupa. */
data class TextStyle(
    val textColor: Int,
    val bgColor: Int,
    val outlineColor: Int,
    val hasOutline: Boolean,
    val bold: Boolean,
    val allCaps: Boolean,
    val busyBackground: Boolean,   // latar tidak polos (gambar/gradasi)
    val lineHeight: Float
)

object StyleAnalyzer {

    fun analyze(frame: Bitmap, box: RectF, lineHeight: Float, allCaps: Boolean): TextStyle {
        val x0 = floor(box.left).toInt().coerceIn(0, frame.width - 1)
        val y0 = floor(box.top).toInt().coerceIn(0, frame.height - 1)
        val x1 = ceil(box.right).toInt().coerceIn(x0 + 1, frame.width)
        val y1 = ceil(box.bottom).toInt().coerceIn(y0 + 1, frame.height)
        val w = x1 - x0
        val h = y1 - y0
        val px = IntArray(w * h)
        frame.getPixels(px, 0, w, x0, y0, w, h)

        // 1) warna latar = warna paling dominan
        val cnt = IntArray(4096)
        val sr = LongArray(4096); val sg = LongArray(4096); val sb = LongArray(4096)
        for (c in px) {
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
            cnt[k]++; sr[k] += r.toLong(); sg[k] += g.toLong(); sb[k] += b.toLong()
        }
        val bgKey = argMax(cnt)
        val bg = avg(sr, sg, sb, cnt, bgKey)
        val busy = cnt[bgKey].toFloat() / px.size < 0.5f

        // 2) warna teks = warna paling dominan di antara piksel yang jauh dari warna latar
        val cnt2 = IntArray(4096)
        val tr = LongArray(4096); val tg = LongArray(4096); val tb = LongArray(4096)
        val bgR = Color.red(bg); val bgG = Color.green(bg); val bgB = Color.blue(bg)
        var distant = 0
        for (c in px) {
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            if (abs(r - bgR) + abs(g - bgG) + abs(b - bgB) >= 120) {
                val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
                cnt2[k]++; tr[k] += r.toLong(); tg[k] += g.toLong(); tb[k] += b.toLong(); distant++
            }
        }
        val text: Int
        var outline = contrast(bg)
        var hasOutline = false
        if (distant < 8) {
            text = contrast(bg)
        } else {
            val tKey = argMax(cnt2)
            text = avg(tr, tg, tb, cnt2, tKey)
            // 3) outline/bayangan = warna ketiga yang cukup banyak dan beda terang dari teks
            var oKey = -1
            for (k in 0 until 4096) {
                if (k == tKey || cnt2[k] < cnt2[tKey] * 0.25f) continue
                val c = avg(tr, tg, tb, cnt2, k)
                if (abs(luma(c) - luma(text)) >= 80 && (oKey < 0 || cnt2[k] > cnt2[oKey])) oKey = k
            }
            if (oKey >= 0) { outline = avg(tr, tg, tb, cnt2, oKey); hasOutline = true }
        }
        val bold = distant.toFloat() / px.size > 0.20f
        return TextStyle(text, bg, outline, hasOutline, bold, allCaps, busy, lineHeight)
    }

    private fun argMax(a: IntArray): Int {
        var best = 0
        for (i in a.indices) if (a[i] > a[best]) best = i
        return best
    }

    private fun avg(r: LongArray, g: LongArray, b: LongArray, n: IntArray, k: Int): Int {
        val c = n[k].coerceAtLeast(1)
        return Color.rgb((r[k] / c).toInt(), (g[k] / c).toInt(), (b[k] / c).toInt())
    }

    private fun luma(c: Int) = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
    private fun contrast(c: Int) = if (luma(c) > 128) Color.BLACK else Color.WHITE
}
