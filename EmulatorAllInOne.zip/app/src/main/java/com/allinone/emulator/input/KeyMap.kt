package com.allinone.emulator.input

import android.content.Context
import android.view.KeyEvent

/**
 * Peta tombol per perangkat gamepad (berdasarkan descriptor), jadi controller yang dicolok
 * langsung dikenali dan pengaturan tiap controller tersimpan terpisah.
 *
 * Catatan layout libretro: tombol Android BUTTON_A (bawah) = "B" retropad, BUTTON_B (kanan) = "A".
 */
object KeyMap {
    val logical: List<Pair<String, Int>> = listOf(
        "D-pad atas" to KeyEvent.KEYCODE_DPAD_UP,
        "D-pad bawah" to KeyEvent.KEYCODE_DPAD_DOWN,
        "D-pad kiri" to KeyEvent.KEYCODE_DPAD_LEFT,
        "D-pad kanan" to KeyEvent.KEYCODE_DPAD_RIGHT,
        "A (kanan)" to KeyEvent.KEYCODE_BUTTON_B,
        "B (bawah)" to KeyEvent.KEYCODE_BUTTON_A,
        "X (atas)" to KeyEvent.KEYCODE_BUTTON_Y,
        "Y (kiri)" to KeyEvent.KEYCODE_BUTTON_X,
        "L" to KeyEvent.KEYCODE_BUTTON_L1,
        "R" to KeyEvent.KEYCODE_BUTTON_R1,
        "L2" to KeyEvent.KEYCODE_BUTTON_L2,
        "R2" to KeyEvent.KEYCODE_BUTTON_R2,
        "Start" to KeyEvent.KEYCODE_BUTTON_START,
        "Select" to KeyEvent.KEYCODE_BUTTON_SELECT
    )

    private fun p(c: Context) = c.getSharedPreferences("keymap", Context.MODE_PRIVATE)

    /** Tombol fisik -> tombol logis. Tanpa pengaturan, tombol dipakai apa adanya. */
    fun resolve(c: Context, device: String, physical: Int): Int =
        p(c).getInt("$device|$physical", physical)

    fun bind(c: Context, device: String, physical: Int, logical: Int) {
        val prefs = p(c)
        val e = prefs.edit()
        prefs.all.filter { it.key.startsWith("$device|") && it.value == logical }.keys.forEach { e.remove(it) }
        e.putInt("$device|$physical", logical).apply()
    }

    fun clearAll(c: Context) = p(c).edit().clear().apply()
}
