package com.allinone.emulator.translate

import android.graphics.Bitmap
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tabel font yang dipelajari sendiri. Font game selalu sama: huruf "し" di mana pun punya bentuk piksel yang sama.
 * Tiap huruf pada baris dialog dipotong sendiri, bentuknya diubah jadi tanda (12x12 bit), lalu dicatat huruf apa saja
 * yang dibaca ML Kit untuk bentuk itu. Bentuk yang sudah sering dibaca sama dikenali langsung dari tabel, dan bacaan
 * ML Kit yang menyimpang dari mayoritas dikoreksi. Makin lama dimainkan makin akurat. Disimpan di font_bank.txt
 * (hapus file itu untuk mengulang dari awal).
 */
class GlyphBank(val file: File) {

    private class Entry(val bits: LongArray, val hq: Int, val wq: Int, val counts: HashMap<Char, Int> = HashMap()) {
        fun total() = counts.values.sum()
    }
    private class Sig(val bits: LongArray, val hq: Int, val wq: Int)

    private val entries = ArrayList<Entry>()
    private var dirty = false
    var learned = 0; private set
    var corrected = 0; private set

    init { load() }

    val size: Int get() = entries.size

    // ------------------------------------------------------------------ penyimpanan

    private fun load() {
        try {
            if (!file.exists()) return
            for (line in file.readLines()) {
                val p = line.split('\t')
                if (p.size < 4 || p[0].length != 48) continue
                val bits = LongArray(3) { java.lang.Long.parseUnsignedLong(p[0].substring(it * 16, it * 16 + 16), 16) }
                val e = Entry(bits, p[1].toInt(), p[2].toInt())
                for (kv in p[3].split(',')) {
                    val i = kv.lastIndexOf(':')
                    if (i < 1) continue
                    e.counts[kv[0]] = kv.substring(i + 1).toIntOrNull() ?: continue
                }
                if (e.counts.isNotEmpty()) entries += e
            }
        } catch (_: Exception) { entries.clear() }
    }

    fun saveIfDirty() {
        if (!dirty) return
        try {
            if (entries.size > 4000) {
                entries.sortByDescending { it.total() }
                while (entries.size > 3500) entries.removeAt(entries.size - 1)
            }
            val sb = StringBuilder()
            for (e in entries) {
                sb.append(e.bits.joinToString("") { String.format("%016x", it) }).append('\t')
                    .append(e.hq).append('\t').append(e.wq).append('\t')
                    .append(e.counts.entries.joinToString(",") { "${it.key}:${it.value}" }).append('\n')
            }
            file.writeText(sb.toString())
            dirty = false
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ tanda bentuk huruf

    private fun hamming(a: LongArray, b: LongArray) =
        java.lang.Long.bitCount(a[0] xor b[0]) + java.lang.Long.bitCount(a[1] xor b[1]) + java.lang.Long.bitCount(a[2] xor b[2])

    private fun nearest(s: Sig, maxDist: Int): Entry? {
        var best: Entry? = null
        var bd = Int.MAX_VALUE
        for (e in entries) {
            if (abs(e.hq - s.hq) > 1 || abs(e.wq - s.wq) > 1) continue
            val d = hamming(e.bits, s.bits)
            if (d <= maxDist && d < bd) { bd = d; best = e }
        }
        return best
    }

    /** Huruf yang dikenali tabel untuk bentuk ini bila sudah cukup yakin (>= 4 kali terlihat, >= 75% sama). */
    private fun recall(s: Sig): Char? {
        val e = nearest(s, 8) ?: return null
        val t = e.total()
        if (t < 4) return null
        val top = e.counts.maxByOrNull { it.value } ?: return null
        return if (top.value >= t * 0.75f) top.key else null
    }

    private fun learn(s: Sig, ch: Char) {
        val e = nearest(s, 4) ?: Entry(s.bits, s.hq, s.wq).also { entries += it }
        e.counts[ch] = (e.counts[ch] ?: 0) + 1
        dirty = true
        learned++
    }

    // ------------------------------------------------------------------ pemotongan huruf

    private val SMALL = "ッっゃゅょャュョァィゥェォ、。！？"
    private val ALLOWED_PUNCT = "ー、。！？"

    private fun learnable(c: Char): Boolean =
        c in '\u3041'..'\u3096' || c in '\u30A1'..'\u30FA' || c in '\u4E00'..'\u9FFF' || c in ALLOWED_PUNCT

    /**
     * Proses satu baris dialog Jepang: potong per huruf, koreksi huruf yang menyimpang dari tabel, lalu catat bentuk
     * ke tabel. Bila jumlah huruf tidak cocok dengan potongan gambar (huruf menempel, tanda baca hilang, dll),
     * baris dilewati supaya tabel tidak tercemar. Mengembalikan teks (mungkin sudah dikoreksi).
     */
    fun process(base: Bitmap, rect: android.graphics.Rect, text0: String): String {
        val text = text0.replace(Regex("\\s+"), "")
        val n = text.length
        if (n < 2 || n > 40 || text.any { !learnable(it) }) return text0

        val lh = rect.height()
        if (lh < 12) return text0
        val pad = max(2, (lh * 0.12f).toInt())
        val x0 = (rect.left - pad).coerceIn(0, base.width - 1)
        val y0 = (rect.top - pad).coerceIn(0, base.height - 1)
        val x1 = (rect.right + pad).coerceIn(x0 + 1, base.width)
        val y1 = (rect.bottom + pad).coerceIn(y0 + 1, base.height)
        val w = x1 - x0
        val h = y1 - y0
        if (w < 8 || h < 8) return text0
        val px = IntArray(w * h)
        base.getPixels(px, 0, w, x0, y0, w, h)
        val ink = inkMask(px, w, h) ?: return text0

        // kolom berisi tinta -> segmen
        val col = IntArray(w)
        for (y in 0 until h) for (x in 0 until w) if (ink[y * w + x]) col[x]++
        val segs = ArrayList<IntArray>()
        var x = 0
        while (x < w) {
            if (col[x] < 2) { x++; continue }
            val s = x
            while (x < w && col[x] >= 2) x++
            segs += intArrayOf(s, x - 1)
        }
        val m = segs.size
        if (m < n || m > n * 4) return text0

        // Petakan n huruf ke m segmen berurutan (satu huruf bisa terdiri dari beberapa segmen, mis. い, こ):
        // pilih pembagian dengan lebar huruf paling wajar (lebar ~ tinggi baris; huruf kecil/tanda baca ~ setengah).
        val inf = 1e9
        val dp = Array(n + 1) { DoubleArray(m + 1) { inf } }
        val from = Array(n + 1) { IntArray(m + 1) { -1 } }
        dp[0][0] = 0.0
        for (i in 1..n) for (j in i..m) for (k in max(i - 1, j - 4)..(j - 1)) {
            if (dp[i - 1][k] >= inf) continue
            val span = (segs[j - 1][1] - segs[k][0] + 1).toDouble() / lh
            val exp = if (text[i - 1] in SMALL) 0.45 else 0.9
            val c = dp[i - 1][k] + ((span - exp) / 0.45).let { it * it }
            if (c < dp[i][j]) { dp[i][j] = c; from[i][j] = k }
        }
        if (dp[n][m] >= inf || dp[n][m] / n > 0.8) return text0
        val groups = arrayOfNulls<IntArray>(n)
        var j = m
        for (i in n downTo 1) {
            val k = from[i][j]
            groups[i - 1] = intArrayOf(segs[k][0], segs[j - 1][1])
            j = k
        }

        val out = StringBuilder(text)
        for (i in 0 until n) {
            val g = groups[i] ?: return text0
            val sig = signature(ink, w, h, g[0], g[1], lh) ?: continue
            val known = recall(sig)
            var ch = text[i]
            if (known != null && known != ch) { ch = known; out.setCharAt(i, known); corrected++ }
            learn(sig, ch)
        }
        return out.toString()
    }

    /** Tinta = piksel teks. Kutub (terang/gelap) dipilih yang menghasilkan 2%-50% piksel; teks selalu minoritas. */
    private fun inkMask(px: IntArray, w: Int, h: Int): BooleanArray? {
        val mn = IntArray(px.size)
        val mx = IntArray(px.size)
        val hist = IntArray(256)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            mn[i] = min(r, min(g, b)); mx[i] = max(r, max(g, b))
            hist[mn[i]]++
        }
        var acc = 0
        var med = 127
        for (v in 0..255) { acc += hist[v]; if (acc >= px.size / 2) { med = v; break } }
        val thrL = (med + (255 - med) * 0.4f).toInt().coerceIn(165, 225)
        val thrD = (med * 0.45f).toInt().coerceIn(40, 110)
        var nl = 0
        var nd = 0
        for (i in px.indices) { if (mn[i] >= thrL) nl++; if (mx[i] <= thrD) nd++ }
        val fl = nl.toFloat() / px.size
        val fd = nd.toFloat() / px.size
        val okL = fl in 0.02f..0.5f
        val okD = fd in 0.02f..0.5f
        val light = when {
            okL && okD -> fl >= fd
            okL -> true
            okD -> false
            else -> return null
        }
        return BooleanArray(px.size) { if (light) mn[it] >= thrL else mx[it] <= thrD }
    }

    /** Tanda bentuk: kotak pas tinta dalam rentang kolom [xa, xb], dibagi 12x12; sel dengan >= 30% tinta = 1. */
    private fun signature(ink: BooleanArray, w: Int, h: Int, xa: Int, xb: Int, lh: Int): Sig? {
        var top = h; var bottom = -1; var left = w; var right = -1
        for (y in 0 until h) for (x in xa..xb) if (ink[y * w + x]) {
            if (y < top) top = y; if (y > bottom) bottom = y
            if (x < left) left = x; if (x > right) right = x
        }
        if (bottom < 0) return null
        val bw = right - left + 1
        val bh = bottom - top + 1
        if (bw < 3 || bh < 3) return null
        val bits = LongArray(3)
        for (gy in 0 until 12) for (gx in 0 until 12) {
            val ya = top + gy * bh / 12
            val yb = max(ya + 1, top + (gy + 1) * bh / 12)
            val xa2 = left + gx * bw / 12
            val xb2 = max(xa2 + 1, left + (gx + 1) * bw / 12)
            var on = 0
            var all = 0
            for (y in ya until min(yb, h)) for (x in xa2 until min(xb2, w)) { all++; if (ink[y * w + x]) on++ }
            if (all > 0 && on >= all * 0.3f) {
                val idx = gy * 12 + gx
                bits[idx / 64] = bits[idx / 64] or (1L shl (idx % 64))
            }
        }
        return Sig(bits, (bh.toFloat() / lh * 4).roundToInt().coerceIn(0, 6), (bw.toFloat() / lh * 4).roundToInt().coerceIn(0, 6))
    }
}
