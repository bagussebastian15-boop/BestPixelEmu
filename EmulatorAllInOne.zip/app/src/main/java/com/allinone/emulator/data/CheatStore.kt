package com.allinone.emulator.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Cheat(val name: String, val code: String, var enabled: Boolean)

/** Cheat disimpan per game (JSON). Format kode mengikuti core (Game Genie / GameShark / Action Replay). */
object CheatStore {
    private fun file(ctx: Context, game: Game) = File(Paths.cheats(ctx), "${game.title}.json")

    fun load(ctx: Context, game: Game): MutableList<Cheat> {
        val f = file(ctx, game)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Cheat(o.getString("name"), o.getString("code"), o.optBoolean("enabled", false))
            }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(ctx: Context, game: Game, cheats: List<Cheat>) {
        val arr = JSONArray()
        cheats.forEach {
            arr.put(JSONObject().put("name", it.name).put("code", it.code).put("enabled", it.enabled))
        }
        file(ctx, game).writeText(arr.toString())
    }
}
