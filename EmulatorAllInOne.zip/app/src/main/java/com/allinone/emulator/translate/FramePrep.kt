package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import androidx.annotation.RequiresApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Menangkap isi layar game (GLSurfaceView) tanpa menyertakan tombol/overlay. Butuh Android 7.0+. */
object FrameCapture {
    fun supported() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    suspend fun grab(view: SurfaceView): Bitmap? {
        if (!supported() || view.width <= 0 || view.height <= 0) return null
        return grabN(view)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private suspend fun grabN(view: SurfaceView): Bitmap? = suspendCancellableCoroutine { cont ->
        val bmp = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        try {
            PixelCopy.request(
                view, bmp,
                PixelCopy.OnPixelCopyFinishedListener { r ->
                    if (cont.isActive) cont.resume(if (r == PixelCopy.SUCCESS) bmp else null)
                },
                Handler(Looper.getMainLooper())
            )
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(null)
        }
    }
}

/**
 * Pra-pemrosesan supaya teks piksel/buram lebih mudah dibaca OCR:
 * ukuran dinormalkan, kontras diregangkan, ditajamkan, dibalik, dibinerkan (Otsu), serta pemisahan teks terang/gelap lewat warna (untuk teks putih di kotak biru muda).
 */
object FramePrep {
    private const val MAX_SIDE = 1600
    private const val MIN_SIDE = 1100
    const val VARIANT_COUNT = 15

    /** Urutan percobaan varian OCR: 13/14 = HANYA tulisan (latar dihitamkan / diputihkan), lalu varian huruf ber-outline (11, 2, 3, 12). */
    val ORDER = intArrayOf(13, 14, 0, 1, 11, 2, 3, 12, 4, 5, 6, 7, 8, 9, 10)
    private const val INK_LIGHT = 0
    private const val INK_DARK = 1
    private const val INK_COOL = 2
    private const val INK_OUTLINE = 3
    private const val INK_OUTLINE_FILL = 4   // garis tepi abu-biru + bagian dalam goresan yang tipis diisi (huruf perak ber-outline)
    private const val INK_OUTLINE_THIN = 5   // hanya garis tepi tipis (tanpa bayangan jatuh) untuk huruf ber-outline tebal

    /** Kemiringan (shear) yang dikoreksi pada varian huruf miring; 0 = bukan varian miring. */
    fun shearOf(variant: Int): Float = when (variant) { 6 -> 0.25f; 7 -> 0.45f; else -> 0f }

    fun crop(src: Bitmap, bottomOnly: Boolean): Bitmap {
        if (!bottomOnly) return src
        val h = (src.height * 0.45f).toInt().coerceAtLeast(1)
        return Bitmap.createBitmap(src, 0, src.height - h, src.width, h)
    }

    fun normalizeSize(src: Bitmap): Bitmap {
        val longSide = max(src.width, src.height)
        val scale = when {
            longSide > MAX_SIDE -> MAX_SIDE.toFloat() / longSide
            longSide < MIN_SIDE -> MIN_SIDE.toFloat() / longSide
            else -> 1f
        }
        if (scale == 1f) return src
        return Bitmap.createScaledBitmap(
            src,
            (src.width * scale).roundToInt().coerceAtLeast(1),
            (src.height * scale).roundToInt().coerceAtLeast(1),
            true
        )
    }

    /** Varian dibuat malas (hanya saat dibutuhkan) agar hemat RAM dan waktu. */
    class Variants(private val base: Bitmap) {
        private val w = base.width
        private val h = base.height
        private val cache = arrayOfNulls<Bitmap>(VARIANT_COUNT)
        private var stretched: IntArray? = null
        private var sharpened: IntArray? = null

        fun get(i: Int): Bitmap {
            cache[i]?.let { return it }
            val b = build(i)
            cache[i] = b
            return b
        }

        fun release() {
            for (b in cache) if (b != null && b !== base && !b.isRecycled) b.recycle()
        }

        private fun gray(): IntArray = stretched ?: stretch(grayOf(base)).also { stretched = it }
        private fun sharp(): IntArray = sharpened ?: sharpen(gray(), w, h).also { sharpened = it }

        private fun build(i: Int): Bitmap = when (i) {
            0 -> base                                       // warna asli
            1 -> inkMask(INK_LIGHT)                         // teks terang (putih) dipisah lewat warna -> hitam di atas putih
            2 -> inkMask(INK_OUTLINE)                       // garis tepi/bayangan abu-biru huruf -> huruf ber-outline hitam di atas putih
            3 -> inkMask(INK_COOL)                          // teks putih kebiruan di atas gambar hangat/krem (cutscene)
            4 -> toBitmap(gray(), w, h, false)              // abu-abu, kontras diregangkan
            5 -> toBitmap(sharp(), w, h, false)             // + dipertajam
            6 -> shearBitmap(sharp(), w, h, shearOf(6))      // huruf miring ringan diluruskan
            7 -> shearBitmap(sharp(), w, h, shearOf(7))      // huruf miring kuat diluruskan
            8 -> toBitmap(sharp(), w, h, true)              // dibalik
            9 -> toBitmap(otsu(sharp()), w, h, false)       // hitam-putih (Otsu)
            13 -> isolatedBitmap(false)                     // hanya tulisan: huruf putih di atas latar hitam polos
            14 -> isolatedBitmap(true)                      // hanya tulisan: huruf hitam di atas latar putih polos
            11 -> inkMask(INK_OUTLINE_FILL)                 // huruf perak ber-outline (judul cutscene): outline + isi goresan
            12 -> inkMask(INK_OUTLINE_THIN)                 // outline saja, tanpa dilasi
            else -> inkMask(INK_DARK)                       // teks gelap dipisah lewat warna -> hitam di atas putih
        }

        /**
         * Pisahkan teks dari latar lewat WARNA, bukan lewat keabuan: teks putih di kotak biru muda (GBA) hampir
         * sama terangnya dengan latar sehingga varian abu-abu/Otsu gagal. Teks terang = piksel yang SEMUA kanal
         * warnanya tinggi (min R,G,B); teks gelap = piksel yang semua kanalnya rendah (max R,G,B). Ambang
         * mengikuti median gambar. Hasilnya ditebalkan 1 piksel (goresan huruf piksel sangat tipis), lalu
         * digambar hitam di atas putih supaya mudah dibaca OCR.
         */
        private fun inkMask(kind: Int): Bitmap {
            val light = kind != INK_DARK
            val px = IntArray(w * h)
            base.getPixels(px, 0, w, 0, 0, w, h)
            val ch = IntArray(w * h)
            val hist = IntArray(256)
            for (k in px.indices) {
                val c = px[k]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val v = if (light) min(r, min(g, b)) else max(r, max(g, b))
                // INK_COOL: hanya piksel terang yang biru-nya tidak kalah dari merah (teks putih/lilac); krem/sepia (R > B) ditolak
                ch[k] = when (kind) {
                    INK_COOL -> if (b < 200 || b < r - 6) 0 else b
                    // Outline/bayangan huruf font game berwarna abu-biru (B > R, tidak terlalu gelap/terang). Warna ini
                    // jarang ada pada gambar latar (sepia/krem/hitam) sehingga bentuk huruf tetap utuh meski isinya
                    // sewarna latar.
                    INK_OUTLINE -> if (b - r >= 8 && min(r, min(g, b)) >= 100 && max(r, max(g, b)) <= 205) 255 else 0
                    // Huruf perak/krom: isi terang bergradasi (~190-240) dikelilingi outline abu-biru yang lebih gelap (~110-175).
                    INK_OUTLINE_FILL, INK_OUTLINE_THIN ->
                        if (b - r >= 8 && min(r, min(g, b)) >= 90 && max(r, max(g, b)) <= 175) 255 else 0
                    else -> v
                }
                hist[ch[k]]++
            }
            var acc = 0
            var med = 127
            for (v in 0..255) { acc += hist[v]; if (acc >= ch.size / 2) { med = v; break } }
            val thr = if (kind == INK_OUTLINE || kind == INK_OUTLINE_FILL || kind == INK_OUTLINE_THIN) 128
                      else if (kind == INK_COOL) 205
                      else if (light) (med + (255 - med) * 0.4f).toInt().coerceIn(165, 225)
                      else (med * 0.45f).toInt().coerceIn(40, 110)
            val ink = BooleanArray(w * h) { if (light) ch[it] >= thr else ch[it] <= thr }
            if (kind == INK_OUTLINE_THIN) return maskBitmap(ink)
            // Tebalkan 1 piksel (dilasi 3x3 terpisah: horizontal lalu vertikal)
            val hor = BooleanArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    hor[row + x] = ink[row + x] || (x > 0 && ink[row + x - 1]) || (x < w - 1 && ink[row + x + 1])
                }
            }
            val on = BooleanArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    on[row + x] = hor[row + x] || (y > 0 && hor[row - w + x]) || (y < h - 1 && hor[row + w + x])
                }
            }
            // INK_COOL (cutscene: teks putih di atas gambar terang) dibiarkan utuh: bagian teks yang menempel pada
            // area putih tidak bisa dipisahkan lewat warna, tetapi huruf di bagian lain tetap bersih dan terbaca.
            if (kind == INK_OUTLINE_FILL) fillThinHoles(on, max(3, (w * 0.0045f).toInt()))
            val glyphH = if (kind == INK_COOL || kind == INK_OUTLINE || kind == INK_OUTLINE_FILL) 0 else dropBigBlobs(on)
            if (glyphH > 0) {
                peelAreas(on, (glyphH * 0.35f).toInt().coerceIn(4, 40))
                dropBigBlobs(on)
            }
            val out = IntArray(w * h)
            for (k in out.indices) out[k] = if (on[k]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        }


        // ------------------------------------------------------------------ isolasi tulisan

        private var isoMask: BooleanArray? = null
        private var lastAccepted = 0

        private fun isolated(): BooleanArray = isoMask ?: computeIsolated().also { isoMask = it }

        private fun isolatedBitmap(invert: Boolean): Bitmap {
            val on = isolated()
            val fg = if (invert) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            val bg = if (invert) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
            val out = IntArray(w * h)
            for (k in out.indices) out[k] = if (on[k]) fg else bg
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        }

        private fun thicken(src: BooleanArray): BooleanArray {
            val hor = BooleanArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) hor[row + x] = src[row + x] || (x > 0 && src[row + x - 1]) || (x < w - 1 && src[row + x + 1])
            }
            val on = BooleanArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) on[row + x] = hor[row + x] || (y > 0 && hor[row - w + x]) || (y < h - 1 && hor[row + w + x])
            }
            return on
        }

        /**
         * Pisahkan TULISAN dari seluruh isi gambar (wajah, efek, latar terang/ramai): semua yang bukan huruf dijadikan
         * polos. Huruf dicari lewat warna (isi putih/terang; outline abu-biru dengan bagian dalam diisi; huruf gelap
         * hanya bila dua cara tadi tidak menemukan apa-apa), lalu hanya gumpalan berukuran huruf yang sebaris
         * (minimal 3 gumpalan, atau satu kata panjang) yang dipertahankan. Wajah, rambut, kilau, dan garis kotak dibuang.
         */
        private fun computeIsolated(): BooleanArray {
            val n = w * h
            val px = IntArray(n)
            base.getPixels(px, 0, w, 0, 0, w, h)
            val light = BooleanArray(n)
            val outline = BooleanArray(n)
            val dark = BooleanArray(n)
            for (k in 0 until n) {
                val c = px[k]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val mn = min(r, min(g, b))
                val mx = max(r, max(g, b))
                light[k] = mn >= 175 && mx - mn <= 55
                outline[k] = b - r >= 8 && mn >= 90 && mx <= 175
                dark[k] = mx <= 80
            }
            val result = BooleanArray(n)
            var found = false
            // 1) Isi huruf yang terang: paling tajam bila latarnya tidak ikut terang (kotak dialog berwarna).
            val lm = channelRows(thicken(light), 14f)
            val lightCount = lastAccepted
            if (lm != null) { for (k in 0 until n) if (lm[k]) result[k] = true; found = true }
            // 2) Hanya bila huruf terang sedikit terbaca (judul perak di atas latar putih/efek): pakai outline abu-biru
            //    dengan bagian dalam goresan diisi. Bila isi terang sudah cukup, outline tidak dipakai karena menebalkan huruf.
            if (lightCount < 12) {
                val ol = thicken(outline)
                fillThinHoles(ol, max(3, (w * 0.0045f).toInt()))
                val om = channelRows(ol, 40f)
                if (om != null) { for (k in 0 until n) if (om[k]) result[k] = true; found = true }
            }
            if (!found) {
                val dm = channelRows(thicken(dark), 14f)
                if (dm != null) for (k in 0 until n) if (dm[k]) result[k] = true
            }
            return result
        }

        /** Satu kanal warna -> hanya gumpalan seukuran huruf yang membentuk baris teks; null bila tidak ada baris. */
        private fun channelRows(on: BooleanArray, longMax: Float): BooleanArray? {
            val n = w * h
            val lab = IntArray(n)
            val stack = IntArray(n)
            val bx0 = ArrayList<Int>(); val by0 = ArrayList<Int>()
            val bx1 = ArrayList<Int>(); val by1 = ArrayList<Int>(); val cnts = ArrayList<Int>()
            var id = 0
            for (s0 in 0 until n) {
                if (!on[s0] || lab[s0] != 0) continue
                id++
                var sp = 0
                stack[sp++] = s0; lab[s0] = id
                var minX = w; var maxX = 0; var minY = h; var maxY = 0; var cnt = 0
                while (sp > 0) {
                    val q = stack[--sp]
                    cnt++
                    val x = q % w
                    val y = q / w
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    for (dy in -1..1) {
                        val ny = y + dy
                        if (ny < 0 || ny >= h) continue
                        for (dx in -1..1) {
                            val nx = x + dx
                            if (nx < 0 || nx >= w) continue
                            val q2 = ny * w + nx
                            if (on[q2] && lab[q2] == 0) { lab[q2] = id; stack[sp++] = q2 }
                        }
                    }
                }
                bx0 += minX; bx1 += maxX; by0 += minY; by1 += maxY; cnts += cnt
            }
            lastAccepted = 0
            if (id == 0) return null
            val maxH = 0.18f * h
            val cand = (1..id).filter { i ->
                val bh = by1[i - 1] - by0[i - 1] + 1
                val bw = bx1[i - 1] - bx0[i - 1] + 1
                bh >= 10 && bh <= maxH && bw <= longMax * bh && cnts[i - 1] >= 30
            }.sortedBy { i -> by0[i - 1] + by1[i - 1] }
            if (cand.isEmpty()) return null

            class Row(var top: Int, var bot: Int, val ids: MutableList<Int>)
            val rows = ArrayList<Row>()
            for (i in cand) {
                val t = by0[i - 1]
                val b = by1[i - 1] + 1
                val bh = b - t
                var placed = false
                for (r in rows) {
                    val ov = min(r.bot, b) - max(r.top, t)
                    val rh = r.bot - r.top
                    val hr = bh.toFloat() / max(1, rh)
                    if (ov >= 0.6f * min(rh, bh) && hr > 0.4f && hr < 2.5f) {
                        r.ids += i; r.top = min(r.top, t); r.bot = max(r.bot, b); placed = true; break
                    }
                }
                if (!placed) rows += Row(t, b, mutableListOf(i))
            }
            val accepted = BooleanArray(id + 1)
            var any = false
            for (r in rows) {
                val hs = r.ids.map { by1[it - 1] - by0[it - 1] + 1 }.sorted()
                val med = hs[hs.size / 2]
                val ids2 = r.ids.filter { i ->
                    val bh = by1[i - 1] - by0[i - 1] + 1
                    bh >= 0.5f * med && bh <= 1.7f * med
                }
                val wordLevel = ids2.any { i -> (bx1[i - 1] - bx0[i - 1] + 1) >= 4 * (by1[i - 1] - by0[i - 1] + 1) }
                if (ids2.size >= 3 || wordLevel) { for (i in ids2) accepted[i] = true; any = true; lastAccepted += ids2.size }
            }
            if (!any) return null
            return BooleanArray(n) { lab[it] > 0 && accepted[lab[it]] }
        }

        private fun maskBitmap(on: BooleanArray): Bitmap {
            val out = IntArray(w * h)
            for (k in out.indices) out[k] = if (on[k]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        }

        /**
         * Isi lubang kecil yang tertutup rapat oleh topeng (bagian dalam goresan huruf ber-outline) supaya huruf menjadi
         * hitam padat. Lubang yang tipis (tebal <= 2r) diisi; lubang besar (rongga huruf seperti pada ゆ, ま, 晶) dibiarkan.
         * Lubang yang tersambung ke tepi gambar tidak pernah diisi.
         */
        private fun fillThinHoles(on: BooleanArray, r: Int) {
            val n = w * h
            val comp = IntArray(n)            // 0 = belum, id komponen latar (piksel !on)
            val stack = IntArray(n)
            var id = 0
            val compSize = ArrayList<Int>()
            val touchesEdge = ArrayList<Boolean>()
            compSize += 0; touchesEdge += true
            for (s0 in 0 until n) {
                if (on[s0] || comp[s0] != 0) continue
                id++
                var sp = 0
                var size = 0
                var edge = false
                stack[sp++] = s0; comp[s0] = id
                while (sp > 0) {
                    val q = stack[--sp]
                    size++
                    val x = q % w
                    val y = q / w
                    if (x == 0 || y == 0 || x == w - 1 || y == h - 1) edge = true
                    if (x > 0 && !on[q - 1] && comp[q - 1] == 0) { comp[q - 1] = id; stack[sp++] = q - 1 }
                    if (x < w - 1 && !on[q + 1] && comp[q + 1] == 0) { comp[q + 1] = id; stack[sp++] = q + 1 }
                    if (y > 0 && !on[q - w] && comp[q - w] == 0) { comp[q - w] = id; stack[sp++] = q - w }
                    if (y < h - 1 && !on[q + w] && comp[q + w] == 0) { comp[q + w] = id; stack[sp++] = q + w }
                }
                compSize += size; touchesEdge += edge
            }
            if (id == 0) return
            // Ketebalan lubang = jarak terjauh ke piksel "on" (transformasi jarak pendek 2 sapuan, jarak kotak-kota).
            val d = IntArray(n) { if (on[it]) 0 else Int.MAX_VALUE / 2 }
            for (y in 0 until h) for (x in 0 until w) {
                val q = y * w + x
                if (on[q]) continue
                var v = d[q]
                if (x > 0) v = min(v, d[q - 1] + 1)
                if (y > 0) v = min(v, d[q - w] + 1)
                d[q] = v
            }
            for (y in h - 1 downTo 0) for (x in w - 1 downTo 0) {
                val q = y * w + x
                if (on[q]) continue
                var v = d[q]
                if (x < w - 1) v = min(v, d[q + 1] + 1)
                if (y < h - 1) v = min(v, d[q + w] + 1)
                d[q] = v
            }
            val maxD = IntArray(id + 1)
            for (q in 0 until n) { val c = comp[q]; if (c > 0 && d[q] > maxD[c]) maxD[c] = d[q] }
            for (q in 0 until n) {
                val c = comp[q]
                if (c > 0 && !touchesEdge[c] && maxD[c] <= r) on[q] = true
            }
        }

        /**
         * Buang gumpalan yang jauh lebih besar dari huruf (wajah tokoh, bingkai kotak dialog, gambar latar terang)
         * supaya OCR hanya melihat huruf. Ukuran huruf = median tinggi gumpalan; gumpalan yang tingginya > 2,5x
         * atau lebarnya > 8x tinggi huruf dibuang. Dilewati bila gumpalannya terlalu sedikit untuk dibandingkan.
         */
        private fun dropBigBlobs(on: BooleanArray): Int {
            var total = 0
            for (b in on) if (b) total++
            if (total == 0) return 0
            val order = IntArray(total)
            val seen = BooleanArray(on.size)
            val starts = ArrayList<Int>()
            val sizes = ArrayList<Int>()
            val hs = ArrayList<Int>()
            val ws = ArrayList<Int>()
            var pos = 0
            for (s0 in on.indices) {
                if (!on[s0] || seen[s0]) continue
                val begin = pos
                order[pos++] = s0
                seen[s0] = true
                var head = begin
                var minX = w; var maxX = 0; var minY = h; var maxY = 0
                while (head < pos) {
                    val q0 = order[head++]
                    val x = q0 % w
                    val y = q0 / w
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    for (dy in -1..1) {
                        val ny = y + dy
                        if (ny < 0 || ny >= h) continue
                        for (dx in -1..1) {
                            val nx = x + dx
                            if (nx < 0 || nx >= w || (dx == 0 && dy == 0)) continue
                            val q = ny * w + nx
                            if (on[q] && !seen[q]) { seen[q] = true; order[pos++] = q }
                        }
                    }
                }
                starts += begin
                sizes += (pos - begin)
                hs += (maxY - minY + 1)
                ws += (maxX - minX + 1)
            }
            val sample = ArrayList<Int>()
            for (c in starts.indices) if (sizes[c] >= 40) sample += hs[c]
            if (sample.size < 5) return 0
            sample.sort()
            val medH = sample[sample.size / 2]
            for (c in starts.indices) {
                if (hs[c] > medH * 2.5f || ws[c] > medH * 8f) {
                    for (i in starts[c] until starts[c] + sizes[c]) on[order[i]] = false
                }
            }
            return medH
        }

        /**
         * Buang AREA lebar yang menempel pada huruf (wajah putih/gambar terang di belakang teks): area yang tahan
         * erosi sebesar r (goresan huruf lebih tipis dari 2r+1 sehingga hilang) ditandai sebagai "inti area",
         * dikembalikan dengan dilasi r+2, lalu dihapus dari topeng. Memakai gambar integral supaya O(n).
         */
        private fun peelAreas(on: BooleanArray, r: Int) {
            val k = 2 * r + 1
            val iw = w + 1
            fun integral(src: BooleanArray): IntArray {
                val ii = IntArray(iw * (h + 1))
                for (y in 0 until h) {
                    var rowSum = 0
                    for (x in 0 until w) {
                        if (src[y * w + x]) rowSum++
                        ii[(y + 1) * iw + (x + 1)] = ii[y * iw + (x + 1)] + rowSum
                    }
                }
                return ii
            }
            fun box(ii: IntArray, x0: Int, y0: Int, x1: Int, y1: Int): Int =   // [x0,x1) x [y0,y1)
                ii[y1 * iw + x1] - ii[y0 * iw + x1] - ii[y1 * iw + x0] + ii[y0 * iw + x0]
            val ii = integral(on)
            val core = BooleanArray(w * h)
            var any = false
            for (y in r until h - r) {
                for (x in r until w - r) {
                    if (on[y * w + x] && box(ii, x - r, y - r, x + r + 1, y + r + 1) == k * k) { core[y * w + x] = true; any = true }
                }
            }
            if (!any) return
            val ic = integral(core)
            val d = r + 2
            for (y in 0 until h) {
                val y0 = maxOf(0, y - d); val y1 = minOf(h, y + d + 1)
                for (x in 0 until w) {
                    if (!on[y * w + x]) continue
                    val x0 = maxOf(0, x - d); val x1 = minOf(w, x + d + 1)
                    if (box(ic, x0, y0, x1, y1) > 0) on[y * w + x] = false
                }
            }
        }

        private fun grayOf(b: Bitmap): IntArray {
            val p = IntArray(w * h)
            b.getPixels(p, 0, w, 0, 0, w, h)
            for (k in p.indices) {
                val c = p[k]
                p[k] = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            }
            return p
        }
    }

    private fun stretch(g: IntArray): IntArray {
        val hist = IntArray(256)
        for (v in g) hist[v]++
        val total = g.size
        var acc = 0
        var lo = 0
        var hi = 255
        for (v in 0..255) { acc += hist[v]; if (acc >= total * 0.02) { lo = v; break } }
        acc = 0
        for (v in 255 downTo 0) { acc += hist[v]; if (acc >= total * 0.02) { hi = v; break } }
        if (hi - lo < 16) { lo = 0; hi = 255 }
        val span = (hi - lo).toFloat()
        val out = IntArray(g.size)
        for (k in g.indices) out[k] = (((g[k] - lo) * 255f) / span).toInt().coerceIn(0, 255)
        return out
    }

    private fun sharpen(g: IntArray, w: Int, h: Int): IntArray {
        val out = g.copyOf()
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val v = 5 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]
                out[i] = v.coerceIn(0, 255)
            }
        }
        return out
    }

    private fun otsu(g: IntArray): IntArray {
        val hist = IntArray(256)
        for (v in g) hist[v]++
        val total = g.size.toDouble()
        var sum = 0.0
        for (t in 0..255) sum += t * hist[t].toDouble()
        var sumB = 0.0
        var wB = 0.0
        var best = 0.0
        var thr = 127
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0.0) continue
            val wF = total - wB
            if (wF == 0.0) break
            sumB += t * hist[t].toDouble()
            val mB = sumB / wB
            val mF = (sum - sumB) / wF
            val between = wB * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; thr = t }
        }
        val out = IntArray(g.size)
        for (k in g.indices) out[k] = if (g[k] > thr) 255 else 0
        return out
    }

    /**
     * Meluruskan huruf miring ke kanan: baris atas digeser ke kiri sebanding jaraknya dari tengah.
     * Lebar bertambah supaya tidak ada yang terpotong; tepi diisi dengan piksel tepi (tanpa garis aneh).
     * Peta balik koordinat: x asli = x' - (s*h/2 + s*(y - h/2)).
     */
    private fun shearBitmap(g: IntArray, w: Int, h: Int, s: Float): Bitmap {
        val extra = kotlin.math.ceil(s * h).toInt()
        val nw = w + extra
        val mid = h / 2f
        val off = s * h / 2f
        val out = IntArray(nw * h)
        for (y in 0 until h) {
            val shift = (s * (y - mid) + off).roundToInt()
            val row = y * w
            val orow = y * nw
            for (x in 0 until nw) {
                val sx = (x - shift).coerceIn(0, w - 1)
                out[orow + x] = g[row + sx]
            }
        }
        return toBitmap(out, nw, h, false)
    }

    private fun toBitmap(g: IntArray, w: Int, h: Int, invert: Boolean): Bitmap {
        val px = IntArray(g.size)
        for (k in g.indices) {
            val v = if (invert) 255 - g[k] else g[k]
            px[k] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
