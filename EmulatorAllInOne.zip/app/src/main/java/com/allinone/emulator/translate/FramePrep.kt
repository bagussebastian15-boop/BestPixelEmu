package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import androidx.annotation.RequiresApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt

/** Menangkap isi layar game (GLSurfaceView) tanpa menyertakan tombol/overlay. Butuh Android 7.0+. */
object FrameCapture {
    fun supported() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    suspend fun grab(view: SurfaceView): Bitmap? {
        if (!supported() || view.width <= 0 || view.height <= 0) return null
        return grabN(view)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private suspend fun grabN(view: SurfaceView): Bitmap? = suspendCancellableCoroutine { cont ->
        val bmp = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        try {
            PixelCopy.request(
                view, bmp,
                PixelCopy.OnPixelCopyFinishedListener { r ->
                    if (cont.isActive) cont.resume(if (r == PixelCopy.SUCCESS) bmp else null)
                },
                Handler(Looper.getMainLooper())
            )
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(null)
        }
    }
}

/**
 * Pra-pemrosesan supaya teks piksel/buram lebih mudah dibaca OCR:
 * ukuran dinormalkan, kontras diregangkan, ditajamkan, dibalik (teks terang di kotak gelap), dan dibinerkan (Otsu).
 */
object FramePrep {
    private const val MAX_SIDE = 1600
    private const val MIN_SIDE = 1100
    const val VARIANT_COUNT = 5

    fun crop(src: Bitmap, bottomOnly: Boolean): Bitmap {
        if (!bottomOnly) return src
        val h = (src.height * 0.45f).toInt().coerceAtLeast(1)
        return Bitmap.createBitmap(src, 0, src.height - h, src.width, h)
    }

    fun normalizeSize(src: Bitmap): Bitmap {
        val longSide = max(src.width, src.height)
        val scale = when {
            longSide > MAX_SIDE -> MAX_SIDE.toFloat() / longSide
            longSide < MIN_SIDE -> MIN_SIDE.toFloat() / longSide
            else -> 1f
        }
        if (scale == 1f) return src
        return Bitmap.createScaledBitmap(
            src,
            (src.width * scale).roundToInt().coerceAtLeast(1),
            (src.height * scale).roundToInt().coerceAtLeast(1),
            true
        )
    }

    /** Varian dibuat malas (hanya saat dibutuhkan) agar hemat RAM dan waktu. */
    class Variants(private val base: Bitmap) {
        private val w = base.width
        private val h = base.height
        private val cache = arrayOfNulls<Bitmap>(VARIANT_COUNT)
        private var stretched: IntArray? = null
        private var sharpened: IntArray? = null

        fun get(i: Int): Bitmap {
            cache[i]?.let { return it }
            val b = build(i)
            cache[i] = b
            return b
        }

        fun release() {
            for (b in cache) if (b != null && b !== base && !b.isRecycled) b.recycle()
        }

        private fun gray(): IntArray = stretched ?: stretch(grayOf(base)).also { stretched = it }
        private fun sharp(): IntArray = sharpened ?: sharpen(gray(), w, h).also { sharpened = it }

        private fun build(i: Int): Bitmap = when (i) {
            0 -> base                                       // warna asli
            1 -> toBitmap(gray(), w, h, false)              // abu-abu, kontras diregangkan
            2 -> toBitmap(sharp(), w, h, false)             // + dipertajam
            3 -> toBitmap(sharp(), w, h, true)              // dibalik
            else -> toBitmap(otsu(sharp()), w, h, false)    // hitam-putih
        }

        private fun grayOf(b: Bitmap): IntArray {
            val p = IntArray(w * h)
            b.getPixels(p, 0, w, 0, 0, w, h)
            for (k in p.indices) {
                val c = p[k]
                p[k] = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            }
            return p
        }
    }

    private fun stretch(g: IntArray): IntArray {
        val hist = IntArray(256)
        for (v in g) hist[v]++
        val total = g.size
        var acc = 0
        var lo = 0
        var hi = 255
        for (v in 0..255) { acc += hist[v]; if (acc >= total * 0.02) { lo = v; break } }
        acc = 0
        for (v in 255 downTo 0) { acc += hist[v]; if (acc >= total * 0.02) { hi = v; break } }
        if (hi - lo < 16) { lo = 0; hi = 255 }
        val span = (hi - lo).toFloat()
        val out = IntArray(g.size)
        for (k in g.indices) out[k] = (((g[k] - lo) * 255f) / span).toInt().coerceIn(0, 255)
        return out
    }

    private fun sharpen(g: IntArray, w: Int, h: Int): IntArray {
        val out = g.copyOf()
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val v = 5 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]
                out[i] = v.coerceIn(0, 255)
            }
        }
        return out
    }

    private fun otsu(g: IntArray): IntArray {
        val hist = IntArray(256)
        for (v in g) hist[v]++
        val total = g.size.toDouble()
        var sum = 0.0
        for (t in 0..255) sum += t * hist[t].toDouble()
        var sumB = 0.0
        var wB = 0.0
        var best = 0.0
        var thr = 127
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0.0) continue
            val wF = total - wB
            if (wF == 0.0) break
            sumB += t * hist[t].toDouble()
            val mB = sumB / wB
            val mF = (sum - sumB) / wF
            val between = wB * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; thr = t }
        }
        val out = IntArray(g.size)
        for (k in g.indices) out[k] = if (g[k] > thr) 255 else 0
        return out
    }

    private fun toBitmap(g: IntArray, w: Int, h: Int, invert: Boolean): Bitmap {
        val px = IntArray(g.size)
        for (k in g.indices) {
            val v = if (invert) 255 - g[k] else g[k]
            px[k] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
