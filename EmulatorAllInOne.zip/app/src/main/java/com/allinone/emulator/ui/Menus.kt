package com.allinone.emulator.ui

import android.app.Activity
import android.content.Context
import android.view.KeyEvent
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.translate.TranslationEngine

/** Dialog yang dipakai bersama oleh Library dan layar emulasi. */
object Menus {

    fun choose(ctx: Context, title: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which -> onPick(which); d.dismiss() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickInt(
        ctx: Context, title: String, values: List<Int>, current: Int, suffix: String, onPick: (Int) -> Unit
    ) = choose(ctx, title, values.map { "$it$suffix" }, values.indexOf(current)) { onPick(values[it]) }

    private fun onOff(v: Boolean) = if (v) "aktif" else "mati"

    private fun dialectLabel(k: String) = when (k) {
        "us" -> "Inggris Amerika"
        "uk" -> "Inggris Britania"
        else -> "Otomatis"
    }

    private fun engineLabel(e: Int) = when (e) {
        1 -> "Gemini online (teks saja)"
        2 -> "Gemini online (teks + gambar, paling akurat)"
        else -> "ML Kit offline"
    }

    private fun askText(ctx: Context, title: String, hintText: String, current: String, onOk: (String) -> Unit) {
        val et = android.widget.EditText(ctx).apply {
            setText(current); setHint(hintText); setSingleLine(true)
        }
        val box = android.widget.FrameLayout(ctx).apply {
            val m = (20 * ctx.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        AlertDialog.Builder(ctx).setTitle(title).setView(box)
            .setPositiveButton("Simpan") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    /**
     * Daftar pengaturan yang TETAP terbuka setelah tiap perubahan (label otomatis diperbarui),
     * jadi bisa mengubah beberapa pengaturan sekaligus. Ditutup lewat tombol "Tutup" / Kembali.
     * [extra] dievaluasi ulang tiap refresh; lambda-nya menerima fungsi untuk menutup daftar.
     * [onClosed] dipanggil sekali saat daftar benar-benar tertutup.
     */
    fun settings(
        ctx: Context, s: Settings,
        extra: () -> List<Pair<String, (dismiss: () -> Unit) -> Unit>> = { emptyList() },
        onClosed: () -> Unit = {},
        onChangeCb: () -> Unit
    ) {
        var refresh: () -> Unit = {}
        var dialog: AlertDialog? = null
        val onChange: () -> Unit = { onChangeCb(); refresh() }

        fun buildRows(): List<Pair<String, () -> Unit>> {
        val rows = ArrayList<Pair<String, () -> Unit>>()
        rows += "Kecepatan fast forward: ${s.fastForward}x" to {
            pickInt(ctx, "Fast forward", listOf(2, 3, 4, 8), s.fastForward, "x") { s.fastForward = it; onChange() }
        }
        rows += "Frame skip: ${s.frameSkip} (saat game dimulai)" to {
            pickInt(ctx, "Frame skip", listOf(0, 1, 2, 3, 4, 5), s.frameSkip, "") { s.frameSkip = it; onChange() }
        }
        rows += "Lewati frame duplikat: ${onOff(s.skipDuplicateFrames)} (saat game dimulai)" to {
            s.skipDuplicateFrames = !s.skipDuplicateFrames; onChange()
        }
        rows += "Transparansi kontrol layar: ${s.padOpacity}%" to {
            pickInt(ctx, "Transparansi", listOf(20, 40, 60, 80, 100), s.padOpacity, "%") { s.padOpacity = it; onChange() }
        }
        rows += "Kontrol arah di layar: ${if (s.analogPad) "stik analog" else "D-pad 8 arah"}" to {
            choose(ctx, "Kontrol arah di layar", listOf("D-pad 8 arah (termasuk serong)", "Stik analog"), if (s.analogPad) 1 else 0) {
                s.analogPad = it == 1; onChange()
            }
        }
        rows += "Sembunyikan kontrol layar saat gamepad terhubung: ${onOff(s.autoHidePad)}" to {
            s.autoHidePad = !s.autoHidePad; onChange()
        }
        rows += "Getar saat sentuh: ${onOff(s.haptics)}" to { s.haptics = !s.haptics; onChange() }
        rows += "Bahasa teks game (terjemahan): ${TranslationEngine.SOURCES.first { it.first == s.translateSource }.second}" to {
            val keys = TranslationEngine.SOURCES.map { it.first }
            choose(ctx, "Bahasa teks game", TranslationEngine.SOURCES.map { it.second }, keys.indexOf(s.translateSource)) {
                s.translateSource = keys[it]; onChange()
            }
        }
        rows += "Area baca terjemahan: ${if (s.translateBottomOnly) "bagian bawah layar (dialog)" else "seluruh layar"}" to {
            s.translateBottomOnly = !s.translateBottomOnly; onChange()
        }
        rows += "Ragam Inggris: ${dialectLabel(s.englishVariant)}" to {
            val keys = listOf("auto", "us", "uk")
            choose(ctx, "Ragam bahasa Inggris", keys.map { dialectLabel(it) }, keys.indexOf(s.englishVariant)) {
                s.englishVariant = keys[it]; onChange()
            }
        }
        rows += "Mesin terjemahan: ${engineLabel(s.translateEngine)}" to {
            choose(ctx, "Mesin terjemahan", listOf(0, 1, 2).map { engineLabel(it) }, s.translateEngine) { pick ->
                s.translateEngine = pick
                if (pick != 0 && s.geminiKey.isEmpty()) {
                    askText(ctx, "API key Gemini", "Tempel API key dari Google AI Studio", "") { s.geminiKey = it; onChange() }
                }
                onChange()
            }
        }
        rows += "API key Gemini: ${if (s.geminiKey.isEmpty()) "belum diisi" else "terisi"}" to {
            askText(ctx, "API key Gemini", "Tempel API key dari Google AI Studio", s.geminiKey) { s.geminiKey = it; onChange() }
        }
        rows += "Model Gemini: ${s.geminiModel}" to {
            askText(ctx, "Model Gemini", "mis. gemini-flash-latest", s.geminiModel) { s.geminiModel = it; onChange() }
        }
        rows += "Reset peta tombol gamepad" to {
            KeyMap.clearAll(ctx)
            Toast.makeText(ctx, "Peta tombol direset", Toast.LENGTH_SHORT).show()
        }
        for ((label, action) in extra()) rows += label to { action { dialog?.dismiss() } }
        return rows
        }

        var rows = buildRows()
        val labels = ArrayList(rows.map { it.first })
        val adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_list_item_1, labels)
        val list = android.widget.ListView(ctx).apply {
            this.adapter = adapter
            setOnItemClickListener { _, _, i, _ -> rows.getOrNull(i)?.second?.invoke(); refresh() }
        }
        refresh = {
            rows = buildRows()
            labels.clear(); labels.addAll(rows.map { it.first })
            adapter.notifyDataSetChanged()
        }
        dialog = AlertDialog.Builder(ctx).setTitle("Pengaturan").setView(list)
            .setNegativeButton("Tutup", null)
            .setOnDismissListener { onClosed() }
            .show()
    }

    /** Pemetaan tombol interaktif: tekan tombol di gamepad untuk tiap fungsi. */
    fun remap(activity: Activity) {
        fun ask(i: Int) {
            if (i >= KeyMap.logical.size) {
                Toast.makeText(activity, "Peta tombol tersimpan", Toast.LENGTH_SHORT).show()
                return
            }
            val (name, logical) = KeyMap.logical[i]
            AlertDialog.Builder(activity)
                .setTitle("Atur tombol (${i + 1}/${KeyMap.logical.size})")
                .setMessage("Tekan tombol di gamepad untuk:\n\n$name")
                .setNegativeButton("Lewati") { _, _ -> ask(i + 1) }
                .setNeutralButton("Selesai", null)
                .setOnKeyListener { d, keyCode, ev ->
                    val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                        keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0 && isPadKey) {
                        KeyMap.bind(activity, ev.device?.descriptor ?: "", keyCode, logical)
                        d.dismiss()
                        ask(i + 1)
                        true
                    } else false
                }
                .show()
        }
        ask(0)
    }
}
