package com.allinone.emulator.ui

import android.app.Activity
import android.content.Context
import android.view.KeyEvent
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.translate.TranslationEngine

/** Dialog yang dipakai bersama oleh Library dan layar emulasi. */
object Menus {

    fun choose(ctx: Context, title: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which -> onPick(which); d.dismiss() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickInt(
        ctx: Context, title: String, values: List<Int>, current: Int, suffix: String, onPick: (Int) -> Unit
    ) = choose(ctx, title, values.map { "$it$suffix" }, values.indexOf(current)) { onPick(values[it]) }

    private fun onOff(v: Boolean) = if (v) "aktif" else "mati"

    fun settings(ctx: Context, s: Settings, onChange: () -> Unit, extra: List<Pair<String, () -> Unit>> = emptyList()) {
        val items = arrayOf(
            "Kecepatan fast forward: ${s.fastForward}x",
            "Frame skip: ${s.frameSkip} (saat game dimulai)",
            "Lewati frame duplikat: ${onOff(s.skipDuplicateFrames)} (saat game dimulai)",
            "Transparansi kontrol layar: ${s.padOpacity}%",
            "Sembunyikan kontrol layar saat gamepad terhubung: ${onOff(s.autoHidePad)}",
            "Getar saat sentuh: ${onOff(s.haptics)}",
            "Bahasa teks game (terjemahan): ${TranslationEngine.SOURCES.first { it.first == s.translateSource }.second}",
            "Area baca terjemahan: ${if (s.translateBottomOnly) "bagian bawah layar (dialog)" else "seluruh layar"}",
            "Gaya huruf terjemahan: ${if (s.translateFont == 1) "piksel (eksperimental)" else "ikuti game"}",
            "Reset peta tombol gamepad"
        ) + extra.map { it.first }
        AlertDialog.Builder(ctx).setTitle("Pengaturan").setItems(items) { _, i ->
            when (i) {
                0 -> pickInt(ctx, "Fast forward", listOf(2, 3, 4, 8), s.fastForward, "x") { s.fastForward = it; onChange() }
                1 -> pickInt(ctx, "Frame skip", listOf(0, 1, 2, 3, 4, 5), s.frameSkip, "") { s.frameSkip = it; onChange() }
                2 -> { s.skipDuplicateFrames = !s.skipDuplicateFrames; onChange() }
                3 -> pickInt(ctx, "Transparansi", listOf(20, 40, 60, 80, 100), s.padOpacity, "%") { s.padOpacity = it; onChange() }
                4 -> { s.autoHidePad = !s.autoHidePad; onChange() }
                5 -> { s.haptics = !s.haptics; onChange() }
                6 -> {
                    val keys = TranslationEngine.SOURCES.map { it.first }
                    choose(ctx, "Bahasa teks game", TranslationEngine.SOURCES.map { it.second }, keys.indexOf(s.translateSource)) {
                        s.translateSource = keys[it]; onChange()
                    }
                }
                7 -> { s.translateBottomOnly = !s.translateBottomOnly; onChange() }
                8 -> { s.translateFont = if (s.translateFont == 1) 0 else 1; onChange() }
                9 -> {
                    KeyMap.clearAll(ctx)
                    Toast.makeText(ctx, "Peta tombol direset", Toast.LENGTH_SHORT).show()
                }
                else -> extra.getOrNull(i - 10)?.second?.invoke()
            }
        }.setNegativeButton("Tutup", null).show()
    }

    /** Pemetaan tombol interaktif: tekan tombol di gamepad untuk tiap fungsi. */
    fun remap(activity: Activity) {
        fun ask(i: Int) {
            if (i >= KeyMap.logical.size) {
                Toast.makeText(activity, "Peta tombol tersimpan", Toast.LENGTH_SHORT).show()
                return
            }
            val (name, logical) = KeyMap.logical[i]
            AlertDialog.Builder(activity)
                .setTitle("Atur tombol (${i + 1}/${KeyMap.logical.size})")
                .setMessage("Tekan tombol di gamepad untuk:\n\n$name")
                .setNegativeButton("Lewati") { _, _ -> ask(i + 1) }
                .setNeutralButton("Selesai", null)
                .setOnKeyListener { d, keyCode, ev ->
                    val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                        keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0 && isPadKey) {
                        KeyMap.bind(activity, ev.device?.descriptor ?: "", keyCode, logical)
                        d.dismiss()
                        ask(i + 1)
                        true
                    } else false
                }
                .show()
        }
        ask(0)
    }
}
