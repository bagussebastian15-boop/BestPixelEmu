package com.allinone.emulator.ui

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.input.PadMap
import com.allinone.emulator.input.StickKeys
import com.allinone.emulator.translate.TranslationEngine

/** Dialog yang dipakai bersama oleh Library dan layar emulasi. */
object Menus {

    fun choose(ctx: Context, title: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which -> onPick(which); d.dismiss() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickInt(
        ctx: Context, title: String, values: List<Int>, current: Int, suffix: String, onPick: (Int) -> Unit
    ) = choose(ctx, title, values.map { "$it$suffix" }, values.indexOf(current)) { onPick(values[it]) }

    /** Filter gambar: (nama singkat, penjelasan untuk daftar pilihan). Indeks = Settings.shaderMode. */
    private val SHADERS = listOf(
        "halus" to "Halus (bilinear, bawaan): gambar lembut, piksel agak buram",
        "tajam" to "Tajam (sharp): tepi piksel tegas, huruf piksel lebih jelas dan lebih mudah dibaca OCR terjemahan"
    )

    /** Profil performa arcade: (nama singkat, penjelasan untuk daftar pilihan). */
    private val ARCADE_PERF = listOf(
        "standar" to "Standar (bawaan core)",
        "seimbang" to "Seimbang (tanpa frame dibuang; warna 16-bit & suara lebih ringan)",
        "ringan" to "Ringan (gambar digambar 1 dari tiap 2 frame; sprite ramai lebih lancar)",
        "maksimal" to "Maksimal (gambar digambar 1 dari tiap 3 frame; suara paling ringan)"
    )

    private fun onOff(v: Boolean) = if (v) "aktif" else "mati"

    private fun askText(ctx: Context, title: String, hintText: String, current: String, onOk: (String) -> Unit) {
        val et = android.widget.EditText(ctx).apply {
            setText(current); setHint(hintText); setSingleLine(true)
        }
        val box = android.widget.FrameLayout(ctx).apply {
            val m = (20 * ctx.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        AlertDialog.Builder(ctx).setTitle(title).setView(box)
            .setPositiveButton("Simpan") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Satu kategori di menu pengaturan: judul, ringkasan nilai saat ini, dan baris pengaturan di dalamnya. */
    private class Category(
        val title: String,
        val summary: () -> String,
        val rows: () -> List<Pair<String, () -> Unit>>
    )

    /**
     * Menu pengaturan berkategori. Layar utama berisi daftar kategori (dengan ringkasan nilai saat ini);
     * mengetuk satu kategori membuka daftar pengaturannya. Daftar TETAP terbuka setelah tiap perubahan
     * (label otomatis diperbarui), jadi bisa mengubah beberapa pengaturan sekaligus. Tombol "Kembali" pada
     * kategori kembali ke daftar kategori; tombol "Tutup" menutup semuanya.
     * [extra] dievaluasi ulang tiap refresh; lambda-nya menerima fungsi untuk menutup seluruh menu.
     * Aksi tambahan ini ditaruh di kategori Terjemahan.
     * [onClosed] dipanggil sekali saat menu benar-benar tertutup.
     */
    fun settings(
        ctx: Context, s: Settings,
        extra: () -> List<Pair<String, (dismiss: () -> Unit) -> Unit>> = { emptyList() },
        onClosed: () -> Unit = {},
        padGroup: String? = null,   // sistem yang sedang dimainkan: pemetaan langsung membuka sistem ini
        arcadeGame: Boolean = false, // true hanya saat memainkan game arcade: pengaturan arcade ditampilkan
        onChangeCb: () -> Unit
    ): AlertDialog? {
        var refresh: () -> Unit = {}
        var dialog: AlertDialog? = null
        var subDialog: AlertDialog? = null
        var subRefresh: () -> Unit = {}
        val onChange: () -> Unit = { onChangeCb(); refresh(); subRefresh() }

        // ---- Kategori ----
        val performa = Category(
            "Performa & tampilan",
            { "Fast forward ${s.fastForward}x · Filter ${SHADERS.getOrElse(s.shaderMode) { SHADERS[0] }.first} · Layar 60 Hz ${onOff(s.lock60Hz)} · FPS ${onOff(s.showFps)}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Filter gambar: ${SHADERS.getOrElse(s.shaderMode) { SHADERS[0] }.first} (langsung berlaku)" to {
                choose(ctx, "Filter gambar", SHADERS.map { it.second }, s.shaderMode) { s.shaderMode = it; onChange() }
            }
            r += "Kecepatan fast forward: ${s.fastForward}x" to {
                pickInt(ctx, "Fast forward", listOf(2, 3, 4, 8), s.fastForward, "x") { s.fastForward = it; onChange() }
            }
            r += "Frame skip: ${s.frameSkip} (saat game dimulai)" to {
                pickInt(ctx, "Frame skip", listOf(0, 1, 2, 3, 4, 5), s.frameSkip, "") { s.frameSkip = it; onChange() }
            }
            r += "Kunci layar 60 Hz: ${onOff(s.lock60Hz)} (saat game dimulai)" to {
                s.lock60Hz = !s.lock60Hz; onChange()
            }
            r += "Lewati frame duplikat: ${onOff(s.skipDuplicateFrames)} (saat game dimulai)" to {
                s.skipDuplicateFrames = !s.skipDuplicateFrames; onChange()
            }
            r += "Penghitung FPS di layar: ${onOff(s.showFps)}" to {
                s.showFps = !s.showFps; onChange()
            }
            r
        }

        val arcade = Category(
            "Arcade",
            {
                "Performa ${ARCADE_PERF.getOrElse(s.arcadePerf) { ARCADE_PERF[0] }.first} · CPU ${s.arcadeCpu}%"
            }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Performa arcade: ${ARCADE_PERF.getOrElse(s.arcadePerf) { ARCADE_PERF[0] }.first} (langsung berlaku)" to {
                choose(ctx, "Performa arcade", ARCADE_PERF.map { it.second }, s.arcadePerf) { s.arcadePerf = it; onChange() }
            }
            r += "Kecepatan CPU arcade (FBNeo saja): ${s.arcadeCpu}% (langsung berlaku)" to {
                pickInt(ctx, "Kecepatan CPU arcade (naikkan bila game melambat saat sprite ramai)",
                    com.allinone.emulator.data.ArcadeTuning.CPU_CHOICES, s.arcadeCpu, "%") { s.arcadeCpu = it; onChange() }
            }
            r
        }

        val audio = Category(
            "Audio",
            { "Mode ${if (s.lowLatencyAudio) "latensi rendah" else "stabil"}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Mode audio: ${if (s.lowLatencyAudio) "latensi rendah" else "stabil"} (saat game dimulai)" to {
                choose(ctx, "Mode audio",
                    listOf(
                        "Stabil (bawaan): suara mulus, bebas kresek, tapi sedikit terlambat dari gambar",
                        "Latensi rendah: suara cepat & sinkron, tapi bisa kresek bila perangkat berat"
                    ),
                    if (s.lowLatencyAudio) 1 else 0
                ) { s.lowLatencyAudio = (it == 1); onChange() }
            }
            r
        }

        val kontrol = Category(
            "Kontrol di layar",
            { "Transparansi ${s.padOpacity}% · ${if (s.analogPad) "stik analog" else "D-pad 8 arah"} · Getar ${onOff(s.haptics)}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Transparansi kontrol layar: ${s.padOpacity}%" to {
                pickInt(ctx, "Transparansi", listOf(20, 40, 60, 80, 100), s.padOpacity, "%") { s.padOpacity = it; onChange() }
            }
            r += "Kontrol arah di layar: ${if (s.analogPad) "stik analog" else "D-pad 8 arah"}" to {
                choose(ctx, "Kontrol arah di layar", listOf("D-pad 8 arah (termasuk serong)", "Stik analog"), if (s.analogPad) 1 else 0) {
                    s.analogPad = it == 1; onChange()
                }
            }
            r += "Getar saat sentuh: ${onOff(s.haptics)}" to { s.haptics = !s.haptics; onChange() }
            r
        }

        val controller = Category(
            "Controller eksternal",
            { "Sembunyikan kontrol layar ${onOff(s.autoHidePad)} · Layar penuh ${onOff(s.stretchWithPad)}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Sembunyikan kontrol layar saat gamepad terhubung: ${onOff(s.autoHidePad)}" to {
                s.autoHidePad = !s.autoHidePad; onChange()
            }
            r += "Gambar game memenuhi seluruh layar saat gamepad terhubung: ${onOff(s.stretchWithPad)}" to {
                s.stretchWithPad = !s.stretchWithPad; onChange()
            }
            r += (if (padGroup != null) "Pemetaan tombol controller: ${PadMap.groupLabel(padGroup)}"
                  else "Pemetaan tombol controller eksternal & kombo") to {
                (ctx as? Activity)?.let { if (padGroup != null) padMapOpen(it, padGroup, true) else padMapSystems(it) }
            }
            r += "Pintasan controller (simpan/muat, pengaturan, library, keluar)" to {
                (ctx as? Activity)?.let { remap(it) }
            }
            r += "Reset pintasan controller" to {
                KeyMap.clearAll(ctx)
                Toast.makeText(ctx, "Pintasan direset", Toast.LENGTH_SHORT).show()
            }
            r
        }

        val terjemahan = Category(
            "Terjemahan",
            {
                "${TranslationEngine.SOURCES.first { it.first == s.translateSource }.second} · " +
                    (if (s.translateBottomOnly) "area bawah layar" else "seluruh layar") +
                    " · huruf ${s.translateFontMin}-${s.translateFontMax} dp"
            }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Bahasa teks game: ${TranslationEngine.SOURCES.first { it.first == s.translateSource }.second}" to {
                val keys = TranslationEngine.SOURCES.map { it.first }
                choose(ctx, "Bahasa teks game", TranslationEngine.SOURCES.map { it.second }, keys.indexOf(s.translateSource)) {
                    s.translateSource = keys[it]; onChange()
                }
            }
            r += "Jenis teks: ${if (s.translateKind == 1) "Menu awal game" else "Dialog"}" to {
                choose(ctx, "Jenis teks yang diterjemahkan (dua mode terpisah)",
                    listOf("Dialog (bawaan): balon/kotak dialog saat bermain",
                        "Menu awal game: tulisan Start, Option, Load, Save, dll. diterjemahkan satu per satu di tempatnya"),
                    s.translateKind) { s.translateKind = it; onChange() }
            }
            r += "Mesin terjemahan: ${if (s.translateOnline) "Online (Google Translate)" else "Offline (ML Kit)"}" to {
                choose(ctx, "Mesin terjemahan (dua mode terpisah, tidak saling menggantikan)",
                    listOf("Online (Google Translate): lebih akurat, wajib internet, teks dialog dikirim ke Google",
                        "Offline (ML Kit): tanpa internet, kurang akurat; model bahasa diunduh sekali saja"),
                    if (s.translateOnline) 0 else 1) { s.translateOnline = it == 0; onChange() }
            }
            r += "Area baca terjemahan: ${if (s.translateBottomOnly) "bagian bawah layar (dialog)" else "seluruh layar"}" to {
                s.translateBottomOnly = !s.translateBottomOnly; onChange()
            }
            r += "Ukuran huruf terjemahan minimal: ${s.translateFontMin} dp" to {
                pickInt(ctx, "Huruf minimal (naikkan bila terjemahan terlalu kecil)",
                    listOf(8, 10, 12, 14, 16, 20), s.translateFontMin, " dp") {
                    s.translateFontMin = it
                    if (s.translateFontMax < it) s.translateFontMax = it   // maksimal tidak boleh di bawah minimal
                    onChange()
                }
            }
            r += "Ukuran huruf terjemahan maksimal: ${s.translateFontMax} dp" to {
                pickInt(ctx, "Huruf maksimal (turunkan bila terjemahan terlalu besar)",
                    listOf(16, 20, 24, 28, 36, 48), s.translateFontMax, " dp") {
                    s.translateFontMax = it
                    if (s.translateFontMin > it) s.translateFontMin = it   // minimal tidak boleh di atas maksimal
                    onChange()
                }
            }
            // Aksi yang hanya muncul saat terjemahan sedang aktif (ganti teks asli/terjemahan, baca ulang)
            for ((label, action) in extra()) r += label to { action { dialog?.dismiss() } }
            r
        }

        // Urutan = yang paling sering dipakai di atas
        val categories = ArrayList<Category>().apply {
            add(performa)
            if (arcadeGame) add(arcade)
            add(audio)
            add(kontrol)
            add(controller)
            add(terjemahan)
        }

        // ---- Layar kategori ----
        fun openCategory(c: Category) {
            var rows = c.rows()
            val labels = ArrayList(rows.map { it.first })
            val adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_list_item_1, labels)
            val list = android.widget.ListView(ctx).apply {
                this.adapter = adapter
                setOnItemClickListener { _, _, i, _ -> rows.getOrNull(i)?.second?.invoke(); subRefresh() }
            }
            subRefresh = {
                rows = c.rows()
                labels.clear(); labels.addAll(rows.map { it.first })
                adapter.notifyDataSetChanged()
            }
            subDialog = AlertDialog.Builder(ctx).setTitle(c.title).setView(list)
                .setNegativeButton("Kembali", null)
                .setOnDismissListener { subDialog = null; subRefresh = {}; refresh() }
                .show()
        }

        // ---- Layar utama: daftar kategori + ringkasan ----
        val adapter = object : android.widget.ArrayAdapter<Category>(
            ctx, android.R.layout.simple_list_item_2, android.R.id.text1, categories
        ) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val v = super.getView(position, convertView, parent)
                val c = categories[position]
                v.findViewById<android.widget.TextView>(android.R.id.text1).apply {
                    text = c.title
                    textSize = 17f
                }
                v.findViewById<android.widget.TextView>(android.R.id.text2).apply {
                    text = c.summary()
                    textSize = 13f
                    alpha = 0.7f
                }
                return v
            }
        }
        val list = android.widget.ListView(ctx).apply {
            this.adapter = adapter
            setOnItemClickListener { _, _, i, _ -> categories.getOrNull(i)?.let { openCategory(it) } }
        }
        refresh = { adapter.notifyDataSetChanged() }
        dialog = AlertDialog.Builder(ctx).setTitle("Pengaturan").setView(list)
            .setNegativeButton("Tutup", null)
            .setOnDismissListener {
                subDialog?.dismiss()   // menutup menu dari luar (mis. muat ulang core) ikut menutup kategori yang terbuka
                onClosed()
            }
            .show()
        return dialog
    }

    // ---------------------------------------------------------------- pemetaan tombol controller + kombo

    private fun specLabel(spec: String) = spec.replace("+", " + ")

    /** Pilih sistem yang pemetaannya mau diatur (tiap sistem punya pemetaan sendiri). */
    fun padMapSystems(a: Activity) {
        val gs = PadMap.GROUPS
        val rows = gs.map { g ->
            val n = PadMap.entries(a, g).size
            PadMap.groupLabel(g) + if (n > 0) "  ($n pemetaan)" else ""
        }.toTypedArray()
        AlertDialog.Builder(a)
            .setTitle("Pemetaan tombol controller")
            .setItems(rows) { _, i -> padMapOpen(a, gs[i], false) }
            .setNegativeButton("Tutup", null)
            .show()
    }

    /** true bila layar pemetaan dibuka langsung untuk sistem yang sedang dimainkan (tanpa pilihan sistem). */
    private var padMapDirect = false

    fun padMapOpen(a: Activity, g: String, direct: Boolean) {
        padMapDirect = direct
        padMapButtons(a, g)
    }

    /**
     * Satu layar berisi SEMUA tombol game sistem [g] (mis. GBA: A, B, L, R, Select, Start, arah). Ketuk satu tombol
     * game (jadi hijau, menunggu), lalu tekan tombol di controller eksternal: langsung terpasang dan layar tetap
     * terbuka, jadi bisa lanjut memetakan tombol berikutnya. Tahan lama satu tombol game = kembali ke bawaan.
     */
    private fun padMapButtons(a: Activity, g: String) {
        val tokens = PadMap.tokens(g)
        val dp = a.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        var listening: String? = null
        val swallowUp = HashSet<Int>()
        var refresh: () -> Unit = {}

        val info = TextView(a).apply { textSize = 14f; setPadding(px(20), px(12), px(20), px(8)) }
        val grid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(px(12), 0, px(12), px(8)) }
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            addView(info)
            addView(ScrollView(a).apply { addView(grid) })
        }

        refresh = {
            val l = listening
            info.text = if (l != null) "Tekan tombol di controller untuk ${tokenName(l)}…"
                        else "Ketuk tombol game, lalu tekan tombol di controller atau gerakkan stick analog ke satu arah. Tahan lama = kembali ke bawaan."
            grid.removeAllViews()
            for (pair in tokens.chunked(2)) {
                val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
                for (tok in pair) {
                    val phys = PadMap.physFor(a, g, tok)
                    val waiting = tok == l
                    val b = Button(a).apply {
                        isAllCaps = false
                        textSize = 13f
                        text = tokenName(tok) + "\n" + when {
                            waiting -> "tekan tombol controller…"
                            phys.isEmpty() -> "(kosong)"
                            else -> phys.joinToString(", ") { physName(it) }
                        }
                        if (waiting) { setBackgroundColor(0xFF2E7D32.toInt()); setTextColor(Color.WHITE) }
                        setOnClickListener { listening = if (waiting) null else tok; refresh() }
                        setOnLongClickListener {
                            PadMap.resetToken(a, g, tok)
                            listening = null
                            Toast.makeText(a, "${tokenName(tok)} kembali ke bawaan", Toast.LENGTH_SHORT).show()
                            refresh(); true
                        }
                    }
                    row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { setMargins(px(4), px(2), px(4), px(2)) })
                }
                if (pair.size < 2) row.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
                grid.addView(row)
            }
        }
        refresh()

        val back = !padMapDirect
        val dialog = AlertDialog.Builder(a)
            .setTitle("Pemetaan tombol: ${PadMap.groupLabel(g)}")
            .setView(root)
            .setNeutralButton("Kombo / lanjutan") { _, _ -> padMapList(a, g) }
            .setPositiveButton("Reset semua", null)   // di-override di bawah supaya layar tidak tertutup
            .setNegativeButton(if (back) "Kembali" else "Tutup") { _, _ -> if (back) padMapSystems(a) }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                PadMap.clear(a, g)
                listening = null
                Toast.makeText(a, "Pemetaan ${PadMap.groupLabel(g)} dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }
        // Satu tempat untuk tombol fisik dan arah stick analog (kode buatan StickKeys): true = kejadian dipakai.
        fun onPhys(keyCode: Int, down: Boolean, first: Boolean): Boolean {
            val tok = listening
            return when {
                !down && swallowUp.remove(keyCode) -> true
                tok == null -> false   // tidak menunggu: biarkan dipakai menavigasi dialog
                down && first -> {
                    if (KeyMap.actionFor(a, keyCode) != null) {
                        Toast.makeText(a, "${physName(keyCode)} dipakai sebagai pintasan aplikasi", Toast.LENGTH_SHORT).show()
                    } else {
                        PadMap.bindToken(a, g, tok, keyCode)
                        swallowUp += keyCode
                        listening = null
                        Toast.makeText(a, "${tokenName(tok)} = ${physName(keyCode)}", Toast.LENGTH_SHORT).show()
                        refresh()
                    }
                    true
                }
                else -> true
            }
        }
        dialog.setOnKeyListener { _, keyCode, ev ->
            val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
            if (!isPadKey || ev.device?.isVirtual != false) false
            else onPhys(keyCode, ev.action == KeyEvent.ACTION_DOWN, ev.repeatCount == 0)
        }
        dialog.show()
        StickKeys.watch(dialog) { _, code, down -> onPhys(code, down, true) }   // arah stick analog juga bisa dipasang
    }

    private fun tokenName(tok: String) = when (tok) {
        "↑" -> "↑ Atas"; "↓" -> "↓ Bawah"; "←" -> "← Kiri"; "→" -> "→ Kanan"
        "SEL" -> "Select"; "START" -> "Start"; "SELECT" -> "Select"; "MODE" -> "Mode"; "KOIN" -> "Koin"
        else -> "Tombol $tok"
    }

    /** Daftar lanjutan: tombol fisik -> tombol game, termasuk kombo (beberapa tombol sekaligus). */
    private fun padMapList(a: Activity, g: String) {
        val ents = PadMap.entries(a, g)
        val rows = (ents.map { (k, spec) -> "${physName(k)}  →  ${specLabel(spec)}" } + "+ Tambah pemetaan").toTypedArray()
        AlertDialog.Builder(a)
            .setTitle("${PadMap.groupLabel(g)}: tombol fisik → tombol game")
            .setItems(rows) { _, i ->
                if (i == ents.size) padMapCapture(a, g, { k -> padMapPick(a, g, k) }) { padMapList(a, g) }
                else padMapEdit(a, g, ents[i])
            }
            .setNeutralButton("Reset") { _, _ ->
                PadMap.clear(a, g)
                Toast.makeText(a, "Pemetaan ${PadMap.groupLabel(g)} dikosongkan", Toast.LENGTH_SHORT).show()
                padMapList(a, g)
            }
            .setNegativeButton("Kembali") { _, _ -> padMapButtons(a, g) }
            .show()
    }

    private fun padMapEdit(a: Activity, g: String, e: Pair<Int, String>) {
        val (phys, spec) = e
        AlertDialog.Builder(a)
            .setTitle("${physName(phys)}  →  ${specLabel(spec)}")
            .setItems(arrayOf("Ubah tombol game / kombo", "Ganti tombol fisik", "Hapus pemetaan")) { _, i ->
                when (i) {
                    0 -> padMapPick(a, g, phys)
                    1 -> padMapCapture(a, g, { k ->
                        if (k != phys) { PadMap.remove(a, g, phys); PadMap.set(a, g, k, spec) }
                        padMapList(a, g)
                    }) { padMapList(a, g) }
                    else -> { PadMap.remove(a, g, phys); padMapList(a, g) }
                }
            }
            .setNegativeButton("Kembali") { _, _ -> padMapList(a, g) }
            .show()
    }

    /** Tekan tombol di controller untuk memilihnya. Tombol yang sudah jadi pintasan aplikasi ditolak. */
    private fun padMapCapture(a: Activity, g: String, onKey: (Int) -> Unit, onCancel: () -> Unit) {
        var done = false
        val dlg = AlertDialog.Builder(a)
            .setTitle("Pilih tombol controller")
            .setMessage("Tekan tombol di controller (atau gerakkan stick analog ke satu arah) yang ingin dipetakan.\n\nTombol yang sudah jadi pintasan aplikasi tidak bisa dipakai di sini.")
            .setNegativeButton("Batal") { _, _ -> onCancel() }
            .setOnCancelListener { if (!done) onCancel() }
            .setOnKeyListener { d, keyCode, ev ->
                val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                    keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                if (isPadKey && ev.device?.isVirtual == false) {
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                        if (KeyMap.actionFor(a, keyCode) != null) {
                            Toast.makeText(a, "${physName(keyCode)} dipakai sebagai pintasan aplikasi", Toast.LENGTH_SHORT).show()
                        } else {
                            done = true
                            d.dismiss()
                            onKey(keyCode)
                        }
                    }
                    true
                } else false
            }
            .show()
        StickKeys.watch(dlg) { _, code, down ->
            if (down && !done) {
                if (KeyMap.actionFor(a, code) != null) {
                    Toast.makeText(a, "${physName(code)} dipakai sebagai pintasan aplikasi", Toast.LENGTH_SHORT).show()
                } else {
                    done = true
                    dlg.dismiss()
                    onKey(code)
                }
            }
        }
    }

    /** Pilih tombol game untuk satu tombol fisik: satu pilihan = pemetaan ulang, beberapa pilihan = kombo (serentak). */
    private fun padMapPick(a: Activity, g: String, phys: Int) {
        val tokens = PadMap.tokens(g)
        val have = (PadMap.specFor(a, g, phys) ?: "").split('+').map { it.trim() }.toSet()
        val checked = BooleanArray(tokens.size) { tokens[it] in have }
        AlertDialog.Builder(a)
            .setTitle("${physName(phys)} menekan (pilih >1 = kombo):")
            .setMultiChoiceItems(tokens.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ ->
                val spec = tokens.filterIndexed { i, _ -> checked[i] }.joinToString("+")
                PadMap.set(a, g, phys, spec)   // kosong = hapus: tombol kembali diteruskan apa adanya
                padMapList(a, g)
            }
            .setNegativeButton("Batal") { _, _ -> padMapList(a, g) }
            .show()
    }

    private fun physName(code: Int) = StickKeys.name(code) ?: KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

    /**
     * Pintasan controller eksternal: daftar perintah aplikasi (simpan/muat state, pengaturan, kembali ke library,
     * keluar aplikasi, terjemahan). Ketuk satu perintah lalu tekan tombol di controller untuk memasangnya.
     */
    fun remap(activity: Activity) {
        val acts = KeyMap.Action.values()
        val rows = acts.map { a -> "${a.label}  →  ${KeyMap.keyFor(activity, a)?.let { physName(it) } ?: "(kosong)"}" }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("Pintasan controller")
            .setItems(rows) { _, i -> remapCapture(activity, acts[i]) }
            .setNeutralButton("Reset") { _, _ ->
                KeyMap.clearAll(activity)
                Toast.makeText(activity, "Pintasan dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
                remap(activity)
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun remapCapture(activity: Activity, a: KeyMap.Action) {
        var captured = false
        val dlg = AlertDialog.Builder(activity)
            .setTitle("Atur pintasan")
            .setMessage("Tekan tombol di controller (atau gerakkan stick analog ke satu arah: kiri/kanan/atas/bawah) untuk:\n\n${a.label}\n\nTombol atau arah ini tidak akan dikirim ke game lagi.")
            .setPositiveButton("Kosongkan") { _, _ -> KeyMap.unbind(activity, a); remap(activity) }
            .setNegativeButton("Batal") { _, _ -> remap(activity) }
            .setOnCancelListener { if (!captured) remap(activity) }
            .setOnKeyListener { d, keyCode, ev ->
                val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                    keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                if (isPadKey && ev.device?.isVirtual == false) {
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                        captured = true
                        KeyMap.bind(activity, a, keyCode)
                        d.dismiss()
                        remap(activity)
                    }
                    true
                } else false
            }
            .show()
        StickKeys.watch(dlg) { _, code, down ->
            if (down && !captured) {
                captured = true
                KeyMap.bind(activity, a, code)
                dlg.dismiss()
                remap(activity)
            }
        }
    }
}
