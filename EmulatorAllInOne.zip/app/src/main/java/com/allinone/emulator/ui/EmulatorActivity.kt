package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Bitmap
import android.content.res.Configuration
import android.graphics.RectF
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.hardware.input.InputManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.format.DateFormat
import android.view.GestureDetector
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.allinone.emulator.R
import com.allinone.emulator.data.ArcadeTuning
import com.allinone.emulator.data.Cheat
import com.allinone.emulator.data.CheatStore
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.Paths
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.input.PadMap
import com.allinone.emulator.input.VirtualPadView
import com.allinone.emulator.translate.FrameCapture
import com.allinone.emulator.translate.TranslationEngine
import com.allinone.emulator.translate.TranslationOverlayView
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.Variable
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlin.math.abs
import kotlin.math.sign

class EmulatorActivity : AppCompatActivity() {

    companion object {
        private const val KEY_RESTORE_CPU = "restore_cpu_state"
        const val EXTRA_ROM = "rom"
        const val EXTRA_CONSOLE = "console"
    }

    private lateinit var game: Game
    private lateinit var settings: Settings
    private lateinit var retroView: GLRetroView
    private lateinit var pad: VirtualPadView
    private lateinit var ffView: android.widget.ImageView
    private lateinit var fpsView: TextView
    private var fpsJob: Job? = null
    private lateinit var overlay: View
    private lateinit var editorBar: View
    private var editing = false
    private lateinit var translator: TranslationEngine
    private lateinit var tOverlay: TranslationOverlayView
    private var tJob: Job? = null
    private var preJob: Job? = null        // tangkap layar + jeda seketika saat tombol terjemahan disentuh (mode dengan jeda)
    private var tPre = false               // true = layar sudah ditangkap dan game sudah dijeda, menunggu ketukan selesai
    private var liveJob: Job? = null       // live translate: pemindaian dialog otomatis berkelanjutan
    private var tFrame: Bitmap? = null
    private var tPaused = false
    private var tActive = false            // terjemahan sedang diproses / ditampilkan
    private var tHasResult = false         // hasil sudah tergambar di layar
    private var tShowingOriginal = false   // true = overlay disembunyikan (lihat teks asli)
    private var tToast: Toast? = null
    private lateinit var inputManager: InputManager

    private val ports = HashMap<Int, Int>()   // deviceId -> port pemain
    private val controllerIds = HashSet<Int>() // gamepad fisik yang sedang terhubung
    private var fastForward = false
    private var openDialogs = 0
    @Volatile private var ready = false
    private var appliedCpu = 100            // kecepatan CPU arcade yang sedang dipakai core
    private var appliedShader = 0           // filter gambar (0 halus, 1 tajam) yang sedang tampil
    private var restoreOnStart = false      // true setelah dimuat ulang karena ganti kecepatan CPU: muat state sementara

    // Save/state tiap core arcade dipisah (format state tidak sama; save lama MAME 2003-Plus tidak boleh dimuat ke MAME 2010)
    private val coreTag get() = game.console.saveTag
    private val sramFile get() = File(Paths.saves(this), "${game.title}$coreTag.sram.bin")
    private fun stateFile(slot: String) = File(Paths.states(this), "${game.title}$coreTag.$slot.state")

    // Pemetaan tombol controller eksternal + kombo (Pengaturan -> Pemetaan tombol controller)
    private val padRouter = PadMap.Router { action, key, port -> retroView.sendKeyEvent(action, key, port) }
    private var padMap: Map<Int, IntArray> = emptyMap()
    private var padMapVer = -1

    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refreshPad()
        override fun onInputDeviceRemoved(deviceId: Int) {
            ports.remove(deviceId)
            controllerIds.remove(deviceId)
            refreshPad()
        }
        override fun onInputDeviceChanged(deviceId: Int) = refreshPad()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val romPath = intent.getStringExtra(EXTRA_ROM)
        val consoleName = intent.getStringExtra(EXTRA_CONSOLE)
        if (romPath == null || consoleName == null) { finish(); return }

        settings = Settings(this)
        appliedCpu = settings.arcadeCpu
        appliedShader = settings.shaderMode
        restoreOnStart = savedInstanceState?.getBoolean(KEY_RESTORE_CPU) == true
        game = Game(File(romPath), Console.valueOf(consoleName))
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setFullscreenCutout(true)     // tampil sampai ke area kamera sejak awal

        // Opsi core. Frame skip: saat ini hanya mGBA yang punya opsi ini.
        val coreVars = mutableListOf<Variable>()
        if (game.console == Console.GBA) coreVars += Variable("mgba_frameskip", settings.frameSkip.toString())
        val arcade = ArcadeTuning.isArcade(game.console)
        if (arcade) coreVars += ArcadeTuning.variables(game.console, settings.arcadePerf, settings.arcadeCpu, game.title)

        val data = GLRetroViewData(this).apply {
            coreFilePath = game.console.core
            gameFilePath = game.file.absolutePath
            systemDirectory = Paths.system(this@EmulatorActivity).absolutePath
            savesDirectory = Paths.saves(this@EmulatorActivity).absolutePath
            shader = settings.shaderConfig()
            skipDuplicateFrames = settings.skipDuplicateFrames
            // Mode audio dipilih di Pengaturan. Stabil (bawaan) = buffer longgar; latensi rendah = buffer kecil yang
            // mudah kosong (underrun) saat emulasi sesaat lambat dan terdengar sebagai kresek-kresek.
            preferLowLatencyAudio = settings.lowLatencyAudio
            rumbleEventsEnabled = false
            saveRAMState = if (sramFile.exists()) sramFile.readBytes() else null
            variables = coreVars.toTypedArray()
        }

        retroView = GLRetroView(this, data)
        // Core baru dimulai setelah layar dikunci ke 60 Hz (LibretroDroid membaca refresh rate sekali saat start)

        pad = VirtualPadView(this).apply {
            opacity = settings.padOpacity
            haptics = settings.haptics
            analogMode = settings.analogPad
            genesisLayout = game.console == Console.GENESIS     // pad 6 tombol ala Mega Drive
            gbaLayout = game.console == Console.GBA             // pad ala Game Boy Advance asli (A/B, L/R)
            arcadeLayout = ArcadeTuning.isArcade(game.console)  // panel arcade: joystick, 6 tombol, koin, start
            snesLayout = game.console == Console.SNES           // pad SNES asli: D-pad polos, belah ketupat ABXY, bahu lebar, Select/Start pil miring
            snesStyle = game.console == Console.SNES            // warna tombol SNES (X/Y ungu muda, A/B ungu tua)
            applyComboSettings(this)                            // tombol kombo (kosong dan tersembunyi sampai diisi lewat atur tata letak)
            onKey = { key, down ->
                retroView.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, key, 0)
            }
            onAnalog = { ax, ay ->
                retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, ax, ay, 0)
            }
            onComboEdit = { slot -> showComboDialog(slot) }   // ketuk slot "+ Kombo" saat mengatur tata letak
        }

        val root = FrameLayout(this).apply {
            // Hitam untuk semua konsol. Latar SNES/Genesis/GBA (warna + logo) baru muncul saat game berjalan, lewat GameBackgroundView
            setBackgroundColor(Color.BLACK)
        }
        // retroView TIDAK dipasang ke layar dulu: permukaan GL baru boleh ada setelah core dibuat (lihat startCore).
        retroView.layoutParams = FrameLayout.LayoutParams(-1, -1, Gravity.CENTER)
        rootView = root
        tOverlay = TranslationOverlayView(this)          // terjemahan digambar di atas teks game
        root.addView(tOverlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        overlay = overlayButtons()
        root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        fpsView = TextView(this).apply {
            setTextColor(Color.GREEN); textSize = 12f; setBackgroundColor(0x99000000.toInt())
            setPadding(dp(6), dp(2), dp(6), dp(2)); visibility = View.GONE
        }
        root.addView(fpsView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        editorBar = buildEditorBar().apply { visibility = View.GONE }
        root.addView(editorBar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        translator = TranslationEngine()
        setContentView(root)
        applyLayout()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    tActive -> closeTranslation()
                    editing -> finishLayoutEdit(false)
                    else -> showMenu()
                }
            }
        })

        updateFpsCounter()
        startCoreAfterRefreshLock()

        // Core dianggap siap beberapa detik setelah dibuka (tanpa bergantung pada API event versi tertentu).
        // Setelah siap: cheat diterapkan dan save otomatis diaktifkan.
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) {
                ready = true
                applyCheats(CheatStore.load(this, game))
                if (restoreOnStart) {
                    restoreOnStart = false
                    val f = stateFile("cpu")
                    if (f.exists()) {
                        try { retroView.unserializeState(f.readBytes()) } catch (_: Exception) {}
                        f.delete()
                    }
                }
            }
        }, 4000)
    }

    // ---------------------------------------------------------------- refresh rate

    private var coreStarted = false
    private var gameBg: View? = null
    private lateinit var rootView: FrameLayout

    private fun startCore() {
        if (coreStarted || isFinishing || isDestroyed) return
        coreStarted = true
        // Urutan wajib: core dibuat dulu (observer), baru layar GL dipasang. Kebalikannya membuat aplikasi crash.
        lifecycle.addObserver(retroView)
        rootView.addView(retroView, 0)
        // Latar bergambar (logo Bit©ade) tepat di atas layar game: hanya menggambar di luar gambar game, tombol tetap di atasnya
        val bg = when (game.console) {
            Console.SNES -> GameBackgroundView(this, retroView, VirtualPadView.SNES_BG, R.drawable.snes_logo, 0.0141f, 0.0778f, 0.1380f)
            Console.GENESIS -> GameBackgroundView(this, retroView, 0xFF1B1C19.toInt(), R.drawable.genesis_logo, 0.0271f, 0.0731f, 0.1401f)
            // GBA: ungu; layar game 3:2
            Console.GBA -> GameBackgroundView(this, retroView, 0xFF4C20B9.toInt(), R.drawable.gba_logo, 0.0057f, 0.0926f, 0.1380f, 3f / 2f)
            else -> null
        }
        if (bg != null) { gameBg = bg; rootView.addView(bg, 1, FrameLayout.LayoutParams(-1, -1)) }
        // Arcade (MAME / FBNeo): latar neon Bit©ade di sekeliling gambar game (ukuran game tidak berubah), selalu tampil
        if (ArcadeTuning.isArcade(game.console)) {
            val ab = ArcadeBackgroundView(this, retroView, R.drawable.arcade_bg)
            gameBg = ab
            rootView.addView(ab, 1, FrameLayout.LayoutParams(-1, -1))
        }
        retroView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateStretch() }
        // Tampilkan penyebab bila core/game gagal dibuka (sebelumnya layar hanya hitam tanpa keterangan)
        lifecycleScope.launch {
            retroView.getGLRetroErrors().collect { code -> showCoreError(code) }
        }
    }

    private var errorShown = false

    private fun showCoreError(code: Int) {
        if (errorShown || isFinishing || isDestroyed) return
        errorShown = true
        val tips = if (game.console == Console.ARCADE_FBNEO)
            "\n\nUntuk game arcade (FBNeo):\n" +
            "• Set ROM harus cocok dengan FBNeo (berbeda dari set MAME 0.139). Bila gagal, coba jalankan dengan MAME 2010.\n" +
            "• Nama file zip harus sama dengan nama game FBNeo; clone butuh zip induk, BIOS (mis. neogeo.zip) harus ada di library yang sama."
        else if (game.console == Console.ARCADE_MAME)
            "\n\nUntuk game arcade (MAME 2010 / set ROM 0.139):\n" +
            "• Nama file zip harus sama dengan nama driver MAME, mis. sfa2.zip (bukan \"Street Fighter Alpha 2.zip\").\n" +
            "• Bila game adalah clone (mis. sfa2u, sfa2ud), zip induknya (sfa2.zip) harus ada di library yang sama.\n" +
            "• BIOS/zip pendukung (mis. neogeo.zip) harus diimpor ke library yang sama.\n" +
            "• Set ROM harus versi MAME 0.139 (format .zip); set versi lain gagal dibuka."
        else if (game.console.isArcade)
            "\n\nUntuk game arcade (${game.console.label}):\n" +
            "• Set ROM harus cocok dengan versi core ini; set versi lain sering gagal dibuka atau crash.\n" +
            "• Nama zip = nama driver; clone butuh zip induk, BIOS harus ada di folder yang sama.\n" +
            "• Coba core lain: tekan lama game di library."
        else ""
        AlertDialog.Builder(this)
            .setTitle("Game gagal dibuka")
            .setMessage("File: ${game.file.name}\nKode error: $code$tips")
            .setCancelable(false)
            .setPositiveButton("Kembali ke library") { _, _ -> finish() }
            .show()
    }

    private var padPresent = false

    /**
     * Dengan gamepad fisik: gambar game diregangkan sampai memenuhi seluruh layar. View game berukuran sesuai rasio
     * game dan berada di tengah layar, jadi cukup diskalakan terhadap pusatnya. Tetap aktif saat terjemahan tampil:
     * lapisan terjemahan diberi transformasi yang sama persis dengan view game, jadi teks tetap pas di atas teks asli
     * dan rasio layar penuh tidak diperkecil. Dimatikan hanya saat mengatur tata letak.
     */
    private fun updateStretch() {
        if (!::retroView.isInitialized || !coreStarted || !::rootView.isInitialized) return
        val w = retroView.width.toFloat(); val h = retroView.height.toFloat()
        val pw = rootView.width.toFloat(); val ph = rootView.height.toFloat()
        if (padPresent && settings.stretchWithPad && !editing && w > 0 && h > 0 && pw > 0 && ph > 0) {
            // View GL berukuran satu layar, tapi gambar game di dalamnya memakai rasio asli (sisanya bilah hitam/latar).
            // Jadi yang diskalakan adalah persegi gambar game-nya, bukan seluruh view, supaya gambar game memenuhi layar.
            val aspect = gameAspect()
            var gw = w; var gh = h
            if (w / h > aspect) gw = h * aspect else gh = w / aspect
            retroView.pivotX = w / 2f
            retroView.pivotY = h / 2f
            retroView.scaleX = pw / gw
            retroView.scaleY = ph / gh
            // Pusatkan persegi gambar game ke pusat layar
            retroView.translationX = pw / 2f - (retroView.left + w / 2f)
            retroView.translationY = ph / 2f - (retroView.top + h / 2f)
            syncOverlayTransform()
            gameBg?.visibility = View.GONE      // latar/logo disembunyikan, hanya gambar game
            if (::overlay.isInitialized) overlay.visibility = View.GONE   // ikon terjemah/ff/pengaturan ikut disembunyikan
        } else {
            retroView.scaleX = 1f
            retroView.scaleY = 1f
            retroView.translationX = 0f
            retroView.translationY = 0f
            syncOverlayTransform()
            gameBg?.visibility = View.VISIBLE
            if (::overlay.isInitialized) overlay.visibility = if (editing) View.GONE else View.VISIBLE
        }
    }

    /** Rasio gambar game (lebar/tinggi): GBA 3:2, sistem lain 4:3. Sama dengan yang dipakai updateStretch(). */
    private fun gameAspect(): Float = if (game.console == Console.GBA) 3f / 2f else 4f / 3f

    /**
     * Persegi gambar game yang benar-benar tampil, dalam koordinat view game (= koordinat frame yang ditangkap).
     * View game selalu seukuran layar, sedangkan gambar game memakai rasio aslinya di tengah (sisanya bilah hitam),
     * baik saat diregangkan maupun tidak. Teks terjemahan dibatasi di persegi ini supaya tidak keluar dari rasio layar game.
     */
    private fun visibleGameRect(fw: Int, fh: Int): RectF {
        val w = fw.toFloat(); val h = fh.toFloat()
        if (w <= 0f || h <= 0f) return RectF(0f, 0f, w, h)
        val aspect = gameAspect()
        var gw = w; var gh = h
        if (w / h > aspect) gw = h * aspect else gh = w / aspect
        val l = (w - gw) / 2f; val t = (h - gh) / 2f
        return RectF(l, t, l + gw, t + gh)
    }

    /**
     * Lapisan terjemahan menggambar dalam koordinat view game (digeser sebesar left/top view game), jadi ia harus
     * memakai skala, titik pusat, dan geseran yang sama dengan view game agar teks tetap menempel di teks aslinya.
     */
    private fun syncOverlayTransform() {
        if (!::tOverlay.isInitialized) return
        tOverlay.pivotX = retroView.left + retroView.width / 2f
        tOverlay.pivotY = retroView.top + retroView.height / 2f
        tOverlay.scaleX = retroView.scaleX
        tOverlay.scaleY = retroView.scaleY
        tOverlay.translationX = retroView.translationX
        tOverlay.translationY = retroView.translationY
    }

    /**
     * Minta layar 60 Hz (mode yang resolusinya sama), tunggu sampai berlaku (maks 1,5 detik), baru jalankan core.
     * Bila perangkat menolak (mis. mode hemat daya), game tetap jalan seperti biasa.
     */
    @Suppress("DEPRECATION")
    private fun startCoreAfterRefreshLock() {
        if (!settings.lock60Hz || Build.VERSION.SDK_INT < Build.VERSION_CODES.M) { startCore(); return }
        val disp = windowManager.defaultDisplay
        if (disp.refreshRate <= 65f) { startCore(); return }
        val cur = disp.mode
        val target = disp.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight && Math.abs(it.refreshRate - 60f) < 1.5f }
            .minByOrNull { Math.abs(it.refreshRate - 60f) }
        if (target == null) { startCore(); return }
        window.attributes = window.attributes.apply { preferredDisplayModeId = target.modeId }
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val handler = Handler(Looper.getMainLooper())
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (windowManager.defaultDisplay.refreshRate <= 65f) {
                    dm.unregisterDisplayListener(this)
                    startCore()
                }
            }
        }
        dm.registerDisplayListener(listener, handler)
        handler.postDelayed({ dm.unregisterDisplayListener(listener); startCore() }, 1500)
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        inputManager.registerInputDeviceListener(deviceListener, null)
        refreshPad()
        hideSystemUi()
    }

    override fun onPause() {
        if (::retroView.isInitialized) persist()
        if (::inputManager.isInitialized) inputManager.unregisterInputDeviceListener(deviceListener)
        super.onPause()
    }

    override fun onDestroy() {
        tJob?.cancel()
        tFrame?.recycle(); tFrame = null
        if (::translator.isInitialized) translator.close()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (tActive) closeTranslation()   // posisi teks tidak berlaku lagi
        applyLayout()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    /** Game selalu lanskap (dikunci di manifest), tampil di tengah layar. */
    private fun applyLayout() {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val lp = retroView.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (portrait) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
        retroView.layoutParams = lp
    }

    /** SRAM (save in-game) + state otomatis, disimpan tiap pause/keluar. */
    private fun persist() {
        if (!ready) return
        try { sramFile.writeBytes(retroView.serializeSRAM()) } catch (_: Exception) {}
        try { stateFile("auto").writeBytes(retroView.serializeState()) } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- input (plug n play)

    /**
     * Gamepad fisik = bukan perangkat virtual, melaporkan sumber gamepad/joystick, dan benar-benar punya tombol gamepad.
     * Pemeriksaan tombol mencegah perangkat bawaan HP yang salah lapor dianggap controller.
     */
    private fun isRealController(d: InputDevice): Boolean {
        if (d.isVirtual) return false
        val s = d.sources
        val padLike = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!padLike) return false
        val has = d.hasKeys(
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X,
            KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_START
        )
        return has.any { it }
    }

    /** Dipanggil saat ada input gamepad nyata: jaring pengaman bila pendeteksian lewat daftar perangkat meleset. */
    private fun noteController(deviceId: Int) {
        if (deviceId < 0 || !controllerIds.add(deviceId)) return
        refreshPad()
    }

    /**
     * Kontrol layar SELALU tampil, kecuali ada gamepad fisik terhubung (dan opsi sembunyikan aktif).
     * Begitu gamepad dicabut/mati, kontrol layar langsung muncul lagi.
     */
    /**
     * Kombo tiap konsol punya isi sendiri (GBA, Genesis, SNES, arcade). Bawaannya kosong (tersembunyi);
     * pengguna membuatnya lewat mode atur tata letak. Saat mengatur, isi yang belum disimpan jangan ditimpa.
     */
    private fun applyComboSettings(p: VirtualPadView) {
        if (editing) return
        when (game.console) {
            Console.GENESIS -> { p.combo1Spec = settings.genesisCombo1; p.combo2Spec = settings.genesisCombo2 }
            Console.GBA -> { p.combo1Spec = settings.gbaCombo1; p.combo2Spec = settings.gbaCombo2 }
            Console.SNES -> { p.combo1Spec = settings.snesCombo1; p.combo2Spec = settings.snesCombo2 }
            else -> { p.combo1Spec = settings.arcadeCombo1; p.combo2Spec = settings.arcadeCombo2 }
        }
    }

    /** Simpan isi kombo yang sedang dipasang di pad ke pengaturan konsol yang sedang dimainkan. */
    private fun saveComboSettings(p: VirtualPadView) {
        when (game.console) {
            Console.GENESIS -> { settings.genesisCombo1 = p.combo1Spec; settings.genesisCombo2 = p.combo2Spec }
            Console.GBA -> { settings.gbaCombo1 = p.combo1Spec; settings.gbaCombo2 = p.combo2Spec }
            Console.SNES -> { settings.snesCombo1 = p.combo1Spec; settings.snesCombo2 = p.combo2Spec }
            else -> { settings.arcadeCombo1 = p.combo1Spec; settings.arcadeCombo2 = p.combo2Spec }
        }
    }

    private fun refreshPad() {
        if (!::pad.isInitialized) return
        val present = HashSet<Int>()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (isRealController(d)) present += id
        }
        // Pertahankan yang terdeteksi lewat input, selama perangkatnya masih ada.
        for (id in controllerIds) if (InputDevice.getDevice(id) != null) present += id
        controllerIds.clear()
        controllerIds.addAll(present)

        pad.opacity = settings.padOpacity
        pad.haptics = settings.haptics
        pad.analogMode = settings.analogPad
        applyComboSettings(pad)
        val hide = !editing && settings.autoHidePad && controllerIds.isNotEmpty()
        if (hide) pad.releaseTouches()          // lepaskan tombol layar yang mungkin masih tertahan
        pad.visibility = if (hide) View.GONE else View.VISIBLE
        setFullscreenCutout(true)
        padPresent = controllerIds.isNotEmpty()
        updateStretch()
    }

    /** Game selalu menempati seluruh layar, termasuk area poni/lubang kamera (dengan atau tanpa gamepad fisik). */
    private fun setFullscreenCutout(full: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        val mode = when {
            !full -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val attrs = window.attributes
        if (attrs.layoutInDisplayCutoutMode != mode) {
            attrs.layoutInDisplayCutoutMode = mode
            window.attributes = attrs
        }
    }

    /** Gamepad pertama = pemain 1, dst. Port dibebaskan lagi saat gamepad dicabut. */
    private fun portFor(deviceId: Int): Int = ports.getOrPut(deviceId) {
        (0..3).firstOrNull { it !in ports.values } ?: 0
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (KeyEvent.isGamepadButton(code) && e.device?.isVirtual == false) noteController(e.deviceId)
        val isPadKey = KeyEvent.isGamepadButton(code) ||
            code in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        // Pintasan controller: tombol yang dipasang ke perintah aplikasi tidak diteruskan ke game.
        if (isPadKey && !editing && e.device?.isVirtual == false) {
            val act = KeyMap.actionFor(this, code)
            if (act != null) {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) runHotkey(act)
                return true
            }
        }
        if (editing && isPadKey) return true
        if (::retroView.isInitialized && isPadKey && e.repeatCount == 0) {
            if (padMapVer != PadMap.version) {
                padMap = PadMap.load(this, PadMap.group(game.console)); padMapVer = PadMap.version
            }
            padRouter.handle(e.action, e.deviceId, code, portFor(e.deviceId), padMap)
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun runHotkey(a: KeyMap.Action) {
        if (!::retroView.isInitialized || !ready) return
        when (a) {
            KeyMap.Action.SAVE_STATE -> saveState("1")
            KeyMap.Action.LOAD_STATE -> loadState("1")
            KeyMap.Action.SETTINGS -> openSettings()
            KeyMap.Action.LIBRARY -> finish()
            KeyMap.Action.EXIT_APP -> finishAffinity()
            KeyMap.Action.TRANSLATE -> toggleTranslation()
        }
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isStick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!::retroView.isInitialized || !isStick || ev.action != MotionEvent.ACTION_MOVE) {
            return super.dispatchGenericMotionEvent(ev)
        }
        noteController(ev.deviceId)
        val port = portFor(ev.deviceId)
        val hatX = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val lx = ev.getAxisValue(MotionEvent.AXIS_X)
        val ly = ev.getAxisValue(MotionEvent.AXIS_Y)
        // Konsol 2D tidak punya analog: stick kiri juga dipakai sebagai D-pad.
        fun digital(v: Float) = if (abs(v) < 0.35f) 0f else sign(v)
        retroView.sendMotionEvent(
            GLRetroView.MOTION_SOURCE_DPAD,
            if (hatX != 0f) hatX else digital(lx),
            if (hatY != 0f) hatY else digital(ly),
            port
        )
        retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, lx, ly, port)
        retroView.sendMotionEvent(
            GLRetroView.MOTION_SOURCE_ANALOG_RIGHT,
            ev.getAxisValue(MotionEvent.AXIS_Z), ev.getAxisValue(MotionEvent.AXIS_RZ), port
        )
        return true
    }

    // ---------------------------------------------------------------- UI overlay & menu

    private fun overlayButtons(): View {
        fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { onClick() }
        }
        // Tombol fast forward: gambar panah ganda biru (menggantikan emoji ⏩); aktif = lebih terang dan sedikit membesar
        ffView = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_fast_forward)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(46)).apply { gravity = Gravity.CENTER_VERTICAL }
            alpha = 0.7f
            setOnClickListener { toggleFastForward() }
        }
        return LinearLayout(this).apply {
            alpha = 0.55f
            // Tombol terjemahan: gambar balon A/文 dengan panah (menggantikan 🌐)
            addView(android.widget.ImageView(this@EmulatorActivity).apply {
                setImageResource(R.drawable.ic_translate)
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { gravity = Gravity.CENTER_VERTICAL }
                // Ketuk 1x = terjemahkan / tutup terjemahan. Ketuk 2x cepat = pilih mesin terjemahan (online / offline).
                val gd = GestureDetector(this@EmulatorActivity, object : GestureDetector.SimpleOnGestureListener() {
                    override fun onDown(e: MotionEvent) = true
                    override fun onSingleTapConfirmed(e: MotionEvent): Boolean { toggleTranslation(); return true }
                    override fun onDoubleTap(e: MotionEvent): Boolean { showTranslateEngineChooser(); cancelPreCapture(); return true }
                })
                // Tahan 3 detik = pilih jenis teks (dialog / menu awal game).
                val holdHandler = Handler(Looper.getMainLooper())
                var held = false
                var downX = 0f
                var downY = 0f
                val slop = android.view.ViewConfiguration.get(this@EmulatorActivity).scaledTouchSlop
                val holdRun = Runnable {
                    held = true
                    performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    showTranslateKindChooser()
                    cancelPreCapture()
                }
                @Suppress("ClickableViewAccessibility")
                setOnTouchListener { v, ev ->
                    when (ev.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            held = false; downX = ev.x; downY = ev.y
                            holdHandler.postDelayed(holdRun, 3000L)
                            preCaptureForPause()    // mode dengan jeda: tangkap layar lalu jeda game SEKARANG, tanpa menunggu ketukan selesai
                        }
                        MotionEvent.ACTION_MOVE ->
                            if (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop) {
                                holdHandler.removeCallbacks(holdRun)
                                cancelPreCapture()  // jari bergeser: bukan ketukan, batalkan jeda
                            }
                        MotionEvent.ACTION_UP -> holdHandler.removeCallbacks(holdRun)
                        MotionEvent.ACTION_CANCEL -> { holdHandler.removeCallbacks(holdRun); cancelPreCapture() }
                    }
                    // Setelah tahan 3 detik terpicu, lepas jari tidak boleh dianggap ketukan (tidak menerjemahkan).
                    val handled = if (held) true else gd.onTouchEvent(ev)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && !held) v.performClick()
                    handled
                }
            })
            addView(ffView)
            // Tombol pengaturan: gambar roda gigi (menggantikan ☰), ukurannya setara tombol teks di sebelahnya
            addView(android.widget.ImageView(this@EmulatorActivity).apply {
                setImageResource(R.drawable.ic_settings_gear)
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { gravity = Gravity.CENTER_VERTICAL }
                setOnClickListener { showMenu() }
            })
        }
    }

    private fun toggleFastForward() {
        fastForward = !fastForward
        retroView.frameSpeed = if (fastForward) settings.fastForward else 1
        ffView.alpha = if (fastForward) 1f else 0.7f
        ffView.scaleX = if (fastForward) 1.15f else 1f
        ffView.scaleY = if (fastForward) 1.15f else 1f
    }

    /** Dialog yang menjeda game selama terbuka. */
    private fun dlg(b: AlertDialog.Builder) {
        if (openDialogs == 0) retroView.onPause()
        openDialogs++
        b.setOnDismissListener {
            openDialogs--
            if (openDialogs == 0) retroView.onResume()
        }
        b.show()
    }

    private fun showMenu() {
        val items = arrayOf(
            "Lanjutkan",
            "Simpan state",
            "Muat state",
            "Cheat code",
            "Atur tata letak kontrol",
            "Pintasan controller",
            "Pengaturan",
            "Reset game",
            "Keluar ke library"
        )
        dlg(AlertDialog.Builder(this).setTitle(game.title).setItems(items) { _, i ->
            when (i) {
                1 -> showSlots(true)
                2 -> showSlots(false)
                3 -> showCheats()
                4 -> startLayoutEdit()
                5 -> Menus.remap(this)
                6 -> openSettings()
                7 -> retroView.reset()
                8 -> finish()
            }
        })
    }

    /** Pengaturan tetap terbuka (game tetap dijeda) sampai ditutup; tidak kembali ke layar game tiap kali mengubah. */
    private var settingsDialog: AlertDialog? = null

    private fun openSettings() {
        // Game arcade tetap berjalan di belakang menu pengaturan, supaya perubahan performa/CPU langsung terlihat
        // (menu utama yang menutup sendiri akan melanjutkan game). Sistem lain tetap dijeda selama pengaturan terbuka.
        val pauseGame = !ArcadeTuning.isArcade(game.console)
        if (pauseGame) {
            if (openDialogs == 0) retroView.onPause()
            openDialogs++
        }
        settingsDialog = Menus.settings(
            this, settings,
            extra = { translationExtras() },
            padGroup = PadMap.group(game.console),
            arcadeGame = ArcadeTuning.isArcade(game.console),
            onClosed = {
                settingsDialog = null
                if (pauseGame) {
                    openDialogs--
                    if (openDialogs == 0) retroView.onResume()
                }
                restartIfCpuChanged()
            }
        ) { applySettingsLive() }
    }

    /**
     * Kecepatan CPU hanya bisa diubah di FBNeo; core MAME 2010 tidak punya opsi ini. Agar perubahan tetap langsung terasa di game,
     * core dimuat ulang otomatis begitu pengaturan ditutup, dan posisi permainan dikembalikan lewat state sementara.
     */
    private fun restartIfCpuChanged() {
        if (game.console != Console.ARCADE_MAME || isFinishing || isDestroyed) return
        val wanted = ArcadeTuning.snapCpu(game.console, settings.arcadeCpu)
        if (wanted == ArcadeTuning.snapCpu(game.console, appliedCpu)) return
        restoreOnStart = false
        if (ready) {
            try {
                stateFile("cpu").writeBytes(retroView.serializeState())
                restoreOnStart = true
            } catch (_: Exception) {}
        }
        recreate()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_RESTORE_CPU, restoreOnStart)
    }

    private fun applySettingsLive() {
        if (fastForward) retroView.frameSpeed = settings.fastForward
        updateFpsCounter()
        applyShaderLive()
        // Profil performa arcade langsung berlaku (core membaca ulang opsi di frame berikutnya)
        if (ArcadeTuning.isArcade(game.console)) {
            val live = ArcadeTuning.liveVariables(game.console, settings.arcadePerf, settings.arcadeCpu, game.title)
            if (live.isNotEmpty()) retroView.updateVariables(*live.toTypedArray())
            // (MAME 2010 tidak punya opsi kecepatan CPU, jadi tidak ada muat ulang)
            if (game.console == Console.ARCADE_MAME &&
                ArcadeTuning.snapCpu(game.console, settings.arcadeCpu) != ArcadeTuning.snapCpu(game.console, appliedCpu)
            ) {
                toast("Kecepatan CPU diterapkan, game dimuat ulang…")
                settingsDialog?.dismiss() ?: restartIfCpuChanged()
                return
            }
        }
        refreshPad()
    }

    /**
     * Filter gambar (halus/tajam) langsung berlaku begitu dipilih, tanpa memulai ulang game.
     * Utama: ganti shader di GLRetroView yang sedang berjalan. Bila versi LibretroDroid tidak mengizinkan,
     * cadangan: simpan state, muat ulang core, lalu kembalikan posisi permainan (seperti ganti CPU arcade).
     */
    private fun applyShaderLive() {
        val mode = settings.shaderMode
        if (mode == appliedShader) return
        val ok = try {
            retroView.javaClass.getMethod("setShader", settings.shaderConfig().javaClass.superclass ?: ShaderConfig::class.java)
                .invoke(retroView, settings.shaderConfig())
            true
        } catch (_: Throwable) {
            try {
                val m = retroView.javaClass.methods.first { it.name == "setShader" && it.parameterTypes.size == 1 }
                m.invoke(retroView, settings.shaderConfig())
                true
            } catch (_: Throwable) { false }
        }
        appliedShader = mode
        if (ok) return
        toast("Filter diterapkan, game dimuat ulang…")
        restoreOnStart = false
        if (ready) {
            try {
                stateFile("cpu").writeBytes(retroView.serializeState())
                restoreOnStart = true
            } catch (_: Exception) {}
        }
        recreate()
    }

    /**
     * Penghitung FPS: jumlah frame yang selesai diproses core per detik (core berjalan di thread GL, jadi bila core
     * kewalahan angkanya turun di bawah kecepatan asli game, ±57-60). Juga menampilkan core, profil, dan refresh layar.
     */
    private fun updateFpsCounter() {
        fpsJob?.cancel()
        if (!settings.showFps) { fpsView.visibility = View.GONE; return }
        fpsView.visibility = View.VISIBLE
        val info = "${game.console.name} P${settings.arcadePerf} CPU${settings.arcadeCpu}%"
        fpsJob = lifecycleScope.launch {
            var count = 0
            var t0 = SystemClock.elapsedRealtime()
            retroView.getGLRetroEvents().collect { ev ->
                if (ev is GLRetroView.GLRetroEvents.FrameRendered) {
                    count++
                    val now = SystemClock.elapsedRealtime()
                    if (now - t0 >= 1000) {
                        // Refresh rate layar dibaca ulang tiap detik (bukan sekali), supaya terlihat bila layar
                        // berpindah ke 90/120 Hz saat disentuh, yang bisa membuat game berjalan lebih cepat.
                        val hzNow = try { windowManager.defaultDisplay.refreshRate } catch (_: Exception) { 0f }
                        fpsView.text = "%.0f FPS  %s  %dHz".format(count * 1000f / (now - t0), info, hzNow.toInt())
                        count = 0; t0 = now
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- terjemahan dialog

    /** Tahan 3 detik logo terjemahan: pilih jenis teks. Dialog = balon/kotak dialog; Menu = Start, Option, Load, dll. */
    private fun showTranslateKindChooser() {
        val items = arrayOf(
            "Dialog: balon/kotak dialog saat bermain",
            "Menu awal game: tulisan Start, Option, Load, Save, dll. satu per satu"
        )
        dlg(AlertDialog.Builder(this)
            .setTitle("Jenis teks yang diterjemahkan")
            .setSingleChoiceItems(items, settings.translateKind) { d, which ->
                val changed = settings.translateKind != which
                settings.translateKind = which
                d.dismiss()
                status("Jenis teks: ${if (which == 1) "Menu awal game" else "Dialog"}")
                // Terjemahan sedang tampil: terjemahkan ulang layar yang sama dengan jenis teks yang baru.
                if (changed && tActive && tHasResult) startTranslation(thorough = false, reuse = true)
            }
            .setNegativeButton("Batal", null))
    }

    /** Ketuk 2x logo terjemahan: pilih mesin terjemahan. Online = Google Translate atau Groq, Offline = ML Kit saja. */
    private fun showTranslateEngineChooser() {
        val items = arrayOf(
            "Online (Google Translate): lebih akurat, wajib internet",
            "Online (Groq): terjemahan AI, wajib internet + API key Groq",
            "Offline (ML Kit): tanpa internet, kurang akurat"
        )
        val cur = if (!settings.translateOnline) 2 else if (settings.onlineEngine == 1) 1 else 0
        dlg(AlertDialog.Builder(this)
            .setTitle("Mesin terjemahan")
            .setSingleChoiceItems(items, cur) { d, which ->
                val changed = which != cur
                settings.translateOnline = which != 2
                if (which != 2) settings.onlineEngine = which
                d.dismiss()
                status("Mesin terjemahan: " + when (which) { 0 -> "Online (Google)"; 1 -> "Online (Groq)"; else -> "Offline (ML Kit)" })
                if (which == 1 && settings.groqKey.isEmpty()) status("API key Groq belum diisi: Pengaturan > Terjemahan", true)
                // Terjemahan sedang tampil: terjemahkan ulang layar yang sama dengan mesin yang baru dipilih.
                if (changed && tActive && tHasResult) startTranslation(thorough = false, reuse = true)
            }
            .setNegativeButton("Batal", null))
    }

    /** Pilih mode terjemahan: dengan jeda (game berhenti selama terjemahan tampil) atau tanpa jeda (game tetap berjalan). */
    private fun showTranslateModeChooser() {
        val items = arrayOf(
            "Dengan jeda: game berhenti selama terjemahan tampil, teks tidak bergeser",
            "Tanpa jeda: game tetap berjalan saat terjemahan tampil"
        )
        dlg(AlertDialog.Builder(this)
            .setTitle("Mode terjemahan")
            .setSingleChoiceItems(items, if (settings.translateLive) 1 else 0) { d, which ->
                val live = which == 1
                val changed = settings.translateLive != live
                settings.translateLive = live
                d.dismiss()
                status("Mode terjemahan: ${if (live) "tanpa jeda" else "dengan jeda"}")
                // Terjemahan sedang tampil: sesuaikan jeda game dengan mode yang baru dipilih.
                if (changed && tActive) {
                    if (live && tPaused) {
                        tPaused = false
                        openDialogs--
                        if (openDialogs == 0) retroView.onResume()
                    } else if (!live) pauseForOverlay()
                }
            }
            .setNegativeButton("Batal", null))
    }

    /**
     * Mode dengan jeda: begitu tombol terjemahan disentuh, layar langsung ditangkap dan game langsung dijeda, tanpa
     * menunggu ketukan selesai (deteksi ketuk 2x butuh ±0,3 detik) dan tanpa menunggu teks "stabil". Yang diterjemahkan
     * persis tulisan yang ada di layar saat tombol disentuh, jadi tidak terlewat.
     */
    private fun preCaptureForPause() {
        if (tActive || editing || tPre || tPaused || settings.translateAuto || settings.translateLive) return
        tPre = true
        preJob = lifecycleScope.launch {
            val f = FrameCapture.grab(retroView)       // ditangkap sebelum jeda: permukaan GL yang dijeda bisa kosong
            if (f != null) {
                tFrame?.recycle(); tFrame = f
                pauseForOverlay()
            } else tPre = false
        }
    }

    /** Sentuhan ternyata bukan ketukan terjemahan (ketuk 2x, tahan, atau jari bergeser): lepaskan jeda dan buang tangkapan. */
    private fun cancelPreCapture() {
        preJob?.cancel(); preJob = null
        if (!tPre) return
        tPre = false
        if (tActive) return
        tFrame?.recycle(); tFrame = null
        if (tPaused) {
            tPaused = false
            openDialogs--
            if (openDialogs == 0) retroView.onResume()
        }
    }

    private fun toggleTranslation() {
        if (tActive) { closeTranslation(); return }
        if (settings.translateAuto) { cancelPreCapture(); startLive(); return }
        if (tPre && tPaused && tFrame != null) {
            tPre = false
            startTranslation(thorough = false, reuse = true)    // pakai tangkapan saat disentuh; game sudah berhenti
        } else {
            cancelPreCapture()
            startTranslation(thorough = false, reuse = false)
        }
    }

    /**
     * Live translate (khusus dialog): game tetap berjalan; SELURUH layar dipantau terus. Teks yang masih muncul huruf
     * demi huruf TIDAK diterjemahkan. Dialog baru ditampilkan setelah kalimatnya utuh, dengan dua penjaga:
     * (1) layar harus diam dua pemeriksaan berturut-turut sebelum dibaca; (2) hasil baca harus sama dua kali berturut-turut
     * (teks yang masih bertambah selalu berbeda tiap dibaca). Terjemahan lama hilang saat dialog berganti.
     */
    private fun startLive() {
        if (editing || liveJob?.isActive == true) return
        tJob?.cancel()
        tActive = true
        updateStretch()
        tHasResult = false
        tShowingOriginal = false
        tOverlay.clear()
        tOverlay.visibility = View.VISIBLE
        status("Live translate dialog aktif (seluruh layar). Ketuk logo terjemahan lagi untuk berhenti.")
        liveJob = lifecycleScope.launch {
            var lastSig = ""        // teks dialog yang sedang tampil terjemahannya
            var pendingSig = ""     // hasil baca terakhir yang belum terbukti utuh
            var pendingCount = 0
            try {
                while (isActive) {
                    delay(if (pendingSig.isEmpty()) 600 else 450)
                    if (openDialogs > 0 || tShowingOriginal) continue          // menu terbuka / sedang melihat teks asli
                    var f = FrameCapture.grab(retroView) ?: continue
                    val shown = tFrame
                    // Layar sama dengan yang terakhir dibaca dan tidak ada bacaan yang menunggu bukti: lewati
                    if (pendingSig.isEmpty() && shown != null && FrameCapture.frameDiff(shown, f) <= 0.0005f) { f.recycle(); continue }
                    // Penjaga 1: tunggu layar diam 2 kali berturut-turut (teks tidak lagi bertambah). Latar yang terus bergerak
                    // tidak pernah diam, jadi maksimal 8 kali menunggu; penjaga 2 yang menentukan.
                    var calmRun = 0
                    var tries = 0
                    while (calmRun < 2 && tries < 8) {
                        delay(200)
                        val g = FrameCapture.grab(retroView) ?: break
                        calmRun = if (FrameCapture.frameDiff(f, g) <= 0.0005f) calmRun + 1 else 0
                        f.recycle(); f = g
                        tries++
                    }
                    translator.online = settings.translateOnline
                translator.onlineEngine = settings.onlineEngine
                translator.groqKey = settings.groqKey
                translator.groqModel = settings.groqModel
                    translator.menuMode = false                                       // live translate: dialog saja
                    translator.jaGlossaryFile = Paths.glossaryJa(this@EmulatorActivity)
                    translator.glyphFile = Paths.glyphBank(this@EmulatorActivity)
                    val result = translator.run(f, settings.translateSource, false, false, Paths.glossary(this@EmulatorActivity),   // false = seluruh layar
                        when (game.console) {
                            Console.GBA -> intArrayOf(240, 160)
                            Console.SNES -> intArrayOf(256, 224)
                            Console.GENESIS -> intArrayOf(320, 224)
                            else -> null
                        }) { msg ->
                        withContext(Dispatchers.Main.immediate) {
                            if (msg.isEmpty()) tToast?.cancel() else status(msg, true)
                        }
                    }
                    tFrame?.recycle(); tFrame = f                                     // pembanding berikutnya
                    val shownBlocks = result?.blocks?.filter { it.box != null }.orEmpty()
                    if (shownBlocks.isEmpty()) {
                        // Tidak ada dialog di layar
                        if (tHasResult) { tOverlay.clear(); tHasResult = false }
                        lastSig = ""; pendingSig = ""; pendingCount = 0
                    } else {
                        val sig = shownBlocks.joinToString("|") { it.original }.filterNot { it.isWhitespace() }
                        when {
                            sig == lastSig && tHasResult -> { pendingSig = ""; pendingCount = 0 }   // dialog sama, sudah tampil
                            sig == pendingSig || pendingCount >= 3 -> {
                                // Hasil baca sama dua kali berturut-turut (atau sudah 3 kali dibaca): kalimat sudah utuh
                                tOverlay.show(
                                    result!!.blocks, result.frameW, result.frameH,
                                    retroView.left.toFloat(), retroView.top.toFloat(),
                                    visibleGameRect(result.frameW, result.frameH),
                                    settings.translateFontMin, settings.translateFontMax
                                )
                                tHasResult = true
                                lastSig = sig; pendingSig = ""; pendingCount = 0
                            }
                            else -> {
                                // Teks masih berubah (belum utuh): jangan tampilkan, baca lagi sebentar lagi
                                if (tHasResult) { tOverlay.clear(); tHasResult = false; lastSig = "" }
                                pendingSig = sig; pendingCount++
                            }
                        }
                    }
                    if (pendingSig.isEmpty()) delay(700)                              // jeda agar latar ramai tidak membebani HP
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status(
                    if (settings.translateOnline) "Live translate berhenti: ${e.message ?: e.javaClass.simpleName}."
                    else "Live translate berhenti: ${e.message ?: e.javaClass.simpleName}. Model offline butuh internet saat pertama dipakai.",
                    true
                )
                closeTranslation()
            }
        }
    }

    /** Pesan singkat (toast) supaya layar game tidak tertutup panel apa pun. */
    private fun status(msg: String, long: Boolean = false) {
        tToast?.cancel()
        tToast = Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).also { it.show() }
    }

    /** Pilihan tambahan di Pengaturan, hanya ada saat terjemahan sedang tampil di layar. */
    private fun translationExtras(): List<Pair<String, (() -> Unit) -> Unit>> {
        val diag: (() -> Unit) -> Unit = {
            AlertDialog.Builder(this)
                .setTitle("Hasil baca OCR terakhir")
                .setMessage(translator.lastDebug.ifBlank { "(belum ada hasil baca)" })
                .setPositiveButton("Tutup", null)
                .show()
        }
        val diagItem = Pair("Diagnosis: apa yang dibaca OCR terakhir", diag)
        val modeItem = Pair<String, (() -> Unit) -> Unit>(
            "Mode terjemahan: ${if (settings.translateLive) "tanpa jeda" else "dengan jeda"} (ketuk untuk ganti)"
        ) { dismiss -> dismiss(); showTranslateModeChooser() }
        val liveItem = Pair<String, (() -> Unit) -> Unit>(
            "Live translate dialog: ${if (settings.translateAuto) "aktif" else "mati"} (ketuk untuk ganti)"
        ) { dismiss ->
            settings.translateAuto = !settings.translateAuto
            dismiss()
            if (settings.translateAuto) {
                if (tActive) closeTranslation()
                startLive()
            } else {
                if (liveJob?.isActive == true) closeTranslation()
                status("Live translate dialog mati")
            }
        }
        if (liveJob?.isActive == true) return listOf(liveItem, diagItem)
        if (!tActive || !tHasResult) return listOf(liveItem, modeItem, diagItem)
        val toggleText: (() -> Unit) -> Unit = {
            tShowingOriginal = !tShowingOriginal
            tOverlay.visibility = if (tShowingOriginal) View.GONE else View.VISIBLE
        }
        val rescan: (() -> Unit) -> Unit = { dismiss ->
            dismiss()
            startTranslation(thorough = true, reuse = true)
        }
        return listOf(
            liveItem,
            modeItem,
            Pair("Teks di layar: ${if (tShowingOriginal) "asli" else "terjemahan"} (ketuk untuk ganti)", toggleText),
            Pair("Baca ulang terjemahan (mode teliti)", rescan),
            diagItem
        )
    }

    private fun startTranslation(thorough: Boolean, reuse: Boolean) {
        if (editing || liveJob?.isActive == true) return
        tJob?.cancel()
        tJob = lifecycleScope.launch {
            var frame = if (reuse) tFrame else null
            if (frame == null) {
                frame = FrameCapture.grabStable(retroView)      // ditangkap saat game masih berjalan, setelah teks selesai muncul
                if (frame == null) {
                    status(if (FrameCapture.supported()) "Gagal menangkap layar game" else "Terjemahan butuh Android 7.0 ke atas")
                    return@launch
                }
                tFrame?.recycle()
                tFrame = frame
            }
            tActive = true
            updateStretch()
            tHasResult = false
            tShowingOriginal = false
            if (!settings.translateLive) pauseForOverlay()   // mode tanpa jeda: game tetap berjalan
            tOverlay.clear()
            tOverlay.visibility = View.VISIBLE
            try {
                translator.online = settings.translateOnline
                translator.onlineEngine = settings.onlineEngine
                translator.groqKey = settings.groqKey
                translator.groqModel = settings.groqModel
                translator.menuMode = settings.translateKind == 1
                translator.jaGlossaryFile = Paths.glossaryJa(this@EmulatorActivity)
                translator.glyphFile = Paths.glyphBank(this@EmulatorActivity)
                val result = translator.run(frame, settings.translateSource, settings.translateBottomOnly, thorough, Paths.glossary(this@EmulatorActivity),
                    when (game.console) {
                        Console.GBA -> intArrayOf(240, 160)
                        Console.SNES -> intArrayOf(256, 224)
                        Console.GENESIS -> intArrayOf(320, 224)
                        else -> null
                    }) { msg ->
                    // Satu-satunya kabar progres yang tampil: unduhan model bahasa (kosong = selesai)
                    withContext(Dispatchers.Main.immediate) {
                        if (msg.isEmpty()) tToast?.cancel() else status(msg, true)
                    }
                }
                when {
                    result == null -> {
                        status("${if (settings.translateKind == 1) "Menu" else "Teks"} tidak terbaca ${translator.debugSummary()}", true)   // pendek: toast dipotong 2 baris
                        closeTranslation()
                    }
                    result.blocks.none { it.box != null } && result.failed > 0 -> {
                        status("Teks terbaca acak/tidak jelas, jadi tidak ditimpa. Coba lagi saat dialog sudah tampil penuh, atau pakai \"Baca ulang terjemahan (mode teliti)\".", true)
                        closeTranslation()
                    }
                    result.blocks.none { it.box != null } -> {
                        status("Tidak ada teks yang perlu diterjemahkan (sudah berbahasa Indonesia, atau hanya nama/angka).", true)
                        closeTranslation()
                    }
                    else -> {
                        tOverlay.show(
                            result.blocks, result.frameW, result.frameH,
                            retroView.left.toFloat(), retroView.top.toFloat(),
                            visibleGameRect(result.frameW, result.frameH),
                            settings.translateFontMin, settings.translateFontMax
                        )
                        tHasResult = true
                        tToast?.cancel()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status(
                    if (settings.translateOnline) "Gagal: ${e.message ?: e.javaClass.simpleName}."
                    else "Gagal: ${e.message ?: e.javaClass.simpleName}. Model terjemahan offline diunduh sekali saat pertama dipakai, jadi butuh internet.",
                    true
                )
                closeTranslation()
            }
        }
    }

    private fun pauseForOverlay() {
        if (tPaused) return
        tPaused = true
        if (openDialogs == 0) retroView.onPause()
        openDialogs++
    }

    private fun closeTranslation() {
        tJob?.cancel()
        liveJob?.cancel(); liveJob = null
        tActive = false
        updateStretch()
        tHasResult = false
        tShowingOriginal = false
        tOverlay.clear()
        tOverlay.visibility = View.VISIBLE
        if (tPaused) {
            tPaused = false
            openDialogs--
            if (openDialogs == 0) retroView.onResume()
        }
        tFrame?.recycle(); tFrame = null
    }

    // ---------------------------------------------------------------- save / load state

    private fun slotLabel(slot: String): String {
        val f = stateFile(slot)
        val name = if (slot == "auto") "Otomatis" else "Slot $slot"
        return if (f.exists()) "$name — ${DateFormat.format("dd MMM HH:mm", f.lastModified())}" else "$name — kosong"
    }

    private fun showSlots(save: Boolean) {
        val slots = if (save) listOf("1", "2", "3", "4", "5") else listOf("auto", "1", "2", "3", "4", "5")
        dlg(
            AlertDialog.Builder(this)
                .setTitle(if (save) "Simpan state" else "Muat state")
                .setItems(slots.map { slotLabel(it) }.toTypedArray()) { _, i ->
                    if (save) saveState(slots[i]) else loadState(slots[i])
                }
        )
    }

    private fun saveState(slot: String) {
        try {
            stateFile(slot).writeBytes(retroView.serializeState())
            toast("State tersimpan")
        } catch (e: Exception) {
            toast("Gagal menyimpan state")
        }
    }

    private fun loadState(slot: String) {
        val f = stateFile(slot)
        if (!f.exists()) { toast("Slot kosong"); return }
        val ok = try { retroView.unserializeState(f.readBytes()) } catch (e: Exception) { false }
        toast(if (ok) "State dimuat" else "Gagal memuat state")
    }

    // ---------------------------------------------------------------- cheat

    private fun applyCheats(list: List<Cheat>) {
        if (!ready) return
        list.forEachIndexed { i, c -> retroView.setCheat(i, c.enabled, c.code) }
    }

    private fun showCheats() {
        val cheats = CheatStore.load(this, game)
        val checked = cheats.map { it.enabled }.toBooleanArray()
        dlg(
            AlertDialog.Builder(this)
                .setTitle("Cheat code")
                .setMultiChoiceItems(cheats.map { it.name }.toTypedArray(), checked) { _, i, on -> checked[i] = on }
                .setPositiveButton("Terapkan") { _, _ ->
                    cheats.forEachIndexed { i, c -> c.enabled = checked[i] }
                    CheatStore.save(this, game, cheats)
                    applyCheats(cheats)
                    toast("Cheat diterapkan")
                }
                .setNeutralButton("Tambah…") { _, _ -> addCheat(cheats) }
                .setNegativeButton("Hapus yang dicentang") { _, _ ->
                    cheats.forEachIndexed { i, c -> if (ready) retroView.setCheat(i, false, c.code) }
                    val keep = cheats.filterIndexed { i, _ -> !checked[i] }
                    CheatStore.save(this, game, keep)
                    applyCheats(keep)
                }
        )
    }

    private fun addCheat(cheats: MutableList<Cheat>) {
        val name = EditText(this).apply { hint = "Nama (mis. Nyawa tak terbatas)" }
        val code = EditText(this).apply { hint = "Kode (format sesuai core: Game Genie / GameShark / AR)" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(name); addView(code)
        }
        dlg(
            AlertDialog.Builder(this).setTitle("Tambah cheat").setView(box)
                .setPositiveButton("Simpan") { _, _ ->
                    val n = name.text.toString().trim()
                    val c = code.text.toString().trim()
                    if (n.isNotEmpty() && c.isNotEmpty()) {
                        cheats += Cheat(n, c, false)
                        CheatStore.save(this, game, cheats)
                        toast("Cheat ditambahkan — buka Cheat code untuk mengaktifkan")
                    }
                }
                .setNegativeButton("Batal", null)
        )
    }

    // ---------------------------------------------------------------- atur tata letak kontrol

    /** Isi kombo saat mulai mengatur, untuk dikembalikan bila pengguna menekan Batal. */
    private var comboBackup: Pair<String, String>? = null

    /** Pilih tombol apa saja yang ditekan sekaligus oleh slot kombo [slot] (0 atau 1). Tanpa pilihan = tombol disembunyikan. */
    private fun showComboDialog(slot: Int) {
        val tokens: List<String>
        val names: Array<String>
        when (game.console) {
            Console.GENESIS -> {
                tokens = VirtualPadView.GENESIS_COMBO_KEYS
                names = arrayOf("A", "B", "C", "X", "Y", "Z", "Mode", "Start", "↑ Atas", "↓ Bawah", "← Kiri", "→ Kanan")
            }
            Console.GBA -> {
                tokens = VirtualPadView.GBA_COMBO_KEYS
                names = arrayOf("A", "B", "L", "R", "Select", "Start", "↑ Atas", "↓ Bawah", "← Kiri", "→ Kanan")
            }
            Console.SNES -> {
                tokens = VirtualPadView.SNES_COMBO_KEYS
                names = arrayOf("A", "B", "X", "Y", "L", "R", "Select", "Start", "↑ Atas", "↓ Bawah", "← Kiri", "→ Kanan")
            }
            else -> {
                tokens = VirtualPadView.ARCADE_COMBO_KEYS
                names = arrayOf("A", "B", "C", "X", "Y", "Z", "Koin", "Start", "↑ Atas", "↓ Bawah", "← Kiri", "→ Kanan")
            }
        }
        val have = (if (slot == 0) pad.combo1Spec else pad.combo2Spec).split('+').map { it.trim() }.toSet()
        val checked = BooleanArray(tokens.size) { tokens[it] in have }
        fun setSpec(spec: String) { if (slot == 0) pad.combo1Spec = spec else pad.combo2Spec = spec }
        AlertDialog.Builder(this)
            .setTitle("Tombol kombo ${slot + 1}")
            .setMultiChoiceItems(names, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ ->
                setSpec(tokens.filterIndexed { i, _ -> checked[i] }.joinToString("+"))
            }
            .setNeutralButton("Kosongkan") { _, _ -> setSpec("") }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun startLayoutEdit() {
        comboBackup = pad.combo1Spec to pad.combo2Spec
        editing = true
        openDialogs++                       // game tetap dijeda selama mengedit
        pad.visibility = View.VISIBLE
        pad.editMode = true
        updateStretch()
        overlay.visibility = View.GONE
        editorBar.visibility = View.VISIBLE
    }

    private fun finishLayoutEdit(save: Boolean) {
        if (save) saveComboSettings(pad)
        else comboBackup?.let { pad.combo1Spec = it.first; pad.combo2Spec = it.second }
        comboBackup = null
        if (save) pad.saveLayout() else pad.reloadLayout()
        pad.editMode = false
        editing = false
        updateStretch()
        editorBar.visibility = View.GONE
        overlay.visibility = View.VISIBLE
        refreshPad()
        openDialogs--
        if (openDialogs == 0) retroView.onResume()
        if (save) toast("Tata letak disimpan")
    }

    private fun buildEditorBar(): View {
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { onClick() }
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(dp(8), 0, dp(2), 0)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(label("Arah"))
            addView(btn("−") { pad.changeDirScale(-0.1f) })
            addView(btn("+") { pad.changeDirScale(0.1f) })
            addView(label("Tombol"))
            addView(btn("−") { pad.changeScale(-0.1f) })
            addView(btn("+") { pad.changeScale(0.1f) })
            addView(btn("Reset") { pad.resetLayout() })
            addView(btn("Batal") { finishLayoutEdit(false) })
            addView(btn("Simpan") { finishLayoutEdit(true) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            addView(TextView(context).apply {
                text = "Seret tombol = pindah.  Ketuk = nonaktif/aktif.  Arah = ukuran D-pad/stik, Tombol = ukuran tombol lain" +
                    ".  Ketuk \"+ Kombo\" = buat tombol kombo (pilih tombol bebas)"
                setTextColor(Color.WHITE)
                textSize = 12f
            })
            addView(row)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
