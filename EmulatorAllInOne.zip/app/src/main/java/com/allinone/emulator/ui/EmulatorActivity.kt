package com.allinone.emulator.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.input.InputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.allinone.emulator.data.Cheat
import com.allinone.emulator.data.CheatStore
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.Paths
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.input.VirtualPadView
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.Variable
import java.io.File
import kotlin.math.abs
import kotlin.math.sign

class EmulatorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        const val EXTRA_CONSOLE = "console"
    }

    private lateinit var game: Game
    private lateinit var settings: Settings
    private lateinit var retroView: GLRetroView
    private lateinit var pad: VirtualPadView
    private lateinit var ffView: TextView
    private lateinit var inputManager: InputManager

    private val ports = HashMap<Int, Int>()   // deviceId -> port pemain
    private var fastForward = false
    private var openDialogs = 0
    @Volatile private var ready = false

    private val sramFile get() = File(Paths.saves(this), "${game.title}.sram.bin")
    private fun stateFile(slot: String) = File(Paths.states(this), "${game.title}.$slot.state")

    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refreshPad()
        override fun onInputDeviceRemoved(deviceId: Int) { ports.remove(deviceId); refreshPad() }
        override fun onInputDeviceChanged(deviceId: Int) = refreshPad()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val romPath = intent.getStringExtra(EXTRA_ROM)
        val consoleName = intent.getStringExtra(EXTRA_CONSOLE)
        if (romPath == null || consoleName == null) { finish(); return }

        settings = Settings(this)
        game = Game(File(romPath), Console.valueOf(consoleName))
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Opsi core. Frame skip: saat ini hanya mGBA yang punya opsi ini.
        val coreVars = mutableListOf<Variable>()
        if (game.console == Console.GBA) coreVars += Variable("mgba_frameskip", settings.frameSkip.toString())

        val data = GLRetroViewData(this).apply {
            coreFilePath = game.console.core
            gameFilePath = game.file.absolutePath
            systemDirectory = Paths.system(this@EmulatorActivity).absolutePath
            savesDirectory = Paths.saves(this@EmulatorActivity).absolutePath
            shader = settings.shaderConfig()
            skipDuplicateFrames = settings.skipDuplicateFrames
            preferLowLatencyAudio = true
            rumbleEventsEnabled = false
            saveRAMState = if (sramFile.exists()) sramFile.readBytes() else null
            variables = coreVars.toTypedArray()
        }

        retroView = GLRetroView(this, data)
        lifecycle.addObserver(retroView)

        pad = VirtualPadView(this).apply {
            opacity = settings.padOpacity
            haptics = settings.haptics
            onKey = { key, down ->
                retroView.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, key, 0)
            }
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(retroView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        root.addView(overlayButtons(), FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        setContentView(root)
        applyLayout()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = showMenu()
        })

        // Core dianggap siap beberapa detik setelah dibuka (tanpa bergantung pada API event versi tertentu).
        // Setelah siap: cheat diterapkan dan save otomatis diaktifkan.
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) {
                ready = true
                applyCheats(CheatStore.load(this, game))
            }
        }, 4000)
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        inputManager.registerInputDeviceListener(deviceListener, null)
        refreshPad()
        hideSystemUi()
    }

    override fun onPause() {
        if (::retroView.isInitialized) persist()
        if (::inputManager.isInitialized) inputManager.unregisterInputDeviceListener(deviceListener)
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    /** Potret: layar game di atas, kontrol di bawah. Lanskap: game di tengah. */
    private fun applyLayout() {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val lp = retroView.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (portrait) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
        retroView.layoutParams = lp
    }

    /** SRAM (save in-game) + state otomatis, disimpan tiap pause/keluar. */
    private fun persist() {
        if (!ready) return
        try { sramFile.writeBytes(retroView.serializeSRAM()) } catch (_: Exception) {}
        try { stateFile("auto").writeBytes(retroView.serializeState()) } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- input (plug n play)

    private fun isGamepad(d: InputDevice) =
        !d.isVirtual && (d.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD

    private fun refreshPad() {
        if (!::pad.isInitialized) return
        val hasPad = InputDevice.getDeviceIds().any { id ->
            InputDevice.getDevice(id)?.let { isGamepad(it) } == true
        }
        pad.opacity = settings.padOpacity
        pad.haptics = settings.haptics
        pad.visibility = if (hasPad && settings.autoHidePad) View.GONE else View.VISIBLE
    }

    /** Gamepad pertama = pemain 1, dst. Port dibebaskan lagi saat gamepad dicabut. */
    private fun portFor(deviceId: Int): Int = ports.getOrPut(deviceId) {
        (0..3).firstOrNull { it !in ports.values } ?: 0
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        val isPadKey = KeyEvent.isGamepadButton(code) ||
            code in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (::retroView.isInitialized && isPadKey && e.repeatCount == 0) {
            val target = KeyMap.resolve(this, e.device?.descriptor ?: "", code)
            retroView.sendKeyEvent(e.action, target, portFor(e.deviceId))
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isStick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!::retroView.isInitialized || !isStick || ev.action != MotionEvent.ACTION_MOVE) {
            return super.dispatchGenericMotionEvent(ev)
        }
        val port = portFor(ev.deviceId)
        val hatX = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val lx = ev.getAxisValue(MotionEvent.AXIS_X)
        val ly = ev.getAxisValue(MotionEvent.AXIS_Y)
        // Konsol 2D tidak punya analog: stick kiri juga dipakai sebagai D-pad.
        fun digital(v: Float) = if (abs(v) < 0.35f) 0f else sign(v)
        retroView.sendMotionEvent(
            GLRetroView.MOTION_SOURCE_DPAD,
            if (hatX != 0f) hatX else digital(lx),
            if (hatY != 0f) hatY else digital(ly),
            port
        )
        retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, lx, ly, port)
        retroView.sendMotionEvent(
            GLRetroView.MOTION_SOURCE_ANALOG_RIGHT,
            ev.getAxisValue(MotionEvent.AXIS_Z), ev.getAxisValue(MotionEvent.AXIS_RZ), port
        )
        return true
    }

    // ---------------------------------------------------------------- UI overlay & menu

    private fun overlayButtons(): View {
        fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { onClick() }
        }
        ffView = chip("⏩") { toggleFastForward() }
        return LinearLayout(this).apply {
            alpha = 0.55f
            addView(ffView)
            addView(chip("☰") { showMenu() })
        }
    }

    private fun toggleFastForward() {
        fastForward = !fastForward
        retroView.frameSpeed = if (fastForward) settings.fastForward else 1
        ffView.setTextColor(if (fastForward) Color.YELLOW else Color.WHITE)
    }

    /** Dialog yang menjeda game selama terbuka. */
    private fun dlg(b: AlertDialog.Builder) {
        if (openDialogs == 0) retroView.onPause()
        openDialogs++
        b.setOnDismissListener {
            openDialogs--
            if (openDialogs == 0) retroView.onResume()
        }
        b.show()
    }

    private fun showMenu() {
        val items = arrayOf(
            "Lanjutkan",
            "Simpan state",
            "Muat state",
            if (fastForward) "Fast forward: AKTIF" else "Fast forward: mati",
            "Shader & filter",
            "Cheat code",
            "Atur tombol gamepad",
            "Pengaturan",
            "Reset game",
            "Keluar ke library"
        )
        dlg(AlertDialog.Builder(this).setTitle(game.title).setItems(items) { _, i ->
            when (i) {
                1 -> showSlots(true)
                2 -> showSlots(false)
                3 -> toggleFastForward()
                4 -> Menus.shader(this, settings) { applySettingsLive() }
                5 -> showCheats()
                6 -> Menus.remap(this)
                7 -> Menus.settings(this, settings) { applySettingsLive() }
                8 -> retroView.reset()
                9 -> finish()
            }
        })
    }

    private fun applySettingsLive() {
        retroView.shader = settings.shaderConfig()
        if (fastForward) retroView.frameSpeed = settings.fastForward
        refreshPad()
    }

    // ---------------------------------------------------------------- save / load state

    private fun slotLabel(slot: String): String {
        val f = stateFile(slot)
        val name = if (slot == "auto") "Otomatis" else "Slot $slot"
        return if (f.exists()) "$name — ${DateFormat.format("dd MMM HH:mm", f.lastModified())}" else "$name — kosong"
    }

    private fun showSlots(save: Boolean) {
        val slots = if (save) listOf("1", "2", "3", "4", "5") else listOf("auto", "1", "2", "3", "4", "5")
        dlg(
            AlertDialog.Builder(this)
                .setTitle(if (save) "Simpan state" else "Muat state")
                .setItems(slots.map { slotLabel(it) }.toTypedArray()) { _, i ->
                    if (save) saveState(slots[i]) else loadState(slots[i])
                }
        )
    }

    private fun saveState(slot: String) {
        try {
            stateFile(slot).writeBytes(retroView.serializeState())
            toast("State tersimpan")
        } catch (e: Exception) {
            toast("Gagal menyimpan state")
        }
    }

    private fun loadState(slot: String) {
        val f = stateFile(slot)
        if (!f.exists()) { toast("Slot kosong"); return }
        val ok = try { retroView.unserializeState(f.readBytes()) } catch (e: Exception) { false }
        toast(if (ok) "State dimuat" else "Gagal memuat state")
    }

    // ---------------------------------------------------------------- cheat

    private fun applyCheats(list: List<Cheat>) {
        if (!ready) return
        list.forEachIndexed { i, c -> retroView.setCheat(i, c.enabled, c.code) }
    }

    private fun showCheats() {
        val cheats = CheatStore.load(this, game)
        val checked = cheats.map { it.enabled }.toBooleanArray()
        dlg(
            AlertDialog.Builder(this)
                .setTitle("Cheat code")
                .setMultiChoiceItems(cheats.map { it.name }.toTypedArray(), checked) { _, i, on -> checked[i] = on }
                .setPositiveButton("Terapkan") { _, _ ->
                    cheats.forEachIndexed { i, c -> c.enabled = checked[i] }
                    CheatStore.save(this, game, cheats)
                    applyCheats(cheats)
                    toast("Cheat diterapkan")
                }
                .setNeutralButton("Tambah…") { _, _ -> addCheat(cheats) }
                .setNegativeButton("Hapus yang dicentang") { _, _ ->
                    cheats.forEachIndexed { i, c -> if (ready) retroView.setCheat(i, false, c.code) }
                    val keep = cheats.filterIndexed { i, _ -> !checked[i] }
                    CheatStore.save(this, game, keep)
                    applyCheats(keep)
                }
        )
    }

    private fun addCheat(cheats: MutableList<Cheat>) {
        val name = EditText(this).apply { hint = "Nama (mis. Nyawa tak terbatas)" }
        val code = EditText(this).apply { hint = "Kode (format sesuai core: Game Genie / GameShark / AR)" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(name); addView(code)
        }
        dlg(
            AlertDialog.Builder(this).setTitle("Tambah cheat").setView(box)
                .setPositiveButton("Simpan") { _, _ ->
                    val n = name.text.toString().trim()
                    val c = code.text.toString().trim()
                    if (n.isNotEmpty() && c.isNotEmpty()) {
                        cheats += Cheat(n, c, false)
                        CheatStore.save(this, game, cheats)
                        toast("Cheat ditambahkan — buka Cheat code untuk mengaktifkan")
                    }
                }
                .setNegativeButton("Batal", null)
        )
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
