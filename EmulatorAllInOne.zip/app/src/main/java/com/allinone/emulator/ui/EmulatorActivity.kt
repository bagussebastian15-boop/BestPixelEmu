package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Bitmap
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.input.InputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.allinone.emulator.data.ArcadeTuning
import com.allinone.emulator.data.Cheat
import com.allinone.emulator.data.CheatStore
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.Paths
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.input.VirtualPadView
import com.allinone.emulator.translate.FrameCapture
import com.allinone.emulator.translate.TranslationEngine
import com.allinone.emulator.translate.TranslationOverlayView
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.Variable
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlin.math.abs
import kotlin.math.sign

class EmulatorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        const val EXTRA_CONSOLE = "console"
    }

    private lateinit var game: Game
    private lateinit var settings: Settings
    private lateinit var retroView: GLRetroView
    private lateinit var pad: VirtualPadView
    private lateinit var ffView: TextView
    private lateinit var overlay: View
    private lateinit var editorBar: View
    private var editing = false
    private lateinit var translator: TranslationEngine
    private lateinit var tOverlay: TranslationOverlayView
    private var tJob: Job? = null
    private var tFrame: Bitmap? = null
    private var tPaused = false
    private var tActive = false            // terjemahan sedang diproses / ditampilkan
    private var tHasResult = false         // hasil sudah tergambar di layar
    private var tShowingOriginal = false   // true = overlay disembunyikan (lihat teks asli)
    private var tToast: Toast? = null
    private lateinit var inputManager: InputManager

    private val ports = HashMap<Int, Int>()   // deviceId -> port pemain
    private val controllerIds = HashSet<Int>() // gamepad fisik yang sedang terhubung
    private var fastForward = false
    private var openDialogs = 0
    @Volatile private var ready = false

    private val sramFile get() = File(Paths.saves(this), "${game.title}.sram.bin")
    private fun stateFile(slot: String) = File(Paths.states(this), "${game.title}.$slot.state")

    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refreshPad()
        override fun onInputDeviceRemoved(deviceId: Int) {
            ports.remove(deviceId)
            controllerIds.remove(deviceId)
            refreshPad()
        }
        override fun onInputDeviceChanged(deviceId: Int) = refreshPad()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val romPath = intent.getStringExtra(EXTRA_ROM)
        val consoleName = intent.getStringExtra(EXTRA_CONSOLE)
        if (romPath == null || consoleName == null) { finish(); return }

        settings = Settings(this)
        game = Game(File(romPath), Console.valueOf(consoleName))
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Opsi core. Frame skip: saat ini hanya mGBA yang punya opsi ini.
        val coreVars = mutableListOf<Variable>()
        if (game.console == Console.GBA) coreVars += Variable("mgba_frameskip", settings.frameSkip.toString())
        val arcade = ArcadeTuning.isArcade(game.console)
        if (arcade) coreVars += ArcadeTuning.variables(game.console, settings.arcadePerf, settings.arcadeCpu)

        val data = GLRetroViewData(this).apply {
            coreFilePath = game.console.core
            gameFilePath = game.file.absolutePath
            systemDirectory = Paths.system(this@EmulatorActivity).absolutePath
            savesDirectory = Paths.saves(this@EmulatorActivity).absolutePath
            shader = settings.shaderConfig()
            skipDuplicateFrames = settings.skipDuplicateFrames
            // Arcade dengan profil performa: buffer audio lebih longgar supaya tidak tersendat/melambat saat berat
            preferLowLatencyAudio = !(arcade && settings.arcadePerf >= 1)
            rumbleEventsEnabled = false
            saveRAMState = if (sramFile.exists()) sramFile.readBytes() else null
            variables = coreVars.toTypedArray()
        }

        retroView = GLRetroView(this, data)
        lifecycle.addObserver(retroView)

        pad = VirtualPadView(this).apply {
            opacity = settings.padOpacity
            haptics = settings.haptics
            analogMode = settings.analogPad
            genesisLayout = game.console == Console.GENESIS     // pad 6 tombol ala Mega Drive
            gbaLayout = game.console == Console.GBA             // pad ala Game Boy Advance asli (A/B, L/R)
            arcadeLayout = game.console == Console.ARCADE_FBNEO ||
                game.console == Console.ARCADE_MAME             // panel arcade: joystick, 6 tombol, koin, start
            onKey = { key, down ->
                retroView.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, key, 0)
            }
            onAnalog = { ax, ay ->
                retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, ax, ay, 0)
            }
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(retroView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        tOverlay = TranslationOverlayView(this)          // terjemahan digambar di atas teks game
        root.addView(tOverlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        overlay = overlayButtons()
        root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        editorBar = buildEditorBar().apply { visibility = View.GONE }
        root.addView(editorBar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        translator = TranslationEngine()
        setContentView(root)
        applyLayout()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    tActive -> closeTranslation()
                    editing -> finishLayoutEdit(false)
                    else -> showMenu()
                }
            }
        })

        // Core dianggap siap beberapa detik setelah dibuka (tanpa bergantung pada API event versi tertentu).
        // Setelah siap: cheat diterapkan dan save otomatis diaktifkan.
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) {
                ready = true
                applyCheats(CheatStore.load(this, game))
            }
        }, 4000)
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        inputManager.registerInputDeviceListener(deviceListener, null)
        refreshPad()
        hideSystemUi()
    }

    override fun onPause() {
        if (::retroView.isInitialized) persist()
        if (::inputManager.isInitialized) inputManager.unregisterInputDeviceListener(deviceListener)
        super.onPause()
    }

    override fun onDestroy() {
        tJob?.cancel()
        tFrame?.recycle(); tFrame = null
        if (::translator.isInitialized) translator.close()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (tActive) closeTranslation()   // posisi teks tidak berlaku lagi
        applyLayout()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    /** Potret: layar game di atas, kontrol di bawah. Lanskap: game di tengah. */
    private fun applyLayout() {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val lp = retroView.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (portrait) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
        retroView.layoutParams = lp
    }

    /** SRAM (save in-game) + state otomatis, disimpan tiap pause/keluar. */
    private fun persist() {
        if (!ready) return
        try { sramFile.writeBytes(retroView.serializeSRAM()) } catch (_: Exception) {}
        try { stateFile("auto").writeBytes(retroView.serializeState()) } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- input (plug n play)

    /**
     * Gamepad fisik = bukan perangkat virtual, melaporkan sumber gamepad/joystick, dan benar-benar punya tombol gamepad.
     * Pemeriksaan tombol mencegah perangkat bawaan HP yang salah lapor dianggap controller.
     */
    private fun isRealController(d: InputDevice): Boolean {
        if (d.isVirtual) return false
        val s = d.sources
        val padLike = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!padLike) return false
        val has = d.hasKeys(
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X,
            KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_START
        )
        return has.any { it }
    }

    /** Dipanggil saat ada input gamepad nyata: jaring pengaman bila pendeteksian lewat daftar perangkat meleset. */
    private fun noteController(deviceId: Int) {
        if (deviceId < 0 || !controllerIds.add(deviceId)) return
        refreshPad()
    }

    /**
     * Kontrol layar SELALU tampil, kecuali ada gamepad fisik terhubung (dan opsi sembunyikan aktif).
     * Begitu gamepad dicabut/mati, kontrol layar langsung muncul lagi.
     */
    private fun refreshPad() {
        if (!::pad.isInitialized) return
        val present = HashSet<Int>()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (isRealController(d)) present += id
        }
        // Pertahankan yang terdeteksi lewat input, selama perangkatnya masih ada.
        for (id in controllerIds) if (InputDevice.getDevice(id) != null) present += id
        controllerIds.clear()
        controllerIds.addAll(present)

        pad.opacity = settings.padOpacity
        pad.haptics = settings.haptics
        pad.analogMode = settings.analogPad
        val hide = !editing && settings.autoHidePad && controllerIds.isNotEmpty()
        if (hide) pad.releaseTouches()          // lepaskan tombol layar yang mungkin masih tertahan
        pad.visibility = if (hide) View.GONE else View.VISIBLE
    }

    /** Gamepad pertama = pemain 1, dst. Port dibebaskan lagi saat gamepad dicabut. */
    private fun portFor(deviceId: Int): Int = ports.getOrPut(deviceId) {
        (0..3).firstOrNull { it !in ports.values } ?: 0
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (KeyEvent.isGamepadButton(code) && e.device?.isVirtual == false) noteController(e.deviceId)
        val isPadKey = KeyEvent.isGamepadButton(code) ||
            code in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        // Pintasan gamepad: tekan R3 (klik stik kanan) untuk menerjemahkan layar.
        if (code == KeyEvent.KEYCODE_BUTTON_THUMBR) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) toggleTranslation()
            return true
        }
        if (editing && isPadKey) return true
        if (::retroView.isInitialized && isPadKey && e.repeatCount == 0) {
            val target = KeyMap.resolve(this, e.device?.descriptor ?: "", code)
            retroView.sendKeyEvent(e.action, target, portFor(e.deviceId))
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isStick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!::retroView.isInitialized || !isStick || ev.action != MotionEvent.ACTION_MOVE) {
            return super.dispatchGenericMotionEvent(ev)
        }
        noteController(ev.deviceId)
        val port = portFor(ev.deviceId)
        val hatX = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val lx = ev.getAxisValue(MotionEvent.AXIS_X)
        val ly = ev.getAxisValue(MotionEvent.AXIS_Y)
        // Konsol 2D tidak punya analog: stick kiri juga dipakai sebagai D-pad.
        fun digital(v: Float) = if (abs(v) < 0.35f) 0f else sign(v)
        retroView.sendMotionEvent(
            GLRetroView.MOTION_SOURCE_DPAD,
            if (hatX != 0f) hatX else digital(lx),
            if (hatY != 0f) hatY else digital(ly),
            port
        )
        retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, lx, ly, port)
        retroView.sendMotionEvent(
            GLRetroView.MOTION_SOURCE_ANALOG_RIGHT,
            ev.getAxisValue(MotionEvent.AXIS_Z), ev.getAxisValue(MotionEvent.AXIS_RZ), port
        )
        return true
    }

    // ---------------------------------------------------------------- UI overlay & menu

    private fun overlayButtons(): View {
        fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { onClick() }
        }
        ffView = chip("⏩") { toggleFastForward() }
        return LinearLayout(this).apply {
            alpha = 0.55f
            addView(chip("🌐") { toggleTranslation() })
            addView(ffView)
            addView(chip("☰") { showMenu() })
        }
    }

    private fun toggleFastForward() {
        fastForward = !fastForward
        retroView.frameSpeed = if (fastForward) settings.fastForward else 1
        ffView.setTextColor(if (fastForward) Color.YELLOW else Color.WHITE)
    }

    /** Dialog yang menjeda game selama terbuka. */
    private fun dlg(b: AlertDialog.Builder) {
        if (openDialogs == 0) retroView.onPause()
        openDialogs++
        b.setOnDismissListener {
            openDialogs--
            if (openDialogs == 0) retroView.onResume()
        }
        b.show()
    }

    private fun showMenu() {
        val items = arrayOf(
            "Lanjutkan",
            "Terjemahkan layar",
            "Simpan state",
            "Muat state",
            if (fastForward) "Fast forward: AKTIF" else "Fast forward: mati",
            "Cheat code",
            "Atur tata letak kontrol",
            "Atur tombol gamepad",
            "Pengaturan",
            "Reset game",
            "Keluar ke library"
        )
        dlg(AlertDialog.Builder(this).setTitle(game.title).setItems(items) { _, i ->
            when (i) {
                // Beri waktu game lanjut jalan setelah menu tertutup supaya ada frame segar untuk ditangkap.
                1 -> Handler(Looper.getMainLooper()).postDelayed({ if (!isFinishing) toggleTranslation() }, 350)
                2 -> showSlots(true)
                3 -> showSlots(false)
                4 -> toggleFastForward()
                5 -> showCheats()
                6 -> startLayoutEdit()
                7 -> Menus.remap(this)
                8 -> openSettings()
                9 -> retroView.reset()
                10 -> finish()
            }
        })
    }

    /** Pengaturan tetap terbuka (game tetap dijeda) sampai ditutup; tidak kembali ke layar game tiap kali mengubah. */
    private fun openSettings() {
        if (openDialogs == 0) retroView.onPause()
        openDialogs++
        Menus.settings(
            this, settings,
            extra = { translationExtras() },
            onClosed = {
                openDialogs--
                if (openDialogs == 0) retroView.onResume()
            }
        ) { applySettingsLive() }
    }

    private fun applySettingsLive() {
        if (fastForward) retroView.frameSpeed = settings.fastForward
        refreshPad()
    }

    // ---------------------------------------------------------------- terjemahan dialog

    private fun toggleTranslation() {
        if (tActive) closeTranslation() else startTranslation(thorough = false, reuse = false)
    }

    /** Pesan singkat (toast) supaya layar game tidak tertutup panel apa pun. */
    private fun status(msg: String, long: Boolean = false) {
        tToast?.cancel()
        tToast = Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).also { it.show() }
    }

    /** Pilihan tambahan di Pengaturan, hanya ada saat terjemahan sedang tampil di layar. */
    private fun translationExtras(): List<Pair<String, (() -> Unit) -> Unit>> {
        if (!tActive || !tHasResult) return emptyList()
        val toggleText: (() -> Unit) -> Unit = {
            tShowingOriginal = !tShowingOriginal
            tOverlay.visibility = if (tShowingOriginal) View.GONE else View.VISIBLE
        }
        val rescan: (() -> Unit) -> Unit = { dismiss ->
            dismiss()
            startTranslation(thorough = true, reuse = true)
        }
        return listOf(
            Pair("Teks di layar: ${if (tShowingOriginal) "asli" else "terjemahan"} (ketuk untuk ganti)", toggleText),
            Pair("Baca ulang terjemahan (mode teliti)", rescan)
        )
    }

    private fun startTranslation(thorough: Boolean, reuse: Boolean) {
        if (editing) return
        tJob?.cancel()
        tJob = lifecycleScope.launch {
            var frame = if (reuse) tFrame else null
            if (frame == null) {
                frame = FrameCapture.grab(retroView)      // ditangkap saat game masih berjalan
                if (frame == null) {
                    status(if (FrameCapture.supported()) "Gagal menangkap layar game" else "Terjemahan butuh Android 7.0 ke atas")
                    return@launch
                }
                tFrame?.recycle()
                tFrame = frame
            }
            tActive = true
            tHasResult = false
            tShowingOriginal = false
            pauseForOverlay()
            tOverlay.clear()
            tOverlay.visibility = View.VISIBLE
            try {
                val result = translator.run(frame, settings.translateSource, settings.translateBottomOnly, thorough, Paths.glossary(this@EmulatorActivity)) { msg ->
                    // Satu-satunya kabar progres yang tampil: unduhan model bahasa (kosong = selesai)
                    withContext(Dispatchers.Main.immediate) {
                        if (msg.isEmpty()) tToast?.cancel() else status(msg, true)
                    }
                }
                when {
                    result == null -> {
                        status("Tidak ada teks yang terbaca. Coba saat dialog terlihat jelas, atau atur Pengaturan → Bahasa teks game.", true)
                        closeTranslation()
                    }
                    result.blocks.none { it.box != null } && result.failed > 0 -> {
                        status("Teks terbaca acak/tidak jelas, jadi tidak ditimpa. Coba lagi saat dialog sudah tampil penuh, atau pakai \"Baca ulang terjemahan (mode teliti)\".", true)
                        closeTranslation()
                    }
                    result.blocks.none { it.box != null } -> {
                        status("Tidak ada teks yang perlu diterjemahkan (sudah berbahasa Indonesia, atau hanya nama/angka).", true)
                        closeTranslation()
                    }
                    else -> {
                        tOverlay.show(
                            result.blocks, result.frameW, result.frameH,
                            retroView.left.toFloat(), retroView.top.toFloat()
                        )
                        tHasResult = true
                        tToast?.cancel()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status("Gagal: ${e.message ?: e.javaClass.simpleName}. Model terjemahan diunduh sekali saat pertama dipakai, jadi butuh internet.", true)
                closeTranslation()
            }
        }
    }

    private fun pauseForOverlay() {
        if (tPaused) return
        tPaused = true
        if (openDialogs == 0) retroView.onPause()
        openDialogs++
    }

    private fun closeTranslation() {
        tJob?.cancel()
        tActive = false
        tHasResult = false
        tShowingOriginal = false
        tOverlay.clear()
        tOverlay.visibility = View.VISIBLE
        if (tPaused) {
            tPaused = false
            openDialogs--
            if (openDialogs == 0) retroView.onResume()
        }
        tFrame?.recycle(); tFrame = null
    }

    // ---------------------------------------------------------------- save / load state

    private fun slotLabel(slot: String): String {
        val f = stateFile(slot)
        val name = if (slot == "auto") "Otomatis" else "Slot $slot"
        return if (f.exists()) "$name — ${DateFormat.format("dd MMM HH:mm", f.lastModified())}" else "$name — kosong"
    }

    private fun showSlots(save: Boolean) {
        val slots = if (save) listOf("1", "2", "3", "4", "5") else listOf("auto", "1", "2", "3", "4", "5")
        dlg(
            AlertDialog.Builder(this)
                .setTitle(if (save) "Simpan state" else "Muat state")
                .setItems(slots.map { slotLabel(it) }.toTypedArray()) { _, i ->
                    if (save) saveState(slots[i]) else loadState(slots[i])
                }
        )
    }

    private fun saveState(slot: String) {
        try {
            stateFile(slot).writeBytes(retroView.serializeState())
            toast("State tersimpan")
        } catch (e: Exception) {
            toast("Gagal menyimpan state")
        }
    }

    private fun loadState(slot: String) {
        val f = stateFile(slot)
        if (!f.exists()) { toast("Slot kosong"); return }
        val ok = try { retroView.unserializeState(f.readBytes()) } catch (e: Exception) { false }
        toast(if (ok) "State dimuat" else "Gagal memuat state")
    }

    // ---------------------------------------------------------------- cheat

    private fun applyCheats(list: List<Cheat>) {
        if (!ready) return
        list.forEachIndexed { i, c -> retroView.setCheat(i, c.enabled, c.code) }
    }

    private fun showCheats() {
        val cheats = CheatStore.load(this, game)
        val checked = cheats.map { it.enabled }.toBooleanArray()
        dlg(
            AlertDialog.Builder(this)
                .setTitle("Cheat code")
                .setMultiChoiceItems(cheats.map { it.name }.toTypedArray(), checked) { _, i, on -> checked[i] = on }
                .setPositiveButton("Terapkan") { _, _ ->
                    cheats.forEachIndexed { i, c -> c.enabled = checked[i] }
                    CheatStore.save(this, game, cheats)
                    applyCheats(cheats)
                    toast("Cheat diterapkan")
                }
                .setNeutralButton("Tambah…") { _, _ -> addCheat(cheats) }
                .setNegativeButton("Hapus yang dicentang") { _, _ ->
                    cheats.forEachIndexed { i, c -> if (ready) retroView.setCheat(i, false, c.code) }
                    val keep = cheats.filterIndexed { i, _ -> !checked[i] }
                    CheatStore.save(this, game, keep)
                    applyCheats(keep)
                }
        )
    }

    private fun addCheat(cheats: MutableList<Cheat>) {
        val name = EditText(this).apply { hint = "Nama (mis. Nyawa tak terbatas)" }
        val code = EditText(this).apply { hint = "Kode (format sesuai core: Game Genie / GameShark / AR)" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(name); addView(code)
        }
        dlg(
            AlertDialog.Builder(this).setTitle("Tambah cheat").setView(box)
                .setPositiveButton("Simpan") { _, _ ->
                    val n = name.text.toString().trim()
                    val c = code.text.toString().trim()
                    if (n.isNotEmpty() && c.isNotEmpty()) {
                        cheats += Cheat(n, c, false)
                        CheatStore.save(this, game, cheats)
                        toast("Cheat ditambahkan — buka Cheat code untuk mengaktifkan")
                    }
                }
                .setNegativeButton("Batal", null)
        )
    }

    // ---------------------------------------------------------------- atur tata letak kontrol

    private fun startLayoutEdit() {
        editing = true
        openDialogs++                       // game tetap dijeda selama mengedit
        pad.visibility = View.VISIBLE
        pad.editMode = true
        overlay.visibility = View.GONE
        editorBar.visibility = View.VISIBLE
    }

    private fun finishLayoutEdit(save: Boolean) {
        if (save) pad.saveLayout() else pad.reloadLayout()
        pad.editMode = false
        editing = false
        editorBar.visibility = View.GONE
        overlay.visibility = View.VISIBLE
        refreshPad()
        openDialogs--
        if (openDialogs == 0) retroView.onResume()
        if (save) toast("Tata letak disimpan")
    }

    private fun buildEditorBar(): View {
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { onClick() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(btn("−") { pad.changeScale(-0.1f) })
            addView(btn("+") { pad.changeScale(0.1f) })
            addView(btn("Reset") { pad.resetLayout() })
            addView(btn("Batal") { finishLayoutEdit(false) })
            addView(btn("Simpan") { finishLayoutEdit(true) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            addView(TextView(context).apply {
                text = "Seret tombol = pindah.  Ketuk tombol = nonaktif/aktif.  − / + = ukuran"
                setTextColor(Color.WHITE)
                textSize = 12f
            })
            addView(row)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
