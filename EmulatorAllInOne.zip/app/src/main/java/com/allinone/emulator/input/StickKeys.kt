package com.allinone.emulator.input

import android.app.Dialog
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Window

/**
 * Gerakan stick analog kiri/kanan (atas, bawah, kiri, kanan) sebagai "tombol" tambahan: 8 arah, masing-masing punya kode
 * buatan di luar rentang kode tombol Android (tidak bentrok dengan tombol asli). Kodenya dipakai persis seperti kode tombol
 * fisik biasa di [KeyMap] (pintasan) dan [PadMap] (pemetaan tombol/kombo), jadi tersimpan dan dikenali dengan cara yang sama.
 * Arah dianggap "ditekan" bila stick digeser lewat 60% dan "dilepas" saat kembali di bawah 40% (histeresis agar tidak berkedip).
 */
object StickKeys {
    const val L_UP = 100001
    const val L_DOWN = 100002
    const val L_LEFT = 100003
    const val L_RIGHT = 100004
    const val R_UP = 100005
    const val R_DOWN = 100006
    const val R_LEFT = 100007
    const val R_RIGHT = 100008

    fun isStick(code: Int) = code in L_UP..R_RIGHT

    fun name(code: Int): String? = when (code) {
        L_UP -> "Analog kiri ↑ (atas)"; L_DOWN -> "Analog kiri ↓ (bawah)"
        L_LEFT -> "Analog kiri ← (kiri)"; L_RIGHT -> "Analog kiri → (kanan)"
        R_UP -> "Analog kanan ↑ (atas)"; R_DOWN -> "Analog kanan ↓ (bawah)"
        R_LEFT -> "Analog kanan ← (kiri)"; R_RIGHT -> "Analog kanan → (kanan)"
        else -> null
    }

    private const val PRESS = 0.6f
    private const val RELEASE = 0.4f

    /** Mengubah posisi stick menjadi kejadian tekan/lepas per arah, per perangkat. */
    class Tracker {
        private val on = HashSet<Long>()

        fun feed(ev: MotionEvent, emit: (deviceId: Int, code: Int, down: Boolean) -> Unit) {
            val d = ev.deviceId
            val lx = ev.getAxisValue(MotionEvent.AXIS_X)
            val ly = ev.getAxisValue(MotionEvent.AXIS_Y)
            val rx = ev.getAxisValue(MotionEvent.AXIS_Z)      // sama dengan yang dikirim ke game
            val ry = ev.getAxisValue(MotionEvent.AXIS_RZ)
            update(d, L_LEFT, -lx, emit); update(d, L_RIGHT, lx, emit)
            update(d, L_UP, -ly, emit); update(d, L_DOWN, ly, emit)
            update(d, R_LEFT, -rx, emit); update(d, R_RIGHT, rx, emit)
            update(d, R_UP, -ry, emit); update(d, R_DOWN, ry, emit)
        }

        private fun update(dev: Int, code: Int, v: Float, emit: (Int, Int, Boolean) -> Unit) {
            val key = (dev.toLong() shl 32) or code.toLong()
            val was = key in on
            val now = if (was) v > RELEASE else v > PRESS
            if (now == was) return
            if (now) on += key else on -= key
            emit(dev, code, now)
        }
    }

    /**
     * Dialog tidak melewati dispatchGenericMotionEvent milik activity, jadi gerakan stick di dalam dialog (mis. layar
     * pemasangan pintasan/pemetaan) disadap lewat callback jendela dialog. Gerakan tetap diteruskan ke dialog seperti biasa.
     */
    fun watch(dialog: Dialog, onStick: (deviceId: Int, code: Int, down: Boolean) -> Unit) {
        val w = dialog.window ?: return
        val orig = w.callback ?: return
        val tracker = Tracker()
        w.callback = object : Window.Callback by orig {
            override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
                if ((ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK && ev.action == MotionEvent.ACTION_MOVE) {
                    tracker.feed(ev, onStick)
                }
                return orig.dispatchGenericMotionEvent(ev)
            }
        }
    }
}
