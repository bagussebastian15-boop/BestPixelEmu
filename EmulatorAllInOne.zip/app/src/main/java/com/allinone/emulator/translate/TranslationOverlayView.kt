package com.allinone.emulator.translate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Menimpa teks asli di game dengan terjemahan yang utuh dan jelas (tidak dipotong, boleh lebih besar dari teks asli):
 * teks berwarna sama, ukuran mengikuti tinggi baris asli, dengan outline bila game memakainya.
 * Koordinat blok = piksel layar game (sama dengan ukuran view GLRetroView); view ini hanya digeser (offset).
 */
class TranslationOverlayView(ctx: Context) : View(ctx) {

    private class Item(
        val rect: RectF,
        val bgPaint: Paint,
        val pixelBmp: Bitmap
    )

    private var items: List<Item> = emptyList()
    private var offsetX = 0f
    private var offsetY = 0f
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }

    fun show(
        blocks: List<TranslationEngine.Block>, frameW: Int, frameH: Int,
        offsetX: Float, offsetY: Float
    ) {
        recycle()
        this.offsetX = offsetX
        this.offsetY = offsetY
        items = blocks.mapNotNull { b ->
            val box = b.box ?: return@mapNotNull null
            val st = b.style ?: return@mapNotNull null
            if (b.translated.isBlank()) null else prepare(b.translated, box, st, frameW, frameH)
        }
        invalidate()
    }

    fun clear() {
        recycle()
        items = emptyList()
        invalidate()
    }

    private fun recycle() {
        for (i in items) if (!i.pixelBmp.isRecycled) i.pixelBmp.recycle()
    }

    override fun onDetachedFromWindow() {
        recycle()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ persiapan tata letak

    /**
     * Teks terjemahan selalu ditampilkan utuh dan jelas: ukuran huruf tetap sebesar teks asli (turun paling
     * banyak 20% hanya bila hampir memenuhi layar), tidak dipotong, dan boleh lebih lebar/tinggi dari kotak
     * teks asli. Kotak latar selalu menutupi seluruh teks asli.
     */
    private fun prepare(
        text: String, box: RectF, st: TextStyle, frameW: Int, frameH: Int
    ): Item {
        val pad = max(2f, st.lineHeight * 0.18f)
        // Tinggi baris asli = tinggi huruf. Huruf besar semua tidak punya turunan, jadi ukuran fontnya lebih besar.
        val start = st.lineHeight * (if (st.allCaps) 1.35f else 1.0f)
        val minSize = start * 0.8f
        val cx = (box.left + box.right) / 2f
        val centered = abs(cx - frameW / 2f) < frameW * 0.08f
        val align = if (centered) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL
        val outline = st.hasOutline || st.busyBackground
        val k = (st.lineHeight / 8f).roundToInt().coerceIn(2, 5)

        // Lebar maksimum: boleh melebihi teks asli, tetap di dalam layar.
        val maxTotal = frameW * 0.94f
        val maxW = min(maxTotal, max(box.width() + 2 * pad, box.width() * 1.6f + 2 * pad))
        val limitH = frameH * 0.45f
        val sw0 = max(4, (maxW / k).toInt())

        // Tahap 1: tata letak pada lebar maksimum untuk mengetahui lebar baris sebenarnya.
        val padSmall = ceil(pad / k).toInt()
        val first = fit(text, st, outline, max(4, sw0 - 2 * padSmall), limitH / k, start / k, max(6f, minSize / k), align)
        var lineMax = 0f
        for (i in 0 until first.first.lineCount) lineMax = max(lineMax, first.first.getLineWidth(i))
        val needSmall = ceil(lineMax).toInt() + 2 + 2 * padSmall
        val minSmall = ceil((box.width() + 2 * pad) / k).toInt()
        val sw = min(sw0, max(4, max(minSmall, needSmall)))

        // Tahap 2: tata letak akhir pada lebar yang pas, ukuran huruf sama (tidak mengecil lagi).
        val size = first.first.paint.textSize
        val fin = fit(text, st, outline, max(4, sw - 2 * padSmall), Float.MAX_VALUE, size, size, align)
        val sh = max(fin.first.height, ceil((box.height() + 2 * pad) / k).toInt()) + 1

        val w = sw * k.toFloat()
        val h = sh * k.toFloat()
        val left = (if (centered) cx - w / 2f else box.left - pad).coerceIn(0f, max(0f, frameW - w))
        var top = max(0f, box.top - pad)
        if (top + h > frameH) top = max(0f, frameH - h)

        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        // Teks diratakan di dalam kotak; margin kiri-kanan = pad agar tidak menempel di tepi.
        c.translate(padSmall.toFloat(), 0f)
        fin.second?.draw(c)
        fin.first.draw(c)
        val bgPaint = Paint().apply {
            color = st.bgColor
            alpha = if (st.busyBackground) 235 else 255
        }
        return Item(RectF(left, top, left + w, top + h), bgPaint, bmp)
    }

    /** Cari ukuran terbesar yang muat; hasil: (layout isi, layout outline atau null). */
    private fun fit(
        text: String, st: TextStyle, outline: Boolean, width: Int, limitH: Float,
        startSize: Float, minSize: Float, align: Layout.Alignment
    ): Pair<StaticLayout, StaticLayout?> {
        var size = max(startSize, minSize)
        var fill = layout(text, paint(st, size, false), width, align)
        while (fill.height > limitH * 1.08f && size > minSize) {
            size = max(minSize, size * 0.93f)
            fill = layout(text, paint(st, size, false), width, align)
        }
        val stroke = if (outline) layout(text, paint(st, size, true), width, align) else null
        return fill to stroke
    }

    private fun paint(st: TextStyle, size: Float, stroke: Boolean): TextPaint =
        TextPaint().apply {
            isAntiAlias = false
            textSize = size
            if (st.slant > 0f) textSkewX = -min(0.35f, st.slant)    // huruf miring seperti di game
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            if (stroke) {
                style = Paint.Style.STROKE
                strokeWidth = 1f
                strokeJoin = Paint.Join.ROUND
                color = if (st.hasOutline) st.outlineColor else
                    (if (st.bgColor.let { (android.graphics.Color.red(it) * 299 + android.graphics.Color.green(it) * 587 + android.graphics.Color.blue(it) * 114) / 1000 } > 128)
                        android.graphics.Color.WHITE else android.graphics.Color.BLACK)
            } else {
                style = Paint.Style.FILL
                color = st.textColor
            }
        }

    @Suppress("DEPRECATION")
    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment) =
        StaticLayout(text, p, width, align, 1.0f, 0f, false)

    // ------------------------------------------------------------------ gambar

    override fun onDraw(canvas: Canvas) {
        canvas.translate(offsetX, offsetY)
        for (item in items) {
            canvas.drawRect(item.rect, item.bgPaint)
            canvas.drawBitmap(item.pixelBmp, null, item.rect, bmpPaint)
        }
    }
}
