package com.allinone.emulator.translate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Menimpa teks asli di game dengan terjemahan yang utuh dan jelas (tidak dipotong, boleh lebih besar dari teks asli):
 * font Nokia, ukuran mengikuti tinggi baris asli; warna tidak ditiru (putih/hitam menyesuaikan latar).
 * Koordinat blok = piksel layar game (sama dengan ukuran view GLRetroView); view ini hanya digeser (offset).
 */
class TranslationOverlayView(ctx: Context) : View(ctx) {

    private class Item(
        val rect: RectF,
        val bgPaint: Paint,
        val pixelBmp: Bitmap,
        val cover: RectF,     // area teks asli (+bantalan): selalu ditutup latar walau terjemahan harus digeser
        var hidden: Boolean = false,  // potongan yang berada di dalam blok lain: tidak digambar, cukup ditutup
        val pinned: Boolean = false,  // kotak dialog: posisi dikunci persis di atas kotak asli, tidak boleh digeser
        val coverPaint: Paint = bgPaint   // cat penutup teks asli (bisa gradasi untuk kotak dialog bergradasi)
    )

    private var nokia: Typeface? = null
    private var items: List<Item> = emptyList()
    private var offsetX = 0f
    private var offsetY = 0f
    private var bounds = RectF()
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }

    // Batas ukuran huruf terjemahan di layar (piksel). Diisi dari Pengaturan (dp) lewat show().
    private var minFontPx = 0f
    private var maxFontPx = Float.MAX_VALUE

    fun show(
        blocks: List<TranslationEngine.Block>, frameW: Int, frameH: Int,
        offsetX: Float, offsetY: Float,
        visible: RectF? = null,
        minFontDp: Int = 0, maxFontDp: Int = 0     // 0 = tanpa batas
    ) {
        recycle()
        val density = resources.displayMetrics.density
        minFontPx = minFontDp * density
        maxFontPx = if (maxFontDp <= 0) Float.MAX_VALUE else max(minFontPx, maxFontDp * density)
        // Area yang benar-benar terlihat di layar (koordinat frame). Saat gambar game diregangkan memenuhi layar,
        // sebagian view berada di luar layar, jadi teks harus dibatasi di dalam area ini agar tidak terpotong.
        bounds = visible ?: RectF(0f, 0f, frameW.toFloat(), frameH.toFloat())
        this.offsetX = offsetX
        this.offsetY = offsetY
        items = blocks.mapNotNull { b ->
            val box = b.box ?: return@mapNotNull null
            val st = b.style ?: return@mapNotNull null
            if (b.translated.isBlank()) null else if (b.fixed) prepareFixed(b.translated, box, b.textBox, st, bounds) else prepare(b.translated, box, st, bounds, false)
        }
        resolveOverlaps(items, bounds)
        invalidate()
    }

    fun clear() {
        recycle()
        items = emptyList()
        invalidate()
    }

    private fun recycle() {
        for (i in items) if (!i.pixelBmp.isRecycled) i.pixelBmp.recycle()
    }

    override fun onDetachedFromWindow() {
        recycle()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ persiapan tata letak

    /**
     * Teks terjemahan selalu ditampilkan utuh dan jelas: ukuran huruf tetap sebesar teks asli (turun paling
     * banyak 20% hanya bila hampir memenuhi layar), tidak dipotong, dan boleh lebih lebar/tinggi dari kotak
     * teks asli. Kotak latar selalu menutupi seluruh teks asli.
     */
    private fun prepare(
        text: String, box: RectF, st: TextStyle, area: RectF, fixed: Boolean
    ): Item {
        val frameW = area.width().toInt()
        val frameH = area.height().toInt()
        // Teks bebas: bantalan lebih lebar supaya sisa huruf asli di tepi pasti tertutup.
        // Balon dialog (fixed): bantalan kecil agar tidak keluar dari balon.
        val pad = if (fixed) max(2f, st.lineHeight * 0.12f) else max(3f, st.lineHeight * 0.35f)
        // Tinggi baris asli = tinggi huruf. Huruf besar semua tidak punya turunan, jadi ukuran fontnya lebih besar.
        val start0 = st.lineHeight * (if (st.allCaps) 1.14f else 1.0f)
        // Balon dialog boleh mengecil sampai 65% supaya seluruh terjemahan muat di dalam balon, tanpa terpotong.
        val minSize0 = start0 * (if (fixed) 0.65f else 0.8f)
        val cx = (box.left + box.right) / 2f
        val centered = abs(cx - area.centerX()) < frameW * 0.08f
        val align = if (centered) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL
        val outline = st.hasOutline || st.busyBackground
        val k = (st.lineHeight / 8f).roundToInt().coerceIn(2, 5)
        // Batas huruf dari Pengaturan (dalam ruang bitmap kecil = piksel layar / k): huruf selalu terbaca, tidak terlalu kecil/besar.
        val minS = max(6f, minFontPx / k)
        val maxS = if (maxFontPx == Float.MAX_VALUE) Float.MAX_VALUE else max(minS, maxFontPx / k)
        val startS = (start0 / k).coerceIn(minS, maxS)
        val minSzS = max(6f, minSize0 / k).coerceIn(minS, startS)

        // Lebar maksimum: boleh melebihi teks asli, tetap di dalam layar.
        val maxTotal = frameW * 0.94f
        // Satu kata (mis. "WAKTU" untuk "TIME") tidak boleh dipenggal huruf per huruf: beri lebar lebih longgar.
        val singleWord = !text.trim().contains(' ') && !text.contains('\n')
        val maxW = if (fixed) min(maxTotal, box.width() + 2 * pad)
        else min(maxTotal, max(box.width() + 2 * pad, box.width() * (if (singleWord) 3f else 1.6f) + 2 * pad))
        val limitH = if (fixed) max(box.height() + 2 * pad, st.lineHeight * 2f) else frameH * 0.45f
        val sw0 = max(4, (maxW / k).toInt())

        // Tahap 1: tata letak pada lebar maksimum untuk mengetahui lebar baris sebenarnya.
        val padSmall = ceil(pad / k).toInt()
        val first = fit(text, st, outline, max(4, sw0 - 2 * padSmall), limitH / k, startS, minSzS, maxS, align)
        var lineMax = 0f
        for (i in 0 until first.first.lineCount) lineMax = max(lineMax, first.first.getLineWidth(i))
        val needSmall = ceil(lineMax).toInt() + 2 + 2 * padSmall
        val minSmall = ceil((box.width() + 2 * pad) / k).toInt()
        val sw = min(sw0, max(4, max(minSmall, needSmall)))

        // Tahap 2: tata letak akhir pada lebar yang pas, ukuran huruf sama (tidak mengecil lagi).
        val size = first.first.paint.textSize
        val fin = fit(text, st, outline, max(4, sw - 2 * padSmall), Float.MAX_VALUE, size, size, size, align)
        val sh = max(fin.first.height, ceil((box.height() + 2 * pad) / k).toInt()) + 1

        val w = sw * k.toFloat()
        val h = sh * k.toFloat()
        val left = (if (centered) cx - w / 2f else box.left - pad)
            .coerceIn(area.left, max(area.left, area.right - w))
        var top = max(area.top, box.top - pad)
        if (top + h > area.bottom) top = max(area.top, area.bottom - h)

        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        // Teks diratakan di dalam kotak; margin kiri-kanan = pad agar tidak menempel di tepi.
        c.translate(padSmall.toFloat(), 0f)
        fin.second?.draw(c)
        fin.first.draw(c)
        val bgPaint = Paint().apply {
            color = st.bgColor
            alpha = if (st.busyBackground) 235 else 255
        }
        val cover = RectF(box).apply { inset(-pad, -pad) }
        return Item(RectF(left, top, left + w, top + h), bgPaint, bmp, cover)
    }

    /**
     * Kotak dialog: kotak terjemahan menumpuk persis di atas kotak dialog asli. Ukuran huruf = tinggi huruf asli,
     * jarak baris = jarak baris asli, margin dan lebar baris = area teks asli.
     * Bila tidak muat, huruf dikecilkan, tetapi TIDAK di bawah batas terbaca (font piksel rusak/acak bila < 8 px bitmap).
     * Bila pada batas terbaca masih tidak muat (terjemahan kecil dan sulit dibaca), kotak diperbesar sedikit
     * (bertahap, maks. +35%, dari titik tengah, tetap di dalam layar game) supaya terjemahan jelas dan lengkap.
     * Kotak asli tetap ditutup penuh oleh latar.
     */
    private fun prepareFixed(text: String, box: RectF, textBox: RectF?, st: TextStyle, area: RectF): Item {
        val k = (st.lineHeight / 8f).roundToInt().coerceIn(2, 5)
        val tb = textBox ?: RectF(box).apply { inset(st.lineHeight * 0.3f, st.lineHeight * 0.3f) }
        val outline = st.hasOutline || st.busyBackground
        val align = Layout.Alignment.ALIGN_NORMAL
        // Batas maksimal huruf dari Pengaturan (dp) juga berlaku di kotak dialog.
        val capS = if (maxFontPx == Float.MAX_VALUE) Float.MAX_VALUE else max(8f, maxFontPx / k)
        val start = min((st.lineHeight * (if (st.allCaps) 1.14f else 1.0f)) / k, capS)
        val readable = min(max(8f, start * 0.6f), max(8f, start))       // batas terbaca: di bawah ini terjemahan dianggap terlalu kecil
        val pitchS = if (st.linePitch > 0f) st.linePitch / k else 0f
        val padRight = ((box.right - tb.right) / k).coerceAtLeast(1f)

        class Fit(val nb: RectF, val size: Float, val fill: StaticLayout, val ok: Boolean, val spaced: Boolean,
                  val useW: Int, val padL: Float, val padT: Float)

        fun attempt(nb: RectF, minSize: Float): Fit {
            val sw = max(4, ceil(nb.width() / k).toInt())
            val sh = max(4, ceil(nb.height() / k).toInt())
            val padL = ((tb.left - nb.left) / k).coerceIn(0f, sw / 3f)
            val padT = ((tb.top - nb.top) / k).coerceIn(0f, sh / 3f)
            val origW = max(4, (tb.width() / k).toInt())
            val wideW = (sw - padL - padRight).toInt()
            val availH = (sh - padT).coerceAtLeast(4f)
            fun fitAt(width: Int, spaced: Boolean): Fit {
                var size = start
                var fill = layoutSpaced(text, paint(st, size, false, 6f, capS), width, align, if (spaced) pitchS else 0f)
                while (fill.height > availH && size > minSize) {
                    size = max(minSize, size * 0.93f)
                    fill = layoutSpaced(text, paint(st, size, false, 6f, capS), width, align, if (spaced) pitchS else 0f)
                }
                return Fit(nb, size, fill, fill.height <= availH, spaced, width, padL, padT)
            }
            var r = fitAt(min(origW, max(4, sw - padL.toInt() - 1)), true)
            if (!r.ok) r = fitAt(max(origW, wideW).coerceAtMost(max(4, sw - padL.toInt() - 1)), true)
            if (!r.ok) r = fitAt(r.useW, false)
            return r
        }

        // 1) kotak asli; 2) bila terjemahan terlalu kecil/tidak muat: kotak diperbesar bertahap.
        var best = attempt(RectF(box), readable)
        if (!best.ok) {
            for (g in floatArrayOf(0.08f, 0.16f, 0.25f, 0.35f)) {
                val w = box.width() * (1f + g)
                val h = box.height() * (1f + g)
                val l = (box.centerX() - w / 2f).coerceIn(area.left, max(area.left, area.right - w))
                val t = (box.centerY() - h / 2f).coerceIn(area.top, max(area.top, area.bottom - h))
                best = attempt(RectF(l, t, l + w, t + h), readable)
                if (best.ok) break
            }
        }
        val nb = best.nb
        val sw = max(4, ceil(nb.width() / k).toInt())
        val sh = max(4, ceil(nb.height() / k).toInt())
        val stroke = if (outline) layoutSpaced(text, paint(st, best.size, true, 6f, capS), best.useW, align,
            if (best.spaced) pitchS else 0f) else null

        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val bg = bgPaintFor(st, nb)
        val c = Canvas(bmp)
        c.translate(best.padL, best.padT)
        stroke?.draw(c)
        best.fill.draw(c)
        return Item(RectF(nb), bg, bmp, RectF(box), pinned = true, coverPaint = bgPaintFor(st, box))
    }

    /** Cat latar kotak: gradasi vertikal bila game memakai latar bergradasi (st.bgStops), selain itu warna rata. */
    private fun bgPaintFor(st: TextStyle, r: RectF): Paint {
        val stops = st.bgStops
        return Paint().apply {
            if (stops != null && stops.size >= 2 && r.height() > 1f) {
                shader = LinearGradient(0f, r.top, 0f, r.bottom, stops, null, Shader.TileMode.CLAMP)
            } else {
                color = st.bgColor
                alpha = if (st.busyBackground) 235 else 255
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun layoutSpaced(text: String, p: TextPaint, width: Int, align: Layout.Alignment, pitch: Float): StaticLayout {
        val natural = p.fontMetrics.let { it.descent - it.ascent }
        val add = if (pitch > 0f) (pitch - natural).coerceIn(-natural * 0.3f, natural * 1.5f) else 0f
        return StaticLayout(text, p, width, align, 1.0f, add, false)
    }

    /**
     * Pengaman: bila dua terjemahan masih saling menimpa, geser yang di bawah ke bawah blok di atasnya
     * (atau ke atas bila tidak muat), supaya keduanya tetap terbaca. Teks asli tetap tertutup lewat [Item.cover].
     */
    private fun resolveOverlaps(list: List<Item>, area: RectF) {
        val order = list.sortedBy { it.rect.top }
        for (i in order.indices) {
            val cur = order[i]
            for (k in 0 until i) {
                val prev = order[k]
                if (cur.hidden || prev.hidden || !RectF.intersects(cur.rect, prev.rect)) continue
                // Potongan kecil yang sebagian besar berada di dalam blok lain = bagian dari kotak dialog yang sama.
                val ix = min(cur.rect.right, prev.rect.right) - max(cur.rect.left, prev.rect.left)
                val iy = min(cur.rect.bottom, prev.rect.bottom) - max(cur.rect.top, prev.rect.top)
                val smaller = if (cur.rect.width() * cur.rect.height() <= prev.rect.width() * prev.rect.height()) cur else prev
                if (ix * iy >= 0.6f * smaller.rect.width() * smaller.rect.height()) { smaller.hidden = true; continue }
                if (cur.pinned) continue
                val down = prev.rect.bottom + 1f - cur.rect.top
                val up = prev.rect.top - 1f - cur.rect.bottom
                when {
                    cur.rect.bottom + down <= area.bottom -> cur.rect.offset(0f, down)
                    cur.rect.top + up >= area.top -> cur.rect.offset(0f, up)
                }
            }
        }
    }

    /** Cari ukuran terbesar yang muat; hasil: (layout isi, layout outline atau null). */
    private fun fit(
        text: String, st: TextStyle, outline: Boolean, width: Int, limitH: Float,
        startSize: Float, minSize: Float, maxSize: Float, align: Layout.Alignment
    ): Pair<StaticLayout, StaticLayout?> {
        var size = startSize.coerceIn(minSize, maxSize)
        var fill = layout(text, paint(st, size, false, minSize, maxSize), width, align)
        while (fill.height > limitH * 1.08f && size > minSize) {
            size = max(minSize, size * 0.93f)
            fill = layout(text, paint(st, size, false, minSize, maxSize), width, align)
        }
        val stroke = if (outline) layout(text, paint(st, size, true, minSize, maxSize), width, align) else null
        return fill to stroke
    }

    /**
     * Hanya ukuran teks yang meniru game. Huruf selalu memakai font Nokia, tegak (tidak miring), dan warnanya
     * tidak ditiru dari teks asli: putih di latar gelap, hitam di latar terang, dengan outline berlawanan bila perlu.
     */
    private fun paint(st: TextStyle, size: Float, stroke: Boolean, lo: Float, hi: Float): TextPaint =
        TextPaint().apply {
            isAntiAlias = false
            textSize = snapClamped(size, lo, hi)
            typeface = nokiaTypeface()
            val darkBg = bgLuma(st) <= 128
            val fillColor = if (darkBg) Color.WHITE else Color.BLACK
            if (stroke) {
                style = Paint.Style.STROKE
                strokeWidth = 1f
                strokeJoin = Paint.Join.ROUND
                color = if (darkBg) Color.BLACK else Color.WHITE
            } else {
                style = Paint.Style.FILL
                color = fillColor
            }
        }

    /** Font piksel: ukuran kelipatan 8 (1 piksel font = bilangan bulat) supaya kotak huruf rata; hanya mengecil bila terpaksa. */
    /** Seperti [snapPixelSize], tetapi hasilnya tetap berada di dalam batas ukuran huruf [lo]..[hi]. */
    private fun snapClamped(size: Float, lo: Float, hi: Float): Float {
        var s = snapPixelSize(size.coerceIn(lo, hi))
        if (s > hi) s = if (hi >= 8f) kotlin.math.floor(hi / 8f) * 8f else hi
        if (s < lo) { val up = ceil(lo / 8f) * 8f; s = if (up <= hi) up else lo }
        return s
    }

    private fun snapPixelSize(size: Float): Float = when {
        size >= 12f -> (size / 8f).roundToInt() * 8f
        size >= 7.5f -> 8f
        else -> size
    }

    /** Kecerahan latar: rata-rata gradasi bila kotak bergradasi, selain itu warna latar rata. */
    private fun bgLuma(st: TextStyle): Int {
        val stops = st.bgStops
        return if (stops != null && stops.isNotEmpty()) stops.map { luminance(it) }.average().toInt() else luminance(st.bgColor)
    }

    private fun luminance(c: Int) = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000

    /**
     * Font piksel bergaya telepon Nokia lama, dimuat dari assets/fonts/nokia.ttf (font buatan sendiri yang ikut
     * disertakan di proyek; bisa diganti dengan file lain bernama sama). Bila gagal dimuat, memakai monospace tebal.
     */
    private fun nokiaTypeface(): Typeface {
        nokia?.let { return it }
        val tf = try {
            Typeface.createFromAsset(context.assets, "fonts/nokia.ttf")
        } catch (_: Exception) {
            Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        nokia = tf
        return tf
    }

    @Suppress("DEPRECATION")
    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment) =
        StaticLayout(text, p, width, align, 1.0f, 0f, false)

    // ------------------------------------------------------------------ gambar

    override fun onDraw(canvas: Canvas) {
        canvas.translate(offsetX, offsetY)
        // Pengaman terakhir: apa pun yang terjadi, tidak ada yang tergambar di luar persegi gambar game
        canvas.save()
        canvas.clipRect(bounds)
        for (item in items) canvas.drawRect(item.cover, item.coverPaint)   // tutup semua teks asli dulu
        for (item in items) {
            if (item.hidden) continue
            canvas.drawRect(item.rect, item.bgPaint)
            canvas.drawBitmap(item.pixelBmp, null, item.rect, bmpPaint)
        }
        canvas.restore()
    }
}
