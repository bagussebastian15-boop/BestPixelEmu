package com.allinone.emulator.translate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Menimpa teks asli di game dengan terjemahan: kotak latar berwarna sama dengan latar teks asli,
 * teks berwarna sama, ukuran mengikuti tinggi baris asli, dengan outline bila game memakainya.
 * Koordinat blok = piksel layar game (sama dengan ukuran view GLRetroView); view ini hanya digeser (offset).
 */
class TranslationOverlayView(ctx: Context) : View(ctx) {

    private class Item(
        val rect: RectF,
        val bgPaint: Paint,
        val fill: StaticLayout?,
        val stroke: StaticLayout?,
        val textX: Float,
        val textY: Float,
        val pixelBmp: Bitmap?
    )

    private var items: List<Item> = emptyList()
    private var offsetX = 0f
    private var offsetY = 0f
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }

    fun show(
        blocks: List<TranslationEngine.Block>, frameW: Int, frameH: Int,
        pixelFont: Boolean, offsetX: Float, offsetY: Float
    ) {
        recycle()
        this.offsetX = offsetX
        this.offsetY = offsetY
        items = blocks.mapNotNull { b ->
            val box = b.box ?: return@mapNotNull null
            val st = b.style ?: return@mapNotNull null
            if (b.translated.isBlank()) null else prepare(b.translated, box, st, frameW, frameH, pixelFont, b.fixed)
        }
        invalidate()
    }

    fun clear() {
        recycle()
        items = emptyList()
        invalidate()
    }

    private fun recycle() {
        for (i in items) i.pixelBmp?.let { if (!it.isRecycled) it.recycle() }
    }

    override fun onDetachedFromWindow() {
        recycle()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ persiapan tata letak

    private fun prepare(
        text: String, box: RectF, st: TextStyle, frameW: Int, frameH: Int, pixelFont: Boolean, fixed: Boolean
    ): Item {
        val pad = max(2f, st.lineHeight * 0.18f)
        // Teks di latar polos (mis. teks cerita di layar hitam) boleh melebar dan bertambah baris;
        // isi balon dialog dan latar bergambar tetap di dalam area aslinya.
        val grow = !fixed && !st.busyBackground
        // Tinggi baris asli = tinggi huruf. Huruf besar semua tidak punya turunan, jadi ukuran fontnya lebih besar.
        val start = st.lineHeight * (if (st.allCaps) 1.35f else 1.0f)
        val minSize = start * (if (grow) 0.8f else 0.5f)
        val cx = (box.left + box.right) / 2f
        val centered = abs(cx - frameW / 2f) < frameW * 0.08f
        val align = if (centered) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL
        val outline = st.hasOutline || st.busyBackground
        var top = max(0f, box.top - pad)
        var size = start
        var left: Float
        var right: Float

        if (grow) {
            val maxLeft = frameW * 0.03f
            val maxRight = frameW * 0.97f
            val maxW: Float = if (centered) {
                min(cx - maxLeft, maxRight - cx).coerceAtLeast(box.width() / 2f + pad) * 2f
            } else {
                (maxRight - (box.left - pad)).coerceAtLeast(box.width() + 2 * pad)
            }
            var lay = measure(text, st, size, (maxW - 2 * pad).toInt(), align)
            while (lay.height > frameH * 0.3f && size > minSize) {
                size = max(minSize, size * 0.93f)
                lay = measure(text, st, size, (maxW - 2 * pad).toInt(), align)
            }
            var need = 0f
            for (i in 0 until lay.lineCount) need = max(need, lay.getLineWidth(i))
            if (pixelFont) need *= 1.25f
            val w = min(maxW, max(box.width() + 2 * pad, need + 2 * pad))
            if (centered) { left = cx - w / 2f; right = cx + w / 2f } else { left = box.left - pad; right = left + w }
        } else {
            val extra = box.width() * 0.03f
            left = box.left - pad - extra
            right = box.right + pad + extra
        }
        left = max(0f, left)
        right = min(frameW.toFloat(), right)
        val widthPx = (right - left).toInt().coerceAtLeast(8)
        val allowedH = box.height() + 2 * pad
        val limitH = if (grow) frameH * 0.3f else allowedH
        val bgPaint = Paint().apply {
            color = st.bgColor
            alpha = if (st.busyBackground) 235 else 255
        }

        if (pixelFont) {
            val k = (st.lineHeight / 8f).roundToInt().coerceIn(2, 5)
            val sw = max(4, widthPx / k)
            val small = fit(text, st, outline, sw, limitH / k, size / k, max(6f, minSize / k), true, 1f, align)
            val sh = max(small.first.height, ceil(allowedH / k).toInt()) + 1
            val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            small.second?.draw(c)
            small.first.draw(c)
            val h = sh * k.toFloat()
            if (top + h > frameH) top = max(0f, frameH - h)
            val rect = RectF(left, top, left + sw * k, top + h)
            return Item(rect, bgPaint, null, null, 0f, 0f, bmp)
        }

        val strokeW = max(1f, st.lineHeight * 0.12f)
        val textW = (widthPx - 2 * pad).toInt().coerceAtLeast(8)
        val res = fit(text, st, outline, textW, limitH - 2 * pad, size, minSize, false, strokeW, align)
        val h = max(allowedH, res.first.height + 2 * pad)
        if (top + h > frameH) top = max(0f, frameH - h)
        val rect = RectF(left, top, right, top + h)
        val textY = top + pad + max(0f, (h - 2 * pad - res.first.height) / 2f)   // satu baris: di tengah vertikal
        return Item(rect, bgPaint, res.first, res.second, left + pad, textY, null)
    }

    private fun measure(text: String, st: TextStyle, size: Float, width: Int, align: Layout.Alignment) =
        layout(text, paint(st, size, false, false, 1f), width.coerceAtLeast(8), align)

    /** Cari ukuran terbesar yang muat; hasil: (layout isi, layout outline atau null). */
    private fun fit(
        text: String, st: TextStyle, outline: Boolean, width: Int, limitH: Float,
        startSize: Float, minSize: Float, pixel: Boolean, strokeW: Float, align: Layout.Alignment
    ): Pair<StaticLayout, StaticLayout?> {
        var size = max(startSize, minSize)
        var fill = layout(text, paint(st, size, pixel, false, strokeW), width, align)
        while (fill.height > limitH * 1.08f && size > minSize) {
            size = max(minSize, size * 0.93f)
            fill = layout(text, paint(st, size, pixel, false, strokeW), width, align)
        }
        val stroke = if (outline) layout(text, paint(st, size, pixel, true, strokeW), width, align) else null
        return fill to stroke
    }

    private fun paint(st: TextStyle, size: Float, pixel: Boolean, stroke: Boolean, strokeW: Float): TextPaint =
        TextPaint().apply {
            isAntiAlias = !pixel
            textSize = size
            if (st.slant > 0f) textSkewX = -min(0.35f, st.slant)    // huruf miring seperti di game
            typeface = if (pixel) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            else Typeface.create(Typeface.SANS_SERIF, if (st.bold) Typeface.BOLD else Typeface.NORMAL)
            if (stroke) {
                style = Paint.Style.STROKE
                strokeWidth = strokeW
                strokeJoin = Paint.Join.ROUND
                color = if (st.hasOutline) st.outlineColor else
                    (if (st.bgColor.let { (android.graphics.Color.red(it) * 299 + android.graphics.Color.green(it) * 587 + android.graphics.Color.blue(it) * 114) / 1000 } > 128)
                        android.graphics.Color.WHITE else android.graphics.Color.BLACK)
            } else {
                style = Paint.Style.FILL
                color = st.textColor
            }
        }

    @Suppress("DEPRECATION")
    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment) =
        StaticLayout(text, p, width, align, 1.0f, 0f, false)

    // ------------------------------------------------------------------ gambar

    override fun onDraw(canvas: Canvas) {
        canvas.translate(offsetX, offsetY)
        for (item in items) {
            canvas.drawRect(item.rect, item.bgPaint)
            val bmp = item.pixelBmp
            if (bmp != null) {
                canvas.drawBitmap(bmp, null, item.rect, bmpPaint)
            } else {
                canvas.save()
                canvas.translate(item.textX, item.textY)
                item.stroke?.draw(canvas)
                item.fill?.draw(canvas)
                canvas.restore()
            }
        }
    }
}
