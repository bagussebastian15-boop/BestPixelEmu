package com.allinone.emulator.translate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Menimpa teks asli di game dengan terjemahan: kotak latar berwarna sama dengan latar teks asli,
 * teks berwarna sama, ukuran mengikuti tinggi baris asli, dengan outline bila game memakainya.
 * Koordinat blok = piksel layar game (sama dengan ukuran view GLRetroView); view ini hanya digeser (offset).
 */
class TranslationOverlayView(ctx: Context) : View(ctx) {

    private class Item(
        val rect: RectF,
        val bgPaint: Paint,
        val fill: StaticLayout?,
        val stroke: StaticLayout?,
        val textX: Float,
        val textY: Float,
        val pixelBmp: Bitmap?
    )

    private var items: List<Item> = emptyList()
    private var offsetX = 0f
    private var offsetY = 0f
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }

    fun show(
        blocks: List<TranslationEngine.Block>, frameW: Int, frameH: Int,
        pixelFont: Boolean, offsetX: Float, offsetY: Float
    ) {
        recycle()
        this.offsetX = offsetX
        this.offsetY = offsetY
        items = blocks.mapNotNull { b ->
            val box = b.box ?: return@mapNotNull null
            val st = b.style ?: return@mapNotNull null
            if (b.translated.isBlank()) null else prepare(b.translated, box, st, frameW, frameH, pixelFont)
        }
        invalidate()
    }

    fun clear() {
        recycle()
        items = emptyList()
        invalidate()
    }

    private fun recycle() {
        for (i in items) i.pixelBmp?.let { if (!it.isRecycled) it.recycle() }
    }

    override fun onDetachedFromWindow() {
        recycle()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ persiapan tata letak

    private fun prepare(
        text: String, box: RectF, st: TextStyle, frameW: Int, frameH: Int, pixelFont: Boolean
    ): Item {
        val pad = max(2f, st.lineHeight * 0.18f)
        val extra = box.width() * 0.08f
        val left = max(0f, box.left - pad - extra)
        val right = min(frameW.toFloat(), box.right + pad + extra)
        var top = max(0f, box.top - pad)
        val widthPx = (right - left).toInt().coerceAtLeast(8)
        val allowedH = box.height() + 2 * pad
        val bgPaint = Paint().apply {
            color = st.bgColor
            alpha = if (st.busyBackground) 235 else 255
        }
        val outline = st.hasOutline || st.busyBackground

        if (pixelFont) {
            val k = (st.lineHeight / 8f).roundToInt().coerceIn(2, 5)
            val sw = max(4, widthPx / k)
            val small = fit(text, st, outline, sw, allowedH / k, st.lineHeight * 0.85f / k, 6f, true, 1f)
            val sh = max(small.first.height, ceil(allowedH / k).toInt()) + 1
            val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            small.second?.draw(c)
            small.first.draw(c)
            val h = sh * k.toFloat()
            if (top + h > frameH) top = max(0f, frameH - h)
            val rect = RectF(left, top, left + sw * k, top + h)
            return Item(rect, bgPaint, null, null, 0f, 0f, bmp)
        }

        val strokeW = max(1f, st.lineHeight * 0.12f)
        val textW = (widthPx - 2 * pad).toInt().coerceAtLeast(8)
        val res = fit(text, st, outline, textW, allowedH - 2 * pad, st.lineHeight * 0.85f, st.lineHeight * 0.45f, false, strokeW)
        val h = max(allowedH, res.first.height + 2 * pad)
        if (top + h > frameH) top = max(0f, frameH - h)
        val rect = RectF(left, top, right, top + h)
        return Item(rect, bgPaint, res.first, res.second, left + pad, top + pad, null)
    }

    /** Cari ukuran terbesar yang muat; hasil: (layout isi, layout outline atau null). */
    private fun fit(
        text: String, st: TextStyle, outline: Boolean, width: Int, allowedH: Float,
        startSize: Float, minSize: Float, pixel: Boolean, strokeW: Float
    ): Pair<StaticLayout, StaticLayout?> {
        var size = max(startSize, minSize)
        var fill = layout(text, paint(st, size, pixel, false, strokeW), width)
        while (fill.height > allowedH * 1.08f && size > minSize) {
            size = max(minSize, size * 0.93f)
            fill = layout(text, paint(st, size, pixel, false, strokeW), width)
        }
        val stroke = if (outline) layout(text, paint(st, size, pixel, true, strokeW), width) else null
        return fill to stroke
    }

    private fun paint(st: TextStyle, size: Float, pixel: Boolean, stroke: Boolean, strokeW: Float): TextPaint =
        TextPaint().apply {
            isAntiAlias = !pixel
            textSize = size
            typeface = if (pixel) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            else Typeface.create(Typeface.SANS_SERIF, if (st.bold) Typeface.BOLD else Typeface.NORMAL)
            if (stroke) {
                style = Paint.Style.STROKE
                strokeWidth = strokeW
                strokeJoin = Paint.Join.ROUND
                color = if (st.hasOutline) st.outlineColor else
                    (if (st.bgColor.let { (android.graphics.Color.red(it) * 299 + android.graphics.Color.green(it) * 587 + android.graphics.Color.blue(it) * 114) / 1000 } > 128)
                        android.graphics.Color.WHITE else android.graphics.Color.BLACK)
            } else {
                style = Paint.Style.FILL
                color = st.textColor
            }
        }

    @Suppress("DEPRECATION")
    private fun layout(text: String, p: TextPaint, width: Int) =
        StaticLayout(text, p, width, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0f, false)

    // ------------------------------------------------------------------ gambar

    override fun onDraw(canvas: Canvas) {
        canvas.translate(offsetX, offsetY)
        for (item in items) {
            canvas.drawRect(item.rect, item.bgPaint)
            val bmp = item.pixelBmp
            if (bmp != null) {
                canvas.drawBitmap(bmp, null, item.rect, bmpPaint)
            } else {
                canvas.save()
                canvas.translate(item.textX, item.textY)
                item.stroke?.draw(canvas)
                item.fill?.draw(canvas)
                canvas.restore()
            }
        }
    }
}
