package com.allinone.emulator.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Build
import android.webkit.WebSettings
import android.widget.FrameLayout
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.widget.Toast
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Paths
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Membuka situs game online di dalam aplikasi (WebView). Tampilan tidak diubah; hanya kelancaran: WebView dibuat setelah frame
 * pertama (layar terbuka seketika), gambar situs ditahan sampai teks siap, konten campuran http/https diizinkan (Android 5),
 * dan unduhan memakai buffer besar.
 */
class WebActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var loadBar: ProgressBar
    private lateinit var container: FrameLayout
    private var savedState: Bundle? = null
    private var startUrl = DEFAULT_URL

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startUrl = intent.getStringExtra(EXTRA_URL) ?: DEFAULT_URL
        savedState = savedInstanceState

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(4), dp(8), dp(4))
        }
        bar.addView(TextView(this).apply {
            text = "ROMS Library. Emulator ini hanya menjalankan game dari konsol SNES, GBA, Genesis, dan MAME. Jadi download ROM game dari konsol-konsol itu."
            textSize = 14f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply {
            text = "Muat ulang"
            setOnClickListener { if (::web.isInitialized) web.reload() }
        })
        bar.addView(Button(this).apply {
            text = "Tutup"
            setOnClickListener { finish() }
        })

        loadBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(loadBar, LinearLayout.LayoutParams(-1, dp(3)))
        container = FrameLayout(this)
        root.addView(container, LinearLayout.LayoutParams(-1, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)

        // Tombol Kembali: mundur di riwayat web dulu, baru keluar
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::web.isInitialized && web.canGoBack()) web.goBack() else finish()
            }
        })

        // WebView dibuat setelah frame pertama tergambar: layar terasa terbuka seketika walau WebView lambat dimulai (Android lama).
        container.post { if (!isFinishing && !isDestroyed) createWebView() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView() {
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.allowFileAccess = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            if (Build.VERSION.SDK_INT >= 21) {
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE   // Android 5: bawaan memblokir gambar http di halaman https
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            }
            settings.blockNetworkImage = true      // gambar menyusul setelah teks & tata letak siap
            webViewClient = object : WebViewClient() {
                // Tautan tetap dibuka di dalam aplikasi
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = false
                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    web.settings.blockNetworkImage = true
                    loadBar.visibility = android.view.View.VISIBLE
                }
                override fun onPageFinished(view: WebView, url: String?) {
                    web.settings.blockNetworkImage = false
                    loadBar.visibility = android.view.View.GONE
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    loadBar.progress = newProgress
                    if (newProgress >= 70) web.settings.blockNetworkImage = false      // jangan menunggu selesai total
                }
            }
        }

        // Unduhan dari situs langsung disimpan ke penyimpanan aplikasi (tanpa DownloadManager / izin tambahan)
        web.setDownloadListener { dlUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(dlUrl, userAgent, contentDisposition, mimeType)
        }

        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        val st = savedState
        if (st == null) web.loadUrl(startUrl) else web.restoreState(st)
        savedState = null
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::web.isInitialized) web.saveState(outState)
    }

    override fun onPause() { super.onPause(); if (::web.isInitialized) web.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.onResume() }

    override fun onDestroy() {
        if (::web.isInitialized) {
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }

    private val main = Handler(Looper.getMainLooper())

    private fun toast(msg: String) {
        val app = applicationContext
        main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
    }

    /**
     * Ekstensi ROM yang dikenal (.gba .sfc .smc .md .gen .zip ...) masuk ke folder ROM konsolnya,
     * jadi langsung muncul di Library. File lain disimpan di folder "downloads" milik aplikasi.
     */
    private fun targetDir(ctx: android.content.Context, name: String): File {
        val console = Console.fromExtension(name.substringAfterLast('.', "").lowercase())
        if (console != null) return Paths.roms(ctx, console)
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, "downloads").apply { mkdirs() }
    }

    private fun startDownload(url: String, userAgent: String?, disposition: String?, mime: String?) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast("Jenis tautan unduhan ini belum didukung")
            return
        }
        val app = applicationContext
        val name = File(URLUtil.guessFileName(url, disposition, mime)).name
        toast("Mengunduh $name…")
        Thread {
            var part: File? = null
            try {
                val dir = targetDir(app, name)
                val dest = File(dir, name)
                part = File(dir, "$name.part")   // .part tidak ditampilkan di Library sampai selesai
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000; readTimeout = 30000
                    instanceFollowRedirects = true
                    userAgent?.let { setRequestProperty("User-Agent", it) }
                    CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
                    setRequestProperty("Referer", DEFAULT_URL)
                }
                if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP ${conn.responseCode}")
                conn.inputStream.use { input ->
                    java.io.BufferedOutputStream(part.outputStream(), 128 * 1024).use { out -> input.copyTo(out, 128 * 1024) }   // buffer besar: jauh lebih cepat di HP lama
                }
                if (dest.exists()) dest.delete()
                if (!part.renameTo(dest)) throw java.io.IOException("gagal menyimpan")
                if (dir.path.contains("/roms/")) {
                    // Arsip (zip/7z/rar) dibaca isinya: ROM konsol dipindah ke konsol yang sesuai
                    val ex = if (com.allinone.emulator.data.RomLibrary.isArchive(name)) com.allinone.emulator.data.RomLibrary.normalizeArchive(app, dest) else emptyList()
                    val c = (ex.firstOrNull() ?: dest).let { com.allinone.emulator.data.RomLibrary.consoleOf(it) }
                    toast("Tersimpan di Library: ${ex.firstOrNull()?.name ?: name}" + (c?.let { " [${it.label}]" } ?: ""))
                } else toast("Tersimpan: $name (folder downloads)")
            } catch (e: Exception) {
                part?.delete()
                toast("Unduhan gagal: ${e.message ?: "kesalahan jaringan"}")
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_URL = "url"
        const val DEFAULT_URL = "https://videogame.actduck.com/"
    }
}
