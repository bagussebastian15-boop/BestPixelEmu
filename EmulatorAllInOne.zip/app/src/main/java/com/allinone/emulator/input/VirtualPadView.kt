package com.allinone.emulator.input

import android.content.Context
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Kontrol layar sentuh multi-touch: D-pad 8 arah (termasuk serong) atau stik analog, A/B/X/Y, L/R, Start/Select.
 * Tata letak (posisi tiap kontrol + ukuran) bisa diatur dan disimpan terpisah untuk potret dan lanskap.
 */
class VirtualPadView(ctx: Context) : View(ctx) {

    var onKey: ((keyCode: Int, down: Boolean) -> Unit)? = null

    /** Posisi stik analog (-1..1) saat mode analog; dikirim juga sebagai sumbu analog kiri. */
    var onAnalog: ((x: Float, y: Float) -> Unit)? = null

    var haptics = true
    var opacity = 60
        set(v) { field = v; invalidate() }

    /** false = D-pad 8 arah, true = stik analog (keluarannya tetap dijadikan arah digital untuk konsol 2D). */
    var analogMode = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            applyScale()
        }

    /**
     * true = tata letak pad Sega Genesis / Mega Drive 6 tombol: A B C (baris bawah, sedikit miring naik ke kanan)
     * dan X Y Z (baris atas), plus MODE dan START. Tanpa L/R. Tata letak tersimpan terpisah dari mode standar.
     *
     * Pemetaan ke core Genesis Plus GX (libretro): A=RetroPad Y, B=RetroPad B, C=RetroPad A,
     * X=RetroPad L, Y=RetroPad X, Z=RetroPad R, MODE=Select, START=Start.
     * LibretroDroid menerjemahkan KEYCODE_BUTTON_X -> Y, BUTTON_A -> B, BUTTON_B -> A, BUTTON_Y -> X.
     */
    var genesisLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /**
     * true = tata letak pad Game Boy Advance asli: D-pad di kiri, hanya tombol A dan B di kanan
     * (A di kanan-atas, B di kiri-bawah, miring seperti aslinya), L/R di sudut atas, serta SELECT dan START.
     * Tanpa tombol X/Y karena GBA memang tidak punya. Tata letak tersimpan terpisah dari mode lain.
     *
     * Pemetaan ke core mGBA (libretro): A=RetroPad A (KEYCODE_BUTTON_B), B=RetroPad B (KEYCODE_BUTTON_A).
     */
    var gbaLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /**
     * true = tata letak panel arcade (MAME): joystick 8 arah (digital, tanpa analog) di kiri,
     * 6 tombol aksi dalam dua baris tiga di kanan, serta KOIN dan START.
     *
     * Pemetaan ke core arcade (libretro), disusun seperti panel Capcom 6 tombol:
     * baris bawah 1 2 3 = RetroPad B, A, R (tendangan lemah/sedang/kuat pada game fighting Capcom),
     * baris atas 4 5 6 = RetroPad Y, X, L (pukulan lemah/sedang/kuat). KOIN = Select (insert coin), START = Start.
     * LibretroDroid menerjemahkan KEYCODE_BUTTON_A -> B, BUTTON_B -> A, BUTTON_X -> Y, BUTTON_Y -> X.
     */
    var arcadeLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /**
     * true = tampilan ala pad Super Nintendo: X/Y ungu muda, A/B ungu tua (warna tombol SNES asli),
     * sedangkan D-pad, L/R, Select/Start memakai warna gelap supaya terlihat di latar abu-abu terang.
     * Hanya mengubah tampilan; pemetaan tombol tidak berubah.
     */
    var snesStyle = false
        set(v) { field = v; invalidate() }

    /**
     * true = tata letak pad Super Nintendo asli: D-pad salib polos di kiri (tanpa mode analog, SNES memang tidak punya),
     * empat tombol A B X Y berbentuk belah ketupat di kanan (X atas, B bawah, Y kiri, A kanan),
     * tombol bahu L/R lebar di sudut atas, serta SELECT dan START berbentuk pil kecil miring di tengah
     * dengan tulisan di bawahnya. Tata letak tersimpan terpisah dari mode lain.
     *
     * Pemetaan ke core Snes9x (libretro) sama dengan RetroPad: A=KEYCODE_BUTTON_B, B=KEYCODE_BUTTON_A,
     * X=KEYCODE_BUTTON_Y, Y=KEYCODE_BUTTON_X (LibretroDroid menerjemahkannya ke A/B/X/Y SNES yang benar).
     */
    var snesLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /** Kontrol arah berbentuk stik (mode analog pilihan pengguna, atau joystick pada pad arcade). */
    private val stickMode: Boolean get() = (analogMode && !snesLayout) || arcadeLayout

    /** Mode atur tata letak: sentuhan menggeser tombol, bukan mengirim input. */
    var editMode = false
        set(v) {
            field = v
            if (v) releaseAll()
            dragging = null
            invalidate()
        }

    private class Btn(var key: Int, var label: String) {
        var cx = 0f; var cy = 0f
        var br = 0f; var bh = 0f     // radius dan area sentuh dasar
        var r = 0f; var hit = 0f     // setelah skala
        var off = false              // dinonaktifkan pengguna: tidak tampil dan tidak bisa disentuh saat bermain
        var pillW = 1f               // setengah panjang dibanding radius: 1 = bulat, >1 = kapsul (bahu, Select/Start SNES)
        var tilt = 0f                // kemiringan kapsul dalam derajat (negatif = ujung kanan naik)

        /** Apakah titik (px, py) berada dalam jarak [rad] dari bentuk tombol (lingkaran atau kapsul miring). */
        fun touches(px: Float, py: Float, rad: Float): Boolean {
            var dx = px - cx; var dy = py - cy
            if (tilt != 0f) {
                val t = Math.toRadians(-tilt.toDouble())
                val cs = cos(t).toFloat(); val sn = sin(t).toFloat()
                val rx = dx * cs - dy * sn; val ry = dx * sn + dy * cs
                dx = rx; dy = ry
            }
            val ex = max(abs(dx) - r * (pillW - 1f), 0f)
            return hypot(ex, dy) <= rad
        }
    }

    private val a = Btn(KeyEvent.KEYCODE_BUTTON_B, "A")   // timur
    private val b = Btn(KeyEvent.KEYCODE_BUTTON_A, "B")   // selatan
    private val x = Btn(KeyEvent.KEYCODE_BUTTON_Y, "X")   // utara
    private val y = Btn(KeyEvent.KEYCODE_BUTTON_X, "Y")   // barat
    private val l = Btn(KeyEvent.KEYCODE_BUTTON_L1, "L")
    private val r = Btn(KeyEvent.KEYCODE_BUTTON_R1, "R")
    private val sel = Btn(KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
    private val start = Btn(KeyEvent.KEYCODE_BUTTON_START, "START")

    /** Kontrol arah (D-pad atau stik). Kunci 0 dipakai untuk menyimpan posisinya. */
    private val dir = Btn(DIR_ID, "")
    init { configureButtons() }
    private val allButtons = listOf(a, b, x, y, l, r, sel, start)
    /** Tombol yang aktif (tampil dan bisa disentuh) pada mode saat ini; GBA tidak punya X dan Y. */
    private val buttons: List<Btn> get() = if (gbaLayout) listOf(a, b, l, r, sel, start) else allButtons
    private val all: List<Btn> get() = buttons + dir
    /** Tombol yang tidak dinonaktifkan pengguna. */
    private val liveButtons: List<Btn> get() = buttons.filter { !it.off }

    private val prefs = ctx.getSharedPreferences("padlayout", Context.MODE_PRIVATE)
    private var scale = 1f          // ukuran semua tombol (tanpa D-pad/stik)
    private var dirScale = 1f       // ukuran D-pad/stik, terpisah dari tombol lain
    private var unit = 0f
    private var dragging: Btn? = null
    private var pressed: Set<Int> = emptySet()       // tombol biasa + arah digital yang sedang ditekan

    // Stik analog
    private var stickPointer = -1
    private var stickX = 0f
    private var stickY = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val tri = Path()

    companion object {
        private const val DIR_ID = 0

        /** Warna latar layar game untuk SNES (abu-abu kebiruan). */
        val SNES_BG: Int = 0xFFB9C2C4.toInt()
        private val SNES_INK: Int = 0xFF4A4448.toInt()        // warna D-pad, L/R, Select/Start di atas latar terang
        private val SNES_LIGHT: Int = 0xFF8972B8.toInt()      // tombol X dan Y
        private val SNES_DARK: Int = 0xFF3A236B.toInt()       // tombol A dan B
        private val DPAD_KEYS = intArrayOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
        )
        private const val DIAG_RATIO = 0.4142f          // tan(22,5°): batas antara arah lurus dan serong
        private const val DPAD_DEAD = 0.22f             // zona mati di tengah D-pad (pecahan radius)
        private const val STICK_DEAD = 0.30f            // ambang stik analog menjadi arah digital
    }

    // ------------------------------------------------------------ tata letak

    private fun place(btn: Btn, cx: Float, cy: Float, r: Float, hit: Float) {
        btn.cx = cx; btn.cy = cy; btn.br = r; btn.bh = hit
    }

    private fun orient(w: Int, h: Int) =
        (if (genesisLayout) "gen_" else if (gbaLayout) "gba_" else if (arcadeLayout) "arc_" else if (snesLayout) "snes_" else "") + (if (w > h) "land" else "port")

    /** Isi kode tombol dan label sesuai mode. Objek tombol dipakai ulang; hanya kode + label yang berganti. */
    private fun configureButtons() {
        fun set(btn: Btn, key: Int, label: String) { btn.key = key; btn.label = label }
        for (bt in listOf(a, b, x, y, l, r, sel, start)) { bt.pillW = 1f; bt.tilt = 0f }
        if (arcadeLayout) {
            // Baris bawah: 1 2 3
            set(b, KeyEvent.KEYCODE_BUTTON_A, "1")
            set(a, KeyEvent.KEYCODE_BUTTON_B, "2")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "3")
            // Baris atas: 4 5 6
            set(y, KeyEvent.KEYCODE_BUTTON_X, "4")
            set(x, KeyEvent.KEYCODE_BUTTON_Y, "5")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "6")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "KOIN")
        } else if (genesisLayout) {
            // Baris bawah: A B C
            set(a, KeyEvent.KEYCODE_BUTTON_X, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_B, "C")
            // Baris atas: X Y Z
            set(y, KeyEvent.KEYCODE_BUTTON_L1, "X")
            set(l, KeyEvent.KEYCODE_BUTTON_Y, "Y")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "Z")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "MODE")
            set(start, KeyEvent.KEYCODE_BUTTON_START, "START")
            sel.pillW = 2.4f; start.pillW = 2.4f          // pil abu-abu datar, tulisan di bawahnya
        } else if (snesLayout) {
            set(a, KeyEvent.KEYCODE_BUTTON_B, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_Y, "X")
            set(y, KeyEvent.KEYCODE_BUTTON_X, "Y")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "L")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "R")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "SELECT")
            set(start, KeyEvent.KEYCODE_BUTTON_START, "START")
            l.pillW = 2.4f; r.pillW = 2.4f                                  // bahu lebar
            sel.pillW = 2.3f; sel.tilt = -25f                               // pil kecil miring, ujung kanan naik
            start.pillW = 2.3f; start.tilt = -25f
        } else {
            set(a, KeyEvent.KEYCODE_BUTTON_B, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_Y, "X")
            set(y, KeyEvent.KEYCODE_BUTTON_X, "Y")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "L")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "R")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
        }
    }

    /** Susunan pad Genesis: D-pad kiri, A B C + X Y Z kanan, MODE/START di tengah bawah. */
    private fun placeGenesis(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * (if (portrait) 2.7f else 3.2f), baseY, 0f, 0f)

        val rm = u * (if (portrait) 1.3f else 2.2f)     // jarak tombol C ke tepi kanan
        val sx = u * 1.85f                              // jarak antar tombol dalam baris
        val slope = u * 0.3f                            // baris naik ke kanan, seperti pad aslinya
        val rad = 0.8f * u
        val hit = 1.0f * u
        val cx = w - rm
        val bottomY = baseY + 0.6f * u
        val topY = bottomY - 1.95f * u
        place(a, cx - 2 * sx, bottomY + slope, rad, hit)
        place(b, cx - sx, bottomY, rad, hit)
        place(x, cx, bottomY - slope, rad, hit)
        place(y, cx - 2 * sx, topY + slope, rad, hit)
        place(l, cx - sx, topY, rad, hit)
        place(r, cx, topY - slope, rad, hit)

        place(sel, w / 2f - u * 1.9f, h - u * 1.9f, 0.4f * u, 0.8f * u)
        place(start, w / 2f + u * 1.9f, h - u * 1.9f, 0.4f * u, 0.8f * u)
    }

    /**
     * Susunan pad Game Boy Advance: D-pad kiri, A (kanan-atas) dan B (kiri-bawah) kanan,
     * L/R di sudut atas, SELECT dan START di bawah tombol A/B.
     */
    private fun placeGba(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * 3.2f, baseY, 0f, 0f)

        val fx = w - u * 3.0f                       // titik tengah antara A dan B
        val rad = 0.95f * u
        val hit = 1.15f * u
        place(a, fx + 1.0f * u, baseY - 0.5f * u, rad, hit)   // A: kanan, sedikit lebih tinggi
        place(b, fx - 1.0f * u, baseY + 0.5f * u, rad, hit)   // B: kiri, sedikit lebih rendah

        val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
        place(l, u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)
        place(r, w - u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)

        // SELECT dan START di bawah A/B, sedikit miring seperti di badan GBA
        place(sel, fx - 0.9f * u, baseY + 2.6f * u, 0.6f * u, 0.85f * u)
        place(start, fx + 0.9f * u, baseY + 2.4f * u, 0.6f * u, 0.85f * u)
    }

    /**
     * Susunan pad Super Nintendo: D-pad kiri, belah ketupat A (kanan) B (bawah) X (atas) Y (kiri) di kanan,
     * L/R lebar di sudut atas, SELECT dan START berupa pil miring di tengah bawah.
     */
    private fun placeSnes(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * 3.2f, baseY, 0f, 0f)

        val fx = w - u * 3.4f
        val rad = 0.95f * u
        val hit = 1.35f * u
        place(a, fx + 1.8f * u, baseY, rad, hit)
        place(b, fx, baseY + 1.8f * u, rad, hit)
        place(x, fx, baseY - 1.8f * u, rad, hit)
        place(y, fx - 1.8f * u, baseY, rad, hit)

        val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
        place(l, u * 3.0f, shoulderY, 0.7f * u, 1.0f * u)
        place(r, w - u * 3.0f, shoulderY, 0.7f * u, 1.0f * u)

        place(sel, w / 2f - u * 1.7f, h - u * 1.6f, 0.36f * u, 0.8f * u)
        place(start, w / 2f + u * 1.7f, h - u * 1.6f, 0.36f * u, 0.8f * u)
    }

    /** Susunan panel arcade: joystick kiri, 2 baris x 3 tombol kanan (sedikit melengkung), KOIN/START di tengah bawah. */
    private fun placeArcade(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * (if (portrait) 2.7f else 3.2f), baseY, 0f, 0f)

        val rm = u * (if (portrait) 1.3f else 2.2f)     // jarak tombol kolom kanan ke tepi kanan
        val sx = u * 1.85f                              // jarak antar kolom
        val slope = u * 0.3f                            // kolom kanan sedikit lebih tinggi, seperti lengkung panel
        val rad = 0.8f * u
        val hit = 1.0f * u
        val cx = w - rm
        val bottomY = baseY + 0.6f * u
        val topY = bottomY - 1.95f * u
        // Baris bawah: 1 2 3
        place(b, cx - 2 * sx, bottomY + slope, rad, hit)
        place(a, cx - sx, bottomY, rad, hit)
        place(r, cx, bottomY - slope, rad, hit)
        // Baris atas: 4 5 6
        place(y, cx - 2 * sx, topY + slope, rad, hit)
        place(x, cx - sx, topY, rad, hit)
        place(l, cx, topY - slope, rad, hit)

        place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
    }

    private fun layoutAll(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val portrait = h > w
        // Pad Genesis potret memakai unit sedikit lebih kecil supaya D-pad dan 6 tombol muat berdampingan
        val u = min(w, h) * (if ((genesisLayout || arcadeLayout) && portrait) 0.095f else 0.11f)
        unit = u
        val baseY = h - u * 3.6f

        if (genesisLayout) {
            placeGenesis(w, h, u, portrait)
        } else if (arcadeLayout) {
            placeArcade(w, h, u, portrait)
        } else if (gbaLayout) {
            placeGba(w, h, u, portrait)
        } else if (snesLayout) {
            placeSnes(w, h, u, portrait)
        } else {
            place(dir, u * 3.2f, baseY, 0f, 0f)    // radius diisi di applyScale() sesuai mode

            val fx = w - u * 3.4f
            place(a, fx + 1.8f * u, baseY, 0.95f * u, 1.35f * u)
            place(b, fx, baseY + 1.8f * u, 0.95f * u, 1.35f * u)
            place(x, fx, baseY - 1.8f * u, 0.95f * u, 1.35f * u)
            place(y, fx - 1.8f * u, baseY, 0.95f * u, 1.35f * u)

            val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
            place(l, u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)
            place(r, w - u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)

            place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
            place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        }

        // Timpa dengan tata letak tersimpan (jika ada) untuk orientasi ini
        val o = orient(w, h)
        scale = prefs.getFloat("${o}_scale", 1f)
        // Tata letak lama: satu skala untuk semuanya, jadi D-pad/stik ikut memakai nilai itu sampai diatur sendiri
        dirScale = prefs.getFloat("${o}_dirscale", scale)
        for (btn in all) {
            btn.off = prefs.getBoolean("${o}_${btn.key}_off", false)
            if (prefs.contains("${o}_${btn.key}_x")) {
                btn.cx = prefs.getFloat("${o}_${btn.key}_x", 0f) * w
                btn.cy = prefs.getFloat("${o}_${btn.key}_y", 0f) * h
            }
        }
        // Migrasi: tata letak lama punya 4 tombol arah terpisah; pusatnya = (x tombol atas, y tombol kiri)
        val upX = "${o}_${KeyEvent.KEYCODE_DPAD_UP}_x"
        val leftY = "${o}_${KeyEvent.KEYCODE_DPAD_LEFT}_y"
        if (!prefs.contains("${o}_${DIR_ID}_x") && prefs.contains(upX) && prefs.contains(leftY)) {
            dir.cx = prefs.getFloat(upX, 0f) * w
            dir.cy = prefs.getFloat(leftY, 0f) * h
        }
        applyScale()
    }

    private fun applyScale() {
        // Kontrol arah menempati area yang sama dengan 4 tombol lama; stik sedikit lebih kecil
        dir.br = unit * if (stickMode) 2.3f else if (genesisLayout) 2.4f else 2.7f
        // Pad Genesis: area sentuh D-pad lebih ketat agar tidak menabrak tombol A yang berdekatan
        dir.bh = dir.br * if (genesisLayout || arcadeLayout) 1.1f else 1.2f
        for (btn in buttons) { btn.r = btn.br * scale; btn.hit = btn.bh * scale }
        dir.r = dir.br * dirScale; dir.hit = dir.bh * dirScale
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = layoutAll(w, h)

    /** Buang perubahan yang belum disimpan. */
    fun reloadLayout() = layoutAll(width, height)

    fun saveLayout() {
        if (width <= 0 || height <= 0) return
        val o = orient(width, height)
        val e = prefs.edit().putFloat("${o}_scale", scale).putFloat("${o}_dirscale", dirScale)
        for (btn in all) {
            e.putFloat("${o}_${btn.key}_x", btn.cx / width)
            e.putFloat("${o}_${btn.key}_y", btn.cy / height)
            e.putBoolean("${o}_${btn.key}_off", btn.off)
        }
        e.apply()
    }

    /** Kembali ke tata letak bawaan untuk orientasi saat ini. */
    fun resetLayout() {
        val o = orient(width, height)
        val e = prefs.edit().remove("${o}_scale").remove("${o}_dirscale")
        for (btn in all) { e.remove("${o}_${btn.key}_x"); e.remove("${o}_${btn.key}_y"); e.remove("${o}_${btn.key}_off") }
        for (k in DPAD_KEYS) { e.remove("${o}_${k}_x"); e.remove("${o}_${k}_y") }   // sisa tata letak lama
        e.apply()
        layoutAll(width, height)
    }

    /** Ubah ukuran semua tombol (A/B/X/Y, L/R, Start/Select); D-pad/stik tidak ikut berubah. */
    fun changeScale(delta: Float) {
        scale = (scale + delta).coerceIn(0.6f, 1.6f)
        applyScale()
    }

    /** Ubah ukuran D-pad / stik saja; tombol lain tidak ikut berubah. */
    fun changeDirScale(delta: Float) {
        dirScale = (dirScale + delta).coerceIn(0.5f, 2.0f)
        applyScale()
    }

    // ------------------------------------------------------------ gambar

    private fun releaseAll() {
        for (k in pressed) onKey?.invoke(k, false)
        pressed = emptySet()
        if (stickPointer != -1 || stickX != 0f || stickY != 0f) onAnalog?.invoke(0f, 0f)
        stickPointer = -1
        stickX = 0f; stickY = 0f
    }

    /** Dipanggil saat kontrol disembunyikan (gamepad fisik terhubung) supaya tidak ada tombol yang tertahan. */
    fun releaseTouches() { releaseAll(); invalidate() }

    private val padBody = 0xFF5B6272.toInt()          // badan tombol/D-pad (konsol selain SNES)
    private val smallBody = 0xFF444B5A.toInt()        // tombol kecil Select/Start (konsol selain SNES)
    private val snesShoulder = 0xFF9A949C.toInt()     // tombol bahu SNES (abu-abu)
    private val genGray = 0xFF9C9B99.toInt()          // tombol atas X Y Z dan START/MODE pad Genesis asli (abu-abu)
    private val genBlack = 0xFF2C2D31.toInt()         // tombol bawah A B C pad Genesis asli (hitam)
    private val genDpad = 0xFF2A2A2D.toInt()          // D-pad pad Genesis asli (hitam)
    private val arcadeKnob = 0xFFC0392B.toInt()       // bola joystick arcade (merah)
    private val stickKnob = 0xFF6B7385.toInt()        // kenop stik analog
    private val shadowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val crossPath = Path()
    private val rr = RectF()

    private fun darken(color: Int, k: Float): Int {
        val ro = ((color shr 16 and 0xFF) * k).toInt(); val go = ((color shr 8 and 0xFF) * k).toInt(); val bo = ((color and 0xFF) * k).toInt()
        return (0xFF shl 24) or (ro shl 16) or (go shl 8) or bo
    }

    private fun lighten(color: Int, k: Float): Int {
        val ro = color shr 16 and 0xFF; val go = color shr 8 and 0xFF; val bo = color and 0xFF
        val r2 = (ro + (255 - ro) * k).toInt(); val g2 = (go + (255 - go) * k).toInt(); val b2 = (bo + (255 - bo) * k).toInt()
        return (0xFF shl 24) or (r2 shl 16) or (g2 shl 8) or b2
    }

    private fun bodyOf(btn: Btn): Int =
        if (genesisLayout) {
            // Seperti pad 6 tombol asli: X Y Z abu-abu (baris atas), A B C hitam (baris bawah), START/MODE abu-abu
            if (btn === y || btn === l || btn === r || btn === sel || btn === start) genGray else genBlack
        } else if (snesStyle) when {
            btn === x || btn === y -> SNES_LIGHT
            btn === a || btn === b -> SNES_DARK
            btn === l || btn === r -> snesShoulder
            else -> SNES_INK
        } else if (btn === sel || btn === start) smallBody else padBody

    /** Warna huruf: putih di atas tombol berwarna; gelap untuk bahu abu-abu SNES dan tulisan di bawah Select/Start. */
    private fun inkOf(btn: Btn): Int =
        if (genesisLayout) {
            // Huruf gelap di tombol abu-abu, huruf terang di tombol hitam, tulisan START/MODE putih di bawah pil
            if (btn === sel || btn === start) 0xFFFFFFFF.toInt() else if (btn === y || btn === l || btn === r) 0xFF2B2B2B.toInt() else 0xFFC8C8C8.toInt()
        } else if (snesStyle && (btn === l || btn === r || btn === sel || btn === start)) SNES_INK else 0xFFFFFFFF.toInt()

    /**
     * Tombol 3D: bayangan lembut, dinding samping (tebal), permukaan atas bercahaya dari kiri-atas,
     * tepi terang di atas dan gelap di bawah. Saat ditekan permukaan turun dan dinding menipis.
     * Bentuk kapsul bila pillW > 1 (tombol bahu, Select/Start SNES); bisa dimiringkan (tilt).
     */
    private fun drawKey(c: Canvas, btn: Btn, body0: Int, ink: Int, ab: Float, on: Boolean) {
        val rad = btn.r
        val halfW = rad * btn.pillW
        val extent = halfW + rad * 2.6f
        val layer = c.saveLayerAlpha(
            btn.cx - extent, btn.cy - extent, btn.cx + extent, btn.cy + extent,
            (ab * 255).toInt().coerceIn(0, 255)
        )
        val depth = rad * 0.28f
        val push = if (on) depth * 0.7f else 0f
        val body = if (on) darken(body0, 0.88f) else body0
        val below = (snesLayout || genesisLayout) && (btn === sel || btn === start)
        val round = btn.pillW <= 1.01f

        c.save()
        c.translate(btn.cx, btn.cy)
        c.rotate(btn.tilt)

        // Bayangan jatuh
        shadowP.color = 0xFF000000.toInt()
        for (i in 3 downTo 1) {
            val e = rad * 0.08f * i
            shadowP.alpha = if (on) 14 else 22
            rr.set(-halfW - e, -rad - e + depth + e * 0.6f, halfW + e, rad + e + depth + e * 0.6f)
            c.drawRoundRect(rr, rad + e, rad + e, shadowP)
        }
        // Dinding samping
        bodyP.shader = null
        bodyP.pathEffect = null
        bodyP.color = darken(body, 0.5f)
        rr.set(-halfW, -rad + depth, halfW, rad + depth)
        c.drawRoundRect(rr, rad, rad, bodyP)
        rr.set(-halfW, push, halfW, depth)
        c.drawRect(rr, bodyP)

        // Permukaan atas
        c.save()
        c.translate(0f, push)
        rr.set(-halfW, -rad, halfW, rad)
        bodyP.shader = if (round)
            RadialGradient(
                -halfW * 0.35f, -rad * 0.4f, halfW * 1.5f,
                intArrayOf(lighten(body, 0.4f), body, darken(body, 0.7f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        else
            LinearGradient(
                0f, -rad, 0f, rad,
                intArrayOf(lighten(body, 0.32f), body, darken(body, 0.78f)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
        c.drawRoundRect(rr, rad, rad, bodyP)
        bodyP.shader = null

        // Tepi: terang di atas, gelap di bawah
        lineP.strokeWidth = rad * 0.08f
        lineP.shader = LinearGradient(
            0f, -rad, 0f, rad,
            intArrayOf(0xAAFFFFFF.toInt(), 0x00FFFFFF, 0x66000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        rr.inset(rad * 0.05f, rad * 0.05f)
        c.drawRoundRect(rr, rad, rad, lineP)
        lineP.shader = null

        if (round) {
            // Cekungan di tengah dan kilap kecil di kiri-atas
            lineP.color = darken(body, 0.55f); lineP.alpha = 90; lineP.strokeWidth = rad * 0.05f
            c.drawCircle(0f, 0f, rad * 0.68f, lineP)
            shadowP.color = 0xFFFFFFFF.toInt(); shadowP.alpha = 70
            rr.set(-rad * 0.62f, -rad * 0.8f, -rad * 0.02f, -rad * 0.35f)
            c.drawOval(rr, shadowP)
        }

        if (!below) {
            text.textSize = rad * (if (btn.label.length > 1 && round) 0.55f else 0.95f)
            val ty = text.textSize * 0.35f
            text.color = 0xFF000000.toInt(); text.alpha = 90
            c.drawText(btn.label, 0f, ty + rad * 0.05f, text)
            text.color = ink
            c.drawText(btn.label, 0f, ty, text)
        }
        c.restore()

        if (below) {   // SELECT/START tercetak di bawah tombol, ikut miring, seperti pad aslinya
            text.textSize = rad * 1.05f
            text.color = ink
            c.drawText(btn.label, 0f, rad + depth + text.textSize * 1.05f, text)
        }
        c.restore()
        c.restoreToCount(layer)
    }

    override fun onDraw(c: Canvas) {
        val base = (if (editMode) max(opacity, 60) else opacity).coerceIn(10, 100) / 100f
        for (btn in buttons) {
            if (btn.off && !editMode) continue          // tombol nonaktif disembunyikan saat bermain
            val ab = if (btn.off) base * 0.3f else base  // saat mengatur: tampil redup + dicoret
            val on = btn.key in pressed || btn === dragging
            drawKey(c, btn, bodyOf(btn), inkOf(btn), ab, on)
            if (btn.off) strike(c, btn)
        }
        if (!dir.off || editMode) {
            val db = if (dir.off) base * 0.3f else base
            if (stickMode) drawStick(c, db) else drawDpad(c, db)
            if (dir.off) strike(c, dir)
        }
    }

    /** Coretan diagonal penanda tombol nonaktif (hanya terlihat di mode atur tata letak). */
    private fun strike(c: Canvas, btn: Btn) {
        val d = btn.r * 0.7f
        stroke.color = if (snesStyle) SNES_INK else 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 5f
        stroke.alpha = 230
        c.drawLine(btn.cx - d, btn.cy - d, btn.cx + d, btn.cy + d, stroke)
    }

    /** Bola joystick/stik 3D di dalam sumur cekung; bola mengikuti jari dan turun sedikit saat disentuh. */
    private fun drawStick(c: Canvas, ab: Float) {
        val on = stickPointer != -1 || dir === dragging
        val rad = dir.r
        val cx = dir.cx; val cy = dir.cy
        val extent = rad * 1.6f
        val layer = c.saveLayerAlpha(cx - extent, cy - extent, cx + extent, cy + extent, (ab * 255).toInt().coerceIn(0, 255))

        // Sumur cekung
        bodyP.pathEffect = null
        bodyP.shader = RadialGradient(
            cx, cy, rad,
            intArrayOf(0xFF1B1F27.toInt(), 0xFF2A303B.toInt(), 0xFF4B5262.toInt()), floatArrayOf(0f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rad, bodyP)
        bodyP.shader = null
        lineP.strokeWidth = rad * 0.05f
        lineP.shader = LinearGradient(
            cx, cy - rad, cx, cy + rad,
            intArrayOf(0x66000000, 0x00000000, 0x55FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rad * 0.97f, lineP)
        lineP.shader = null

        // Penanda 4 arah
        text.color = 0xFF9AA3B5.toInt(); text.alpha = 140
        text.textSize = rad * 0.28f
        val ty = text.textSize * 0.35f
        c.drawText("▲", cx, cy - rad * 0.72f + ty, text)
        c.drawText("▼", cx, cy + rad * 0.72f + ty, text)
        c.drawText("◀", cx - rad * 0.72f, cy + ty, text)
        c.drawText("▶", cx + rad * 0.72f, cy + ty, text)

        // Kenop
        val knob = if (arcadeLayout) arcadeKnob else stickKnob
        val kr = rad * 0.44f
        val kx = cx + stickX * (rad - kr * 0.4f)
        val ky = cy + stickY * (rad - kr * 0.4f)
        val lift = if (on) kr * 0.12f else kr * 0.3f
        shadowP.color = 0xFF000000.toInt(); shadowP.alpha = 70
        c.drawCircle(kx + kr * 0.08f, ky + lift + kr * 0.12f, kr * 1.02f, shadowP)
        bodyP.color = darken(knob, 0.5f)
        c.drawCircle(kx, ky + lift, kr, bodyP)
        bodyP.shader = RadialGradient(
            kx - kr * 0.35f, ky - kr * 0.4f, kr * 1.5f,
            intArrayOf(lighten(knob, 0.55f), knob, darken(knob, 0.6f)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(kx, ky, kr, bodyP)
        bodyP.shader = null
        shadowP.color = 0xFFFFFFFF.toInt(); shadowP.alpha = 90
        rr.set(kx - kr * 0.6f, ky - kr * 0.8f, kx - kr * 0.05f, ky - kr * 0.35f)
        c.drawOval(rr, shadowP)
        c.restoreToCount(layer)
    }

    /** Lintasan salib D-pad berpusat di (0, dy). */
    private fun buildCross(len: Float, arm: Float, dy: Float) {
        crossPath.reset()
        crossPath.moveTo(-arm, -len + dy); crossPath.lineTo(arm, -len + dy); crossPath.lineTo(arm, -arm + dy)
        crossPath.lineTo(len, -arm + dy); crossPath.lineTo(len, arm + dy); crossPath.lineTo(arm, arm + dy)
        crossPath.lineTo(arm, len + dy); crossPath.lineTo(-arm, len + dy); crossPath.lineTo(-arm, arm + dy)
        crossPath.lineTo(-len, arm + dy); crossPath.lineTo(-len, -arm + dy); crossPath.lineTo(-arm, -arm + dy)
        crossPath.close()
    }

    /** D-pad salib 3D: tebal dengan dinding samping, cekungan di tengah, lengan yang ditekan menggelap dan salib sedikit turun. */
    private fun drawDpad(c: Canvas, ab: Float) {
        val len = dir.r
        val arm = len * 0.34f
        val cx = dir.cx; val cy = dir.cy
        val any = dir === dragging || DPAD_KEYS.any { it in pressed }
        val depth = arm * 0.55f
        val push = if (any) depth * 0.5f else 0f
        val body = if (snesStyle) SNES_INK else if (genesisLayout) genDpad else padBody
        val extent = len * 1.7f
        val layer = c.saveLayerAlpha(cx - extent, cy - extent, cx + extent, cy + extent, (ab * 255).toInt().coerceIn(0, 255))
        c.save()
        c.translate(cx, cy)
        val corner = CornerPathEffect(arm * 0.4f)
        bodyP.pathEffect = corner
        bodyP.shader = null

        // Bayangan jatuh
        bodyP.color = 0xFF000000.toInt()
        for (i in 2 downTo 1) {
            buildCross(len + i * arm * 0.08f, arm + i * arm * 0.08f, depth + i * arm * 0.12f)
            bodyP.alpha = 24
            c.drawPath(crossPath, bodyP)
        }
        // Dinding samping: salib digeser bertahap ke bawah
        val steps = 4
        for (i in steps downTo 1) {
            buildCross(len, arm, push + (depth - push) * i / steps)
            bodyP.color = darken(body, 0.5f)
            c.drawPath(crossPath, bodyP)
        }
        // Permukaan atas
        buildCross(len, arm, push)
        bodyP.shader = LinearGradient(
            -len, -len + push, len, len + push,
            intArrayOf(lighten(body, 0.3f), body, darken(body, 0.75f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(crossPath, bodyP)
        bodyP.shader = null
        lineP.pathEffect = corner
        lineP.strokeWidth = arm * 0.08f
        lineP.shader = LinearGradient(
            0f, -len, 0f, len,
            intArrayOf(0xAAFFFFFF.toInt(), 0x00FFFFFF, 0x66000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(crossPath, lineP)
        lineP.shader = null
        lineP.pathEffect = null
        bodyP.pathEffect = null

        // Lengan yang ditekan menggelap
        if (any) {
            bodyP.color = 0xFF000000.toInt(); bodyP.alpha = 70
            c.save()
            c.translate(0f, push)
            val rc = arm * 0.3f
            if (KeyEvent.KEYCODE_DPAD_UP in pressed) { rr.set(-arm, -len, arm, -arm * 0.2f); c.drawRoundRect(rr, rc, rc, bodyP) }
            if (KeyEvent.KEYCODE_DPAD_DOWN in pressed) { rr.set(-arm, arm * 0.2f, arm, len); c.drawRoundRect(rr, rc, rc, bodyP) }
            if (KeyEvent.KEYCODE_DPAD_LEFT in pressed) { rr.set(-len, -arm, -arm * 0.2f, arm); c.drawRoundRect(rr, rc, rc, bodyP) }
            if (KeyEvent.KEYCODE_DPAD_RIGHT in pressed) { rr.set(arm * 0.2f, -arm, len, arm); c.drawRoundRect(rr, rc, rc, bodyP) }
            c.restore()
        }

        // Cekungan di tengah
        bodyP.shader = RadialGradient(
            0f, push, arm * 0.9f,
            intArrayOf(darken(body, 0.55f), body), null, Shader.TileMode.CLAMP
        )
        c.drawCircle(0f, push, arm * 0.9f, bodyP)
        bodyP.shader = null

        // Segitiga arah timbul (D-pad SNES asli polos, jadi tidak digambar di SNES)
        if (!snesStyle) {
            val t = arm * 0.5f
            val d = len - arm * 0.9f
            bodyP.color = lighten(body, 0.6f); bodyP.alpha = 210
            fun arrow(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
                tri.reset(); tri.moveTo(x1, y1 + push); tri.lineTo(x2, y2 + push); tri.lineTo(x3, y3 + push); tri.close()
                c.drawPath(tri, bodyP)
            }
            arrow(0f, -d - t * 0.5f, -t, -d + t * 0.6f, t, -d + t * 0.6f)
            arrow(0f, d + t * 0.5f, -t, d - t * 0.6f, t, d - t * 0.6f)
            arrow(-d - t * 0.5f, 0f, -d + t * 0.6f, -t, -d + t * 0.6f, t)
            arrow(d + t * 0.5f, 0f, d - t * 0.6f, -t, d - t * 0.6f, t)
        }
        c.restore()
        c.restoreToCount(layer)
    }

    // ------------------------------------------------------------ sentuhan

    /**
     * Ubah vektor (dx, dy) menjadi arah digital 8 arah.
     * Sudut dibagi rata: tiap arah lurus dan tiap arah serong mendapat sektor 45°.
     */
    private fun dirKeys(dx: Float, dy: Float, out: MutableSet<Int>) {
        val ax = abs(dx); val ay = abs(dy)
        val diagonal = ay >= ax * DIAG_RATIO && ax >= ay * DIAG_RATIO
        val horiz = diagonal || ay < ax * DIAG_RATIO      // kiri/kanan (lurus atau serong)
        val vert = diagonal || ax < ay * DIAG_RATIO       // atas/bawah (lurus atau serong)
        if (horiz) out.add(if (dx < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        if (vert) out.add(if (dy < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editMode) return handleEdit(e)

        val now = HashSet<Int>()
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1

        // Stik analog: kunci ke satu jari sejak menyentuh area stik sampai dilepas
        if (stickMode && !dir.off) {
            if (ending) stickPointer = -1
            if (stickPointer != -1) {
                val idx = e.findPointerIndex(stickPointer)
                if (idx < 0 || idx == skip) stickPointer = -1
            }
            if (stickPointer == -1 && !ending &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_POINTER_DOWN)
            ) {
                val i = e.actionIndex
                if (hypot(e.getX(i) - dir.cx, e.getY(i) - dir.cy) <= dir.hit) stickPointer = e.getPointerId(i)
            }
            var sx = 0f; var sy = 0f
            if (stickPointer != -1) {
                val i = e.findPointerIndex(stickPointer)
                var vx = (e.getX(i) - dir.cx) / dir.r
                var vy = (e.getY(i) - dir.cy) / dir.r
                val m = hypot(vx, vy)
                if (m > 1f) { vx /= m; vy /= m }
                sx = vx; sy = vy
                if (hypot(sx, sy) >= STICK_DEAD) dirKeys(sx, sy, now)
            }
            if (sx != stickX || sy != stickY) {
                stickX = sx; stickY = sy
                if (!arcadeLayout) onAnalog?.invoke(sx, sy)     // joystick arcade murni digital
            }
        }

        if (!ending) {
            for (i in 0 until e.pointerCount) {
                if (i == skip || e.getPointerId(i) == stickPointer) continue
                val px = e.getX(i); val py = e.getY(i)
                for (btn in liveButtons) {
                    if (btn.touches(px, py, btn.hit)) now.add(btn.key)
                }
                if (!stickMode && !dir.off) {
                    val dx = px - dir.cx; val dy = py - dir.cy
                    val dist = hypot(dx, dy)
                    if (dist <= dir.hit && dist >= dir.r * DPAD_DEAD) dirKeys(dx, dy, now)
                }
            }
        }
        val added = now - pressed
        for (k in pressed - now) onKey?.invoke(k, false)
        for (k in added) onKey?.invoke(k, true)
        if (added.isNotEmpty() && haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        pressed = now
        invalidate()
        return true
    }

    private var downX = 0f
    private var downY = 0f
    private var movedFar = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    /** Seret = pindahkan tombol; ketuk sekali (tanpa menyeret) = nonaktifkan / aktifkan kembali tombol itu. */
    private fun handleEdit(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; movedFar = false
                dragging = all
                    .filter { it.touches(e.x, e.y, it.r * 1.3f) }
                    .minByOrNull { hypot(e.x - it.cx, e.y - it.cy) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!movedFar && hypot(e.x - downX, e.y - downY) > slop) movedFar = true
                if (movedFar) dragging?.let {
                    val mx = it.r * it.pillW
                    it.cx = e.x.coerceIn(mx, max(mx, width - mx))
                    it.cy = e.y.coerceIn(it.r, max(it.r, height - it.r))
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!movedFar) dragging?.let { it.off = !it.off }
                dragging = null
            }
            MotionEvent.ACTION_CANCEL -> dragging = null
        }
        invalidate()
        return true
    }
}
