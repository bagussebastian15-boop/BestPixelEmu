package com.allinone.emulator.input

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Kontrol layar sentuh multi-touch: D-pad 8 arah (termasuk serong) atau stik analog, A/B/X/Y, L/R, Start/Select.
 * Tata letak (posisi tiap kontrol + ukuran) bisa diatur dan disimpan terpisah untuk potret dan lanskap.
 */
class VirtualPadView(ctx: Context) : View(ctx) {

    var onKey: ((keyCode: Int, down: Boolean) -> Unit)? = null

    /** Posisi stik analog (-1..1) saat mode analog; dikirim juga sebagai sumbu analog kiri. */
    var onAnalog: ((x: Float, y: Float) -> Unit)? = null

    var haptics = true
    var opacity = 60
        set(v) { field = v; invalidate() }

    /** false = D-pad 8 arah, true = stik analog (keluarannya tetap dijadikan arah digital untuk konsol 2D). */
    var analogMode = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            applyScale()
        }

    /**
     * true = tata letak pad Sega Genesis / Mega Drive 6 tombol: A B C (baris bawah, sedikit miring naik ke kanan)
     * dan X Y Z (baris atas), plus MODE dan START. Tanpa L/R. Tata letak tersimpan terpisah dari mode standar.
     *
     * Pemetaan ke core Genesis Plus GX (libretro): A=RetroPad Y, B=RetroPad B, C=RetroPad A,
     * X=RetroPad L, Y=RetroPad X, Z=RetroPad R, MODE=Select, START=Start.
     * LibretroDroid menerjemahkan KEYCODE_BUTTON_X -> Y, BUTTON_A -> B, BUTTON_B -> A, BUTTON_Y -> X.
     */
    var genesisLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /**
     * true = tata letak pad Game Boy Advance asli: D-pad di kiri, hanya tombol A dan B di kanan
     * (A di kanan-atas, B di kiri-bawah, miring seperti aslinya), L/R di sudut atas, serta SELECT dan START.
     * Tanpa tombol X/Y karena GBA memang tidak punya. Tata letak tersimpan terpisah dari mode lain.
     *
     * Pemetaan ke core mGBA (libretro): A=RetroPad A (KEYCODE_BUTTON_B), B=RetroPad B (KEYCODE_BUTTON_A).
     */
    var gbaLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /**
     * true = tata letak panel arcade (MAME / FBNeo): joystick 8 arah (digital, tanpa analog) di kiri,
     * 6 tombol aksi dalam dua baris tiga di kanan, serta KOIN dan START.
     *
     * Pemetaan ke core arcade (libretro), disusun seperti panel Capcom 6 tombol:
     * baris bawah 1 2 3 = RetroPad B, A, R (tendangan lemah/sedang/kuat pada game fighting Capcom),
     * baris atas 4 5 6 = RetroPad Y, X, L (pukulan lemah/sedang/kuat). KOIN = Select (insert coin), START = Start.
     * LibretroDroid menerjemahkan KEYCODE_BUTTON_A -> B, BUTTON_B -> A, BUTTON_X -> Y, BUTTON_Y -> X.
     */
    var arcadeLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            layoutAll(width, height)
        }

    /** Kontrol arah berbentuk stik (mode analog pilihan pengguna, atau joystick pada pad arcade). */
    private val stickMode: Boolean get() = analogMode || arcadeLayout

    /** Mode atur tata letak: sentuhan menggeser tombol, bukan mengirim input. */
    var editMode = false
        set(v) {
            field = v
            if (v) releaseAll()
            dragging = null
            invalidate()
        }

    private class Btn(var key: Int, var label: String) {
        var cx = 0f; var cy = 0f
        var br = 0f; var bh = 0f     // radius dan area sentuh dasar
        var r = 0f; var hit = 0f     // setelah skala
    }

    private val a = Btn(KeyEvent.KEYCODE_BUTTON_B, "A")   // timur
    private val b = Btn(KeyEvent.KEYCODE_BUTTON_A, "B")   // selatan
    private val x = Btn(KeyEvent.KEYCODE_BUTTON_Y, "X")   // utara
    private val y = Btn(KeyEvent.KEYCODE_BUTTON_X, "Y")   // barat
    private val l = Btn(KeyEvent.KEYCODE_BUTTON_L1, "L")
    private val r = Btn(KeyEvent.KEYCODE_BUTTON_R1, "R")
    private val sel = Btn(KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
    private val start = Btn(KeyEvent.KEYCODE_BUTTON_START, "START")

    /** Kontrol arah (D-pad atau stik). Kunci 0 dipakai untuk menyimpan posisinya. */
    private val dir = Btn(DIR_ID, "")
    init { configureButtons() }
    private val allButtons = listOf(a, b, x, y, l, r, sel, start)
    /** Tombol yang aktif (tampil dan bisa disentuh) pada mode saat ini; GBA tidak punya X dan Y. */
    private val buttons: List<Btn> get() = if (gbaLayout) listOf(a, b, l, r, sel, start) else allButtons
    private val all: List<Btn> get() = buttons + dir

    private val prefs = ctx.getSharedPreferences("padlayout", Context.MODE_PRIVATE)
    private var scale = 1f
    private var unit = 0f
    private var dragging: Btn? = null
    private var pressed: Set<Int> = emptySet()       // tombol biasa + arah digital yang sedang ditekan

    // Stik analog
    private var stickPointer = -1
    private var stickX = 0f
    private var stickY = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val tri = Path()

    companion object {
        private const val DIR_ID = 0
        private val DPAD_KEYS = intArrayOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
        )
        private const val DIAG_RATIO = 0.4142f          // tan(22,5°): batas antara arah lurus dan serong
        private const val DPAD_DEAD = 0.22f             // zona mati di tengah D-pad (pecahan radius)
        private const val STICK_DEAD = 0.30f            // ambang stik analog menjadi arah digital
    }

    // ------------------------------------------------------------ tata letak

    private fun place(btn: Btn, cx: Float, cy: Float, r: Float, hit: Float) {
        btn.cx = cx; btn.cy = cy; btn.br = r; btn.bh = hit
    }

    private fun orient(w: Int, h: Int) =
        (if (genesisLayout) "gen_" else if (gbaLayout) "gba_" else if (arcadeLayout) "arc_" else "") + (if (w > h) "land" else "port")

    /** Isi kode tombol dan label sesuai mode. Objek tombol dipakai ulang; hanya kode + label yang berganti. */
    private fun configureButtons() {
        fun set(btn: Btn, key: Int, label: String) { btn.key = key; btn.label = label }
        if (arcadeLayout) {
            // Baris bawah: 1 2 3
            set(b, KeyEvent.KEYCODE_BUTTON_A, "1")
            set(a, KeyEvent.KEYCODE_BUTTON_B, "2")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "3")
            // Baris atas: 4 5 6
            set(y, KeyEvent.KEYCODE_BUTTON_X, "4")
            set(x, KeyEvent.KEYCODE_BUTTON_Y, "5")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "6")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "KOIN")
        } else if (genesisLayout) {
            // Baris bawah: A B C
            set(a, KeyEvent.KEYCODE_BUTTON_X, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_B, "C")
            // Baris atas: X Y Z
            set(y, KeyEvent.KEYCODE_BUTTON_L1, "X")
            set(l, KeyEvent.KEYCODE_BUTTON_Y, "Y")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "Z")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "MODE")
        } else {
            set(a, KeyEvent.KEYCODE_BUTTON_B, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_Y, "X")
            set(y, KeyEvent.KEYCODE_BUTTON_X, "Y")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "L")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "R")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
        }
    }

    /** Susunan pad Genesis: D-pad kiri, A B C + X Y Z kanan, MODE/START di tengah bawah. */
    private fun placeGenesis(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * (if (portrait) 2.7f else 3.2f), baseY, 0f, 0f)

        val rm = u * (if (portrait) 1.3f else 2.2f)     // jarak tombol C ke tepi kanan
        val sx = u * 1.85f                              // jarak antar tombol dalam baris
        val slope = u * 0.3f                            // baris naik ke kanan, seperti pad aslinya
        val rad = 0.8f * u
        val hit = 1.0f * u
        val cx = w - rm
        val bottomY = baseY + 0.6f * u
        val topY = bottomY - 1.95f * u
        place(a, cx - 2 * sx, bottomY + slope, rad, hit)
        place(b, cx - sx, bottomY, rad, hit)
        place(x, cx, bottomY - slope, rad, hit)
        place(y, cx - 2 * sx, topY + slope, rad, hit)
        place(l, cx - sx, topY, rad, hit)
        place(r, cx, topY - slope, rad, hit)

        place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
    }

    /**
     * Susunan pad Game Boy Advance: D-pad kiri, A (kanan-atas) dan B (kiri-bawah) kanan,
     * L/R di sudut atas, SELECT dan START di bawah tombol A/B.
     */
    private fun placeGba(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * 3.2f, baseY, 0f, 0f)

        val fx = w - u * 3.0f                       // titik tengah antara A dan B
        val rad = 0.95f * u
        val hit = 1.15f * u
        place(a, fx + 1.0f * u, baseY - 0.5f * u, rad, hit)   // A: kanan, sedikit lebih tinggi
        place(b, fx - 1.0f * u, baseY + 0.5f * u, rad, hit)   // B: kiri, sedikit lebih rendah

        val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
        place(l, u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)
        place(r, w - u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)

        // SELECT dan START di bawah A/B, sedikit miring seperti di badan GBA
        place(sel, fx - 0.9f * u, baseY + 2.6f * u, 0.6f * u, 0.85f * u)
        place(start, fx + 0.9f * u, baseY + 2.4f * u, 0.6f * u, 0.85f * u)
    }

    /** Susunan panel arcade: joystick kiri, 2 baris x 3 tombol kanan (sedikit melengkung), KOIN/START di tengah bawah. */
    private fun placeArcade(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * (if (portrait) 2.7f else 3.2f), baseY, 0f, 0f)

        val rm = u * (if (portrait) 1.3f else 2.2f)     // jarak tombol kolom kanan ke tepi kanan
        val sx = u * 1.85f                              // jarak antar kolom
        val slope = u * 0.3f                            // kolom kanan sedikit lebih tinggi, seperti lengkung panel
        val rad = 0.8f * u
        val hit = 1.0f * u
        val cx = w - rm
        val bottomY = baseY + 0.6f * u
        val topY = bottomY - 1.95f * u
        // Baris bawah: 1 2 3
        place(b, cx - 2 * sx, bottomY + slope, rad, hit)
        place(a, cx - sx, bottomY, rad, hit)
        place(r, cx, bottomY - slope, rad, hit)
        // Baris atas: 4 5 6
        place(y, cx - 2 * sx, topY + slope, rad, hit)
        place(x, cx - sx, topY, rad, hit)
        place(l, cx, topY - slope, rad, hit)

        place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
    }

    private fun layoutAll(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val portrait = h > w
        // Pad Genesis potret memakai unit sedikit lebih kecil supaya D-pad dan 6 tombol muat berdampingan
        val u = min(w, h) * (if ((genesisLayout || arcadeLayout) && portrait) 0.095f else 0.11f)
        unit = u
        val baseY = h - u * 3.6f

        if (genesisLayout) {
            placeGenesis(w, h, u, portrait)
        } else if (arcadeLayout) {
            placeArcade(w, h, u, portrait)
        } else if (gbaLayout) {
            placeGba(w, h, u, portrait)
        } else {
            place(dir, u * 3.2f, baseY, 0f, 0f)    // radius diisi di applyScale() sesuai mode

            val fx = w - u * 3.4f
            place(a, fx + 1.8f * u, baseY, 0.95f * u, 1.35f * u)
            place(b, fx, baseY + 1.8f * u, 0.95f * u, 1.35f * u)
            place(x, fx, baseY - 1.8f * u, 0.95f * u, 1.35f * u)
            place(y, fx - 1.8f * u, baseY, 0.95f * u, 1.35f * u)

            val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
            place(l, u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)
            place(r, w - u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)

            place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
            place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        }

        // Timpa dengan tata letak tersimpan (jika ada) untuk orientasi ini
        val o = orient(w, h)
        scale = prefs.getFloat("${o}_scale", 1f)
        for (btn in all) {
            if (prefs.contains("${o}_${btn.key}_x")) {
                btn.cx = prefs.getFloat("${o}_${btn.key}_x", 0f) * w
                btn.cy = prefs.getFloat("${o}_${btn.key}_y", 0f) * h
            }
        }
        // Migrasi: tata letak lama punya 4 tombol arah terpisah; pusatnya = (x tombol atas, y tombol kiri)
        val upX = "${o}_${KeyEvent.KEYCODE_DPAD_UP}_x"
        val leftY = "${o}_${KeyEvent.KEYCODE_DPAD_LEFT}_y"
        if (!prefs.contains("${o}_${DIR_ID}_x") && prefs.contains(upX) && prefs.contains(leftY)) {
            dir.cx = prefs.getFloat(upX, 0f) * w
            dir.cy = prefs.getFloat(leftY, 0f) * h
        }
        applyScale()
    }

    private fun applyScale() {
        // Kontrol arah menempati area yang sama dengan 4 tombol lama; stik sedikit lebih kecil
        dir.br = unit * if (stickMode) 2.3f else if (genesisLayout) 2.4f else 2.7f
        // Pad Genesis: area sentuh D-pad lebih ketat agar tidak menabrak tombol A yang berdekatan
        dir.bh = dir.br * if (genesisLayout || arcadeLayout) 1.1f else 1.2f
        for (btn in all) { btn.r = btn.br * scale; btn.hit = btn.bh * scale }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = layoutAll(w, h)

    /** Buang perubahan yang belum disimpan. */
    fun reloadLayout() = layoutAll(width, height)

    fun saveLayout() {
        if (width <= 0 || height <= 0) return
        val o = orient(width, height)
        val e = prefs.edit().putFloat("${o}_scale", scale)
        for (btn in all) {
            e.putFloat("${o}_${btn.key}_x", btn.cx / width)
            e.putFloat("${o}_${btn.key}_y", btn.cy / height)
        }
        e.apply()
    }

    /** Kembali ke tata letak bawaan untuk orientasi saat ini. */
    fun resetLayout() {
        val o = orient(width, height)
        val e = prefs.edit().remove("${o}_scale")
        for (btn in all) { e.remove("${o}_${btn.key}_x"); e.remove("${o}_${btn.key}_y") }
        for (k in DPAD_KEYS) { e.remove("${o}_${k}_x"); e.remove("${o}_${k}_y") }   // sisa tata letak lama
        e.apply()
        layoutAll(width, height)
    }

    fun changeScale(delta: Float) {
        scale = (scale + delta).coerceIn(0.6f, 1.6f)
        applyScale()
    }

    // ------------------------------------------------------------ gambar

    private fun releaseAll() {
        for (k in pressed) onKey?.invoke(k, false)
        pressed = emptySet()
        if (stickPointer != -1 || stickX != 0f || stickY != 0f) onAnalog?.invoke(0f, 0f)
        stickPointer = -1
        stickX = 0f; stickY = 0f
    }

    /** Dipanggil saat kontrol disembunyikan (gamepad fisik terhubung) supaya tidak ada tombol yang tertahan. */
    fun releaseTouches() { releaseAll(); invalidate() }

    override fun onDraw(c: Canvas) {
        val base = (if (editMode) max(opacity, 60) else opacity).coerceIn(10, 100) / 100f
        stroke.strokeWidth = if (editMode) 5f else 3f
        for (btn in buttons) {
            val on = btn.key in pressed || btn === dragging
            fill.alpha = ((if (on) 0.55f else 0.18f) * base * 255).toInt()
            stroke.alpha = (0.9f * base * 255).toInt()
            text.alpha = (base * 255).toInt()
            text.textSize = btn.r * if (btn.label.length > 1) 0.55f else 0.95f
            c.drawCircle(btn.cx, btn.cy, btn.r, fill)
            c.drawCircle(btn.cx, btn.cy, btn.r, stroke)
            c.drawText(btn.label, btn.cx, btn.cy + text.textSize * 0.35f, text)
        }
        if (stickMode) drawStick(c, base) else drawDpad(c, base)
    }

    private fun drawStick(c: Canvas, base: Float) {
        val on = stickPointer != -1 || dir === dragging
        fill.alpha = ((if (on) 0.30f else 0.12f) * base * 255).toInt()
        stroke.alpha = (0.9f * base * 255).toInt()
        c.drawCircle(dir.cx, dir.cy, dir.r, fill)
        c.drawCircle(dir.cx, dir.cy, dir.r, stroke)
        // Penanda 8 arah tipis di tepi
        text.alpha = (0.5f * base * 255).toInt()
        text.textSize = dir.r * 0.28f
        c.drawText("▲", dir.cx, dir.cy - dir.r * 0.72f + text.textSize * 0.35f, text)
        c.drawText("▼", dir.cx, dir.cy + dir.r * 0.72f + text.textSize * 0.35f, text)
        c.drawText("◀", dir.cx - dir.r * 0.72f, dir.cy + text.textSize * 0.35f, text)
        c.drawText("▶", dir.cx + dir.r * 0.72f, dir.cy + text.textSize * 0.35f, text)
        // Kenop mengikuti jari
        val kr = dir.r * 0.42f
        val kx = dir.cx + stickX * (dir.r - kr * 0.4f)
        val ky = dir.cy + stickY * (dir.r - kr * 0.4f)
        fill.alpha = ((if (on) 0.60f else 0.30f) * base * 255).toInt()
        c.drawCircle(kx, ky, kr, fill)
        c.drawCircle(kx, ky, kr, stroke)
    }

    private fun drawDpad(c: Canvas, base: Float) {
        val arm = dir.r * 0.34f                 // setengah lebar lengan salib
        val len = dir.r
        val cx = dir.cx; val cy = dir.cy
        val corner = arm * 0.45f
        val moving = dir === dragging
        stroke.alpha = (0.9f * base * 255).toInt()

        // Lengan: atas, bawah, kiri, kanan
        val arms = arrayOf(
            RectF(cx - arm, cy - len, cx + arm, cy),
            RectF(cx - arm, cy, cx + arm, cy + len),
            RectF(cx - len, cy - arm, cx, cy + arm),
            RectF(cx, cy - arm, cx + len, cy + arm)
        )
        for ((i, k) in DPAD_KEYS.withIndex()) {
            val on = k in pressed || moving
            fill.alpha = ((if (on) 0.55f else 0.18f) * base * 255).toInt()
            c.drawRoundRect(arms[i], corner, corner, fill)
        }
        // Tengah: menyala bila ada arah yang ditekan
        val any = DPAD_KEYS.any { it in pressed } || moving
        fill.alpha = ((if (any) 0.40f else 0.18f) * base * 255).toInt()
        rect.set(cx - arm, cy - arm, cx + arm, cy + arm)
        c.drawRect(rect, fill)

        // Garis tepi salib (satu jalur utuh)
        val p = Path().apply {
            moveTo(cx - arm, cy - len); lineTo(cx + arm, cy - len); lineTo(cx + arm, cy - arm)
            lineTo(cx + len, cy - arm); lineTo(cx + len, cy + arm); lineTo(cx + arm, cy + arm)
            lineTo(cx + arm, cy + len); lineTo(cx - arm, cy + len); lineTo(cx - arm, cy + arm)
            lineTo(cx - len, cy + arm); lineTo(cx - len, cy - arm); lineTo(cx - arm, cy - arm)
            close()
        }
        c.drawPath(p, stroke)

        // Segitiga arah
        val t = arm * 0.55f
        val d = len - arm * 0.9f
        text.alpha = (base * 255).toInt()
        fill.alpha = (base * 255).toInt()
        fun arrow(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
            tri.reset(); tri.moveTo(x1, y1); tri.lineTo(x2, y2); tri.lineTo(x3, y3); tri.close()
            c.drawPath(tri, fill)
        }
        arrow(cx, cy - d - t * 0.5f, cx - t, cy - d + t * 0.6f, cx + t, cy - d + t * 0.6f)
        arrow(cx, cy + d + t * 0.5f, cx - t, cy + d - t * 0.6f, cx + t, cy + d - t * 0.6f)
        arrow(cx - d - t * 0.5f, cy, cx - d + t * 0.6f, cy - t, cx - d + t * 0.6f, cy + t)
        arrow(cx + d + t * 0.5f, cy, cx + d - t * 0.6f, cy - t, cx + d - t * 0.6f, cy + t)
    }

    // ------------------------------------------------------------ sentuhan

    /**
     * Ubah vektor (dx, dy) menjadi arah digital 8 arah.
     * Sudut dibagi rata: tiap arah lurus dan tiap arah serong mendapat sektor 45°.
     */
    private fun dirKeys(dx: Float, dy: Float, out: MutableSet<Int>) {
        val ax = abs(dx); val ay = abs(dy)
        val diagonal = ay >= ax * DIAG_RATIO && ax >= ay * DIAG_RATIO
        val horiz = diagonal || ay < ax * DIAG_RATIO      // kiri/kanan (lurus atau serong)
        val vert = diagonal || ax < ay * DIAG_RATIO       // atas/bawah (lurus atau serong)
        if (horiz) out.add(if (dx < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        if (vert) out.add(if (dy < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editMode) return handleEdit(e)

        val now = HashSet<Int>()
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1

        // Stik analog: kunci ke satu jari sejak menyentuh area stik sampai dilepas
        if (stickMode) {
            if (ending) stickPointer = -1
            if (stickPointer != -1) {
                val idx = e.findPointerIndex(stickPointer)
                if (idx < 0 || idx == skip) stickPointer = -1
            }
            if (stickPointer == -1 && !ending &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_POINTER_DOWN)
            ) {
                val i = e.actionIndex
                if (hypot(e.getX(i) - dir.cx, e.getY(i) - dir.cy) <= dir.hit) stickPointer = e.getPointerId(i)
            }
            var sx = 0f; var sy = 0f
            if (stickPointer != -1) {
                val i = e.findPointerIndex(stickPointer)
                var vx = (e.getX(i) - dir.cx) / dir.r
                var vy = (e.getY(i) - dir.cy) / dir.r
                val m = hypot(vx, vy)
                if (m > 1f) { vx /= m; vy /= m }
                sx = vx; sy = vy
                if (hypot(sx, sy) >= STICK_DEAD) dirKeys(sx, sy, now)
            }
            if (sx != stickX || sy != stickY) {
                stickX = sx; stickY = sy
                if (!arcadeLayout) onAnalog?.invoke(sx, sy)     // joystick arcade murni digital
            }
        }

        if (!ending) {
            for (i in 0 until e.pointerCount) {
                if (i == skip || e.getPointerId(i) == stickPointer) continue
                val px = e.getX(i); val py = e.getY(i)
                for (btn in buttons) {
                    if (hypot(px - btn.cx, py - btn.cy) <= btn.hit) now.add(btn.key)
                }
                if (!stickMode) {
                    val dx = px - dir.cx; val dy = py - dir.cy
                    val dist = hypot(dx, dy)
                    if (dist <= dir.hit && dist >= dir.r * DPAD_DEAD) dirKeys(dx, dy, now)
                }
            }
        }
        val added = now - pressed
        for (k in pressed - now) onKey?.invoke(k, false)
        for (k in added) onKey?.invoke(k, true)
        if (added.isNotEmpty() && haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        pressed = now
        invalidate()
        return true
    }

    private fun handleEdit(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = all
                    .filter { hypot(e.x - it.cx, e.y - it.cy) <= it.r * 1.3f }
                    .minByOrNull { hypot(e.x - it.cx, e.y - it.cy) }
            }
            MotionEvent.ACTION_MOVE -> dragging?.let {
                it.cx = e.x.coerceIn(it.r, max(it.r, width - it.r))
                it.cy = e.y.coerceIn(it.r, max(it.r, height - it.r))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = null
        }
        invalidate()
        return true
    }
}
