package com.allinone.emulator.input

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Kontrol layar sentuh multi-touch: D-pad, A/B/X/Y, L/R, Start/Select. */
class VirtualPadView(ctx: Context) : View(ctx) {

    var onKey: ((keyCode: Int, down: Boolean) -> Unit)? = null
    var haptics = true
    var opacity = 60
        set(v) { field = v; invalidate() }

    private class Btn(val key: Int, val label: String, val dpad: Boolean = false) {
        var cx = 0f; var cy = 0f; var r = 0f; var hit = 0f
    }

    private val up = Btn(KeyEvent.KEYCODE_DPAD_UP, "▲", true)
    private val down = Btn(KeyEvent.KEYCODE_DPAD_DOWN, "▼", true)
    private val left = Btn(KeyEvent.KEYCODE_DPAD_LEFT, "◀", true)
    private val right = Btn(KeyEvent.KEYCODE_DPAD_RIGHT, "▶", true)
    private val a = Btn(KeyEvent.KEYCODE_BUTTON_B, "A")   // timur
    private val b = Btn(KeyEvent.KEYCODE_BUTTON_A, "B")   // selatan
    private val x = Btn(KeyEvent.KEYCODE_BUTTON_Y, "X")   // utara
    private val y = Btn(KeyEvent.KEYCODE_BUTTON_X, "Y")   // barat
    private val l = Btn(KeyEvent.KEYCODE_BUTTON_L1, "L")
    private val r = Btn(KeyEvent.KEYCODE_BUTTON_R1, "R")
    private val sel = Btn(KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
    private val start = Btn(KeyEvent.KEYCODE_BUTTON_START, "START")
    private val all = listOf(up, down, left, right, a, b, x, y, l, r, sel, start)

    private var pressed: Set<Int> = emptySet()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER
    }

    private fun place(btn: Btn, cx: Float, cy: Float, r: Float, hit: Float) {
        btn.cx = cx; btn.cy = cy; btn.r = r; btn.hit = hit
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val u = min(w, h) * 0.11f
        val portrait = h > w
        val baseY = h - u * 3.6f

        val dx = u * 3.2f
        place(up, dx, baseY - 1.9f * u, 0.95f * u, 1.45f * u)
        place(down, dx, baseY + 1.9f * u, 0.95f * u, 1.45f * u)
        place(left, dx - 1.9f * u, baseY, 0.95f * u, 1.45f * u)
        place(right, dx + 1.9f * u, baseY, 0.95f * u, 1.45f * u)

        val fx = w - u * 3.4f
        place(a, fx + 1.8f * u, baseY, 0.95f * u, 1.35f * u)
        place(b, fx, baseY + 1.8f * u, 0.95f * u, 1.35f * u)
        place(x, fx, baseY - 1.8f * u, 0.95f * u, 1.35f * u)
        place(y, fx - 1.8f * u, baseY, 0.95f * u, 1.35f * u)

        val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
        place(l, u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)
        place(r, w - u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)

        place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
    }

    override fun onDraw(c: Canvas) {
        val base = opacity.coerceIn(10, 100) / 100f
        for (btn in all) {
            val on = btn.key in pressed
            fill.alpha = ((if (on) 0.55f else 0.18f) * base * 255).toInt()
            stroke.alpha = (0.9f * base * 255).toInt()
            text.alpha = (base * 255).toInt()
            text.textSize = btn.r * if (btn.label.length > 1 && !btn.dpad) 0.55f else 0.95f
            c.drawCircle(btn.cx, btn.cy, btn.r, fill)
            c.drawCircle(btn.cx, btn.cy, btn.r, stroke)
            c.drawText(btn.label, btn.cx, btn.cy + text.textSize * 0.35f, text)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = HashSet<Int>()
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        if (!ending) {
            for (i in 0 until e.pointerCount) {
                if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                for (btn in all) {
                    if (hypot(e.getX(i) - btn.cx, e.getY(i) - btn.cy) <= btn.hit) now.add(btn.key)
                }
            }
        }
        for (k in pressed - now) onKey?.invoke(k, false)
        for (k in now - pressed) {
            onKey?.invoke(k, true)
            if (haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        pressed = now
        invalidate()
        return true
    }
}
