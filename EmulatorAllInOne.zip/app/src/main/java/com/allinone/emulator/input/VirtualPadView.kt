package com.allinone.emulator.input

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.HapticFeedbackConstants
import com.allinone.emulator.R
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Kontrol layar sentuh multi-touch: D-pad 8 arah (termasuk serong) atau stik analog, A/B/X/Y, L/R, Start/Select.
 * Tata letak (posisi tiap kontrol + ukuran) bisa diatur dan disimpan terpisah untuk potret dan lanskap.
 */
class VirtualPadView(ctx: Context) : View(ctx) {

    var onKey: ((keyCode: Int, down: Boolean) -> Unit)? = null

    /** Posisi stik analog (-1..1) saat mode analog; dikirim juga sebagai sumbu analog kiri. */
    var onAnalog: ((x: Float, y: Float) -> Unit)? = null

    var haptics = true
    var opacity = 60
        set(v) { field = v; invalidate() }

    /** false = D-pad 8 arah, true = stik analog (keluarannya tetap dijadikan arah digital untuk konsol 2D). */
    var analogMode = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            applyScale()
        }

    /**
     * true = tata letak pad Sega Genesis / Mega Drive 6 tombol: A B C (baris bawah, sedikit miring naik ke kanan)
     * dan X Y Z (baris atas), plus MODE dan START. Tanpa L/R. Tata letak tersimpan terpisah dari mode standar.
     *
     * Pemetaan fungsi resmi Sega ke core Genesis Plus GX (libretro): A=RetroPad Y, B=RetroPad B, C=RetroPad A,
     * X=RetroPad L, Y=RetroPad X, Z=RetroPad R, MODE=Select, START=Start. Dikirim sebagai keycode: A=BUTTON_Y,
     * B=BUTTON_B, C=BUTTON_A, X=L1, Y=BUTTON_X, Z=R1.
     */
    var genesisLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            syncCombos()
            layoutAll(width, height)
        }

    /**
     * true = tata letak pad Game Boy Advance asli: D-pad di kiri, hanya tombol A dan B di kanan
     * (A di kanan-atas, B di kiri-bawah, miring seperti aslinya), L/R berbentuk baji bahu di sudut atas,
     * serta START dan SELECT berupa tombol bulat kecil bertumpuk dengan pelat tulisan miring di kirinya.
     * Tanpa tombol X/Y karena GBA memang tidak punya. Tata letak tersimpan terpisah dari mode lain.
     *
     * Pemetaan ke core mGBA (libretro): A=KEYCODE_BUTTON_A, B=KEYCODE_BUTTON_B (ditukar karena di perangkat
     * konfirmasi jatuh ke tombol B pada pemetaan sebelumnya).
     */
    var gbaLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            syncCombos()
            layoutAll(width, height)
        }

    /**
     * true = tata letak panel arcade (MAME): joystick 8 arah (digital, tanpa analog) di kiri,
     * 6 tombol aksi dalam dua baris tiga di kanan, serta KOIN dan START.
     *
     * Pemetaan ke core arcade (libretro), disusun seperti panel Capcom 6 tombol:
     * baris bawah 1 2 3 = RetroPad B, A, R (tendangan lemah/sedang/kuat pada game fighting Capcom),
     * baris atas 4 5 6 = RetroPad Y, X, L (pukulan lemah/sedang/kuat). KOIN = Select (insert coin), START = Start.
     * LibretroDroid menerjemahkan KEYCODE_BUTTON_A -> B, BUTTON_B -> A, BUTTON_X -> Y, BUTTON_Y -> X.
     */
    var arcadeLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            syncCombos()
            layoutAll(width, height)
        }

    /**
     * true = tampilan ala pad Super Nintendo: X/Y ungu muda, A/B ungu tua (warna tombol SNES asli),
     * sedangkan D-pad, L/R, Select/Start memakai warna gelap supaya terlihat di latar abu-abu terang.
     * Hanya mengubah tampilan; pemetaan tombol tidak berubah.
     */
    var snesStyle = false
        set(v) { field = v; invalidate() }

    /**
     * true = tata letak pad Super Nintendo asli: D-pad salib polos di kiri (bisa diganti stik analog lewat Pengaturan; keluarannya tetap arah digital karena SNES tidak punya analog),
     * empat tombol A B X Y berbentuk belah ketupat di kanan (X atas, B bawah, Y kiri, A kanan),
     * tombol bahu L/R lebar di sudut atas, serta SELECT dan START berbentuk pil kecil miring di tengah
     * dengan tulisan di bawahnya. Tata letak tersimpan terpisah dari mode lain.
     *
     * Pemetaan ke core Snes9x: label = sinyal, yaitu A=KEYCODE_BUTTON_A, B=KEYCODE_BUTTON_B,
     * X=KEYCODE_BUTTON_X, Y=KEYCODE_BUTTON_Y (sama seperti GBA).
     */
    var snesLayout = false
        set(v) {
            if (field == v) return
            releaseAll()
            field = v
            configureButtons()
            syncCombos()
            layoutAll(width, height)
        }

    /** Kontrol arah berbentuk stik (mode analog pilihan pengguna, atau joystick pada pad arcade). */
    private val stickMode: Boolean get() = analogMode || arcadeLayout

    /** Mode atur tata letak: sentuhan menggeser tombol, bukan mengirim input. */
    var editMode = false
        set(v) {
            field = v
            if (v) releaseAll()
            dragging = null
            applyScale()        // daftar tombol berubah (slot kombo GBA yang kosong tampil hanya saat mengatur); invalidate di dalamnya
        }

    /** Mode atur: ketuk slot kombo (0 atau 1) -> aktivitas menampilkan pilihan tombol yang digabung. */
    var onComboEdit: ((slot: Int) -> Unit)? = null

    private class Btn(var key: Int, var label: String) {
        var cx = 0f; var cy = 0f
        var br = 0f; var bh = 0f     // radius dan area sentuh dasar
        var r = 0f; var hit = 0f     // setelah skala
        var off = false              // dinonaktifkan pengguna: tidak tampil dan tidak bisa disentuh saat bermain
        var pillW = 1f               // setengah panjang dibanding radius: 1 = bulat, >1 = kapsul (bahu, Select/Start SNES)
        var tilt = 0f                // kemiringan kapsul dalam derajat (negatif = ujung kanan naik)
        var combo: IntArray? = null  // bila terisi: tombol kombo, satu sentuhan menekan semua kode ini sekaligus

        /** Apakah titik (px, py) berada dalam jarak [rad] dari bentuk tombol (lingkaran atau kapsul miring). */
        fun touches(px: Float, py: Float, rad: Float): Boolean {
            var dx = px - cx; var dy = py - cy
            if (tilt != 0f) {
                val t = Math.toRadians(-tilt.toDouble())
                val cs = cos(t).toFloat(); val sn = sin(t).toFloat()
                val rx = dx * cs - dy * sn; val ry = dx * sn + dy * cs
                dx = rx; dy = ry
            }
            val ex = max(abs(dx) - r * (pillW - 1f), 0f)
            return hypot(ex, dy) <= rad
        }
    }

    private val a = Btn(KeyEvent.KEYCODE_BUTTON_B, "A")   // timur
    private val b = Btn(KeyEvent.KEYCODE_BUTTON_A, "B")   // selatan
    private val x = Btn(KeyEvent.KEYCODE_BUTTON_Y, "X")   // utara
    private val y = Btn(KeyEvent.KEYCODE_BUTTON_X, "Y")   // barat
    private val l = Btn(KeyEvent.KEYCODE_BUTTON_L1, "L")
    private val r = Btn(KeyEvent.KEYCODE_BUTTON_R1, "R")
    private val sel = Btn(KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
    private val start = Btn(KeyEvent.KEYCODE_BUTTON_START, "START")

    /** Kontrol arah (D-pad atau stik). Kunci 0 dipakai untuk menyimpan posisinya. */
    private val dir = Btn(DIR_ID, "")
    init { configureButtons() }
    private val allButtons = listOf(a, b, x, y, l, r, sel, start)

    /**
     * Tombol kombo panel arcade (2 slot). Kunci tombol bernilai negatif supaya tidak bentrok dengan kode tombol asli
     * dan posisinya tersimpan sendiri di tata letak.
     */
    private val combo1 = Btn(COMBO_ID_1, "").apply { pillW = 1.6f }
    private val combo2 = Btn(COMBO_ID_2, "").apply { pillW = 1.6f }
    private val comboButtons = listOf(combo1, combo2)

    /** Token tombol SNES -> kode tombol (urutan sama dengan [SNES_COMBO_KEYS]). Pemetaan sama dengan configureButtons() untuk SNES. */
    private val snesLetterKeys: Map<String, Int> = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_A, "B" to KeyEvent.KEYCODE_BUTTON_B,
        "X" to KeyEvent.KEYCODE_BUTTON_X, "Y" to KeyEvent.KEYCODE_BUTTON_Y,
        "L" to KeyEvent.KEYCODE_BUTTON_L1, "R" to KeyEvent.KEYCODE_BUTTON_R1,
        "SELECT" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START,
        "↑" to KeyEvent.KEYCODE_DPAD_UP, "↓" to KeyEvent.KEYCODE_DPAD_DOWN,
        "←" to KeyEvent.KEYCODE_DPAD_LEFT, "→" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    /** Token tombol arcade -> kode tombol (urutan sama dengan [ARCADE_COMBO_KEYS]). Pemetaan sama dengan configureButtons() untuk arcade. */
    private val arcadeNumberKeys: Map<String, Int> = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_B, "B" to KeyEvent.KEYCODE_BUTTON_A, "C" to KeyEvent.KEYCODE_BUTTON_R1,
        "X" to KeyEvent.KEYCODE_BUTTON_Y, "Y" to KeyEvent.KEYCODE_BUTTON_X, "Z" to KeyEvent.KEYCODE_BUTTON_L1,
        "KOIN" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START,
        "↑" to KeyEvent.KEYCODE_DPAD_UP, "↓" to KeyEvent.KEYCODE_DPAD_DOWN,
        "←" to KeyEvent.KEYCODE_DPAD_LEFT, "→" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    /**
     * Isi kombo 1 dan 2, token dipisah "+", mis. "4+5+6" (arcade) atau "A+B" (SNES). Bawaan KOSONG: kosong atau tidak
     * valid = tombol itu tidak tampil saat bermain. Pengguna mengisinya lewat mode atur tata letak.
     */
    var combo1Spec = ""
        set(v) { if (field != v) { field = v; refreshCombos() } }
    var combo2Spec = ""
        set(v) { if (field != v) { field = v; refreshCombos() } }

    /** Token tombol GBA -> kode tombol (urutan sama dengan [GBA_COMBO_KEYS]). Pemetaan sama dengan configureButtons(). */
    private val gbaTokenKeys: Map<String, Int> = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_A, "B" to KeyEvent.KEYCODE_BUTTON_B,
        "L" to KeyEvent.KEYCODE_BUTTON_L1, "R" to KeyEvent.KEYCODE_BUTTON_R1,
        "SEL" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START,
        "↑" to KeyEvent.KEYCODE_DPAD_UP, "↓" to KeyEvent.KEYCODE_DPAD_DOWN,
        "←" to KeyEvent.KEYCODE_DPAD_LEFT, "→" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    /** Token tombol Genesis -> kode tombol (urutan sama dengan [GENESIS_COMBO_KEYS]). Pemetaan sama dengan configureButtons() untuk Genesis. */
    private val genesisTokenKeys: Map<String, Int> = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_Y, "B" to KeyEvent.KEYCODE_BUTTON_B, "C" to KeyEvent.KEYCODE_BUTTON_A,
        "X" to KeyEvent.KEYCODE_BUTTON_L1, "Y" to KeyEvent.KEYCODE_BUTTON_X, "Z" to KeyEvent.KEYCODE_BUTTON_R1,
        "MODE" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START,
        "↑" to KeyEvent.KEYCODE_DPAD_UP, "↓" to KeyEvent.KEYCODE_DPAD_DOWN,
        "←" to KeyEvent.KEYCODE_DPAD_LEFT, "→" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    /** Semua tata letak (GBA, Genesis, SNES, arcade): kombo bebas, kosong dan tersembunyi sampai pengguna mengisinya lewat mode atur tata letak. */
    private val customCombo: Boolean get() = gbaLayout || genesisLayout || snesLayout || arcadeLayout

    /** Label tombol yang berlaku untuk kombo pada tata letak saat ini (token GBA/Genesis, angka di arcade, huruf di SNES). */
    private val comboKeyMap: Map<String, Int> get() =
        if (gbaLayout) gbaTokenKeys else if (genesisLayout) genesisTokenKeys else if (snesLayout) snesLetterKeys else arcadeNumberKeys

    /** Ubah teks "4+5+6" menjadi daftar kode tombol (tanpa duplikat, urut seperti diketik). Null bila tidak ada yang valid. */
    private fun parseCombo(spec: String): IntArray? {
        val keys = spec.split('+').map { it.trim() }.mapNotNull { comboKeyMap[it] }.distinct()
        return if (keys.isEmpty()) null else keys.toIntArray()
    }

    private fun cleanLabel(spec: String) =
        spec.split('+').map { it.trim() }.filter { it in comboKeyMap }.distinct().joinToString("+")

    /** Hitung ulang isi kombo sesuai tata letak saat ini (angka arcade / huruf SNES). */
    private fun syncCombos() {
        combo1.combo = parseCombo(combo1Spec); combo1.label = cleanLabel(combo1Spec)
        combo2.combo = parseCombo(combo2Spec); combo2.label = cleanLabel(combo2Spec)
    }

    private fun refreshCombos() {
        releaseAll()
        syncCombos()
        // Saat mengatur tata letak, jangan muat ulang posisi tersimpan: geseran yang belum disimpan akan hilang
        if (editMode) applyScale() else layoutAll(width, height)
    }

    /**
     * Tombol kombo yang tampil: hanya yang berisi saat bermain (bawaan kosong = tidak tampil); saat mengatur
     * tata letak kedua slot tampil, yang kosong sebagai kotak putus-putus "+ Kombo" supaya bisa diisi.
     */
    private val activeCombos: List<Btn> get() =
        if (!customCombo) emptyList() else if (editMode) comboButtons else comboButtons.filter { it.combo != null }

    /** Tombol yang aktif (tampil dan bisa disentuh) pada mode saat ini; GBA tidak punya X dan Y. */
    private val buttons: List<Btn> get() =
        if (gbaLayout) listOf(a, b, l, r, sel, start) + activeCombos else allButtons + activeCombos
    init {
        combo1.combo = parseCombo(combo1Spec); combo1.label = combo1Spec
        combo2.combo = parseCombo(combo2Spec); combo2.label = combo2Spec
    }
    private val all: List<Btn> get() = buttons + dir
    /** Semua yang posisinya disimpan: juga slot kombo yang sedang tersembunyi, supaya posisinya tidak hilang. */
    private val layoutTargets: List<Btn> get() =
        all + (if (customCombo) comboButtons.filter { it !in all } else emptyList())
    /** Tombol yang tidak dinonaktifkan pengguna. */
    private val liveButtons: List<Btn> get() = buttons.filter { !it.off }

    private val prefs = ctx.getSharedPreferences("padlayout", Context.MODE_PRIVATE)
    private var scale = 1f          // ukuran semua tombol (tanpa D-pad/stik)
    private var dirScale = 1f       // ukuran D-pad/stik, terpisah dari tombol lain
    private var unit = 0f
    private var dragging: Btn? = null
    private var pressed: Set<Int> = emptySet()       // tombol biasa + arah digital yang sedang ditekan
    private var comboOn: Set<Btn> = emptySet()       // tombol kombo yang sedang disentuh

    // Stik analog
    private var stickPointer = -1
    private var stickX = 0f
    private var stickY = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val tri = Path()

    companion object {
        private const val DIR_ID = 0
        private const val COMBO_ID_1 = -101
        private const val COMBO_ID_2 = -102

        /** Token tombol yang bisa digabung dalam kombo GBA, berurutan seperti pilihan di dialog. */
        val GBA_COMBO_KEYS = listOf("A", "B", "L", "R", "SEL", "START", "↑", "↓", "←", "→")

        /** Token tombol yang bisa digabung dalam kombo Genesis, berurutan seperti pilihan di dialog. */
        val GENESIS_COMBO_KEYS = listOf("A", "B", "C", "X", "Y", "Z", "MODE", "START", "↑", "↓", "←", "→")

        /** Token tombol yang bisa digabung dalam kombo SNES, berurutan seperti pilihan di dialog. */
        val SNES_COMBO_KEYS = listOf("A", "B", "X", "Y", "L", "R", "SELECT", "START", "↑", "↓", "←", "→")

        /** Token tombol yang bisa digabung dalam kombo arcade, berurutan seperti pilihan di dialog. */
        val ARCADE_COMBO_KEYS = listOf("A", "B", "C", "X", "Y", "Z", "KOIN", "START", "↑", "↓", "←", "→")

        /** Warna latar layar game untuk SNES (abu-abu netral). */
        val SNES_BG: Int = 0xFFB4B4B4.toInt()
        private val SNES_INK: Int = 0xFF4A4448.toInt()        // warna D-pad, L/R, Select/Start di atas latar terang
        private val SNES_LIGHT: Int = 0xFF8972B8.toInt()      // tombol X dan Y
        private val SNES_DARK: Int = 0xFF3A236B.toInt()       // tombol A dan B
        private val DPAD_KEYS = intArrayOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
        )
        private const val DIAG_RATIO = 0.4142f          // tan(22,5°): batas antara arah lurus dan serong
        private const val DPAD_DEAD = 0.22f             // zona mati di tengah D-pad (pecahan radius)
        private val DIR_KEYS = setOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
        )
        private const val STICK_DEAD = 0.30f            // ambang stik analog menjadi arah digital
    }

    // ------------------------------------------------------------ tata letak

    private fun place(btn: Btn, cx: Float, cy: Float, r: Float, hit: Float) {
        btn.cx = cx; btn.cy = cy; btn.br = r; btn.bh = hit
    }

    private fun orient(w: Int, h: Int) =
        (if (genesisLayout) "gen_" else if (gbaLayout) "gba_" else if (arcadeLayout) "arc_" else if (snesLayout) "snes_" else "") + (if (w > h) "land" else "port")

    /** Isi kode tombol dan label sesuai mode. Objek tombol dipakai ulang; hanya kode + label yang berganti. */
    private fun configureButtons() {
        fun set(btn: Btn, key: Int, label: String) { btn.key = key; btn.label = label }
        for (bt in listOf(a, b, x, y, l, r, sel, start)) { bt.pillW = 1f; bt.tilt = 0f }
        if (arcadeLayout) {
            // Urutan seperti panel arcade asli (MAME 0.78: tombol 1-3 = pukulan ringan/sedang/kuat, 4-6 = tendangan).
            // RetroPad MAME: tombol1=B, tombol2=A, tombol3=R, tombol4=Y, tombol5=X, tombol6=L
            // Baris bawah (tendangan ringan/sedang/kuat): X Y Z = tombol 4 5 6
            set(b, KeyEvent.KEYCODE_BUTTON_Y, "X")
            set(a, KeyEvent.KEYCODE_BUTTON_X, "Y")
            set(r, KeyEvent.KEYCODE_BUTTON_L1, "Z")
            // Baris atas (pukulan ringan/sedang/kuat): A B C = tombol 1 2 3
            set(y, KeyEvent.KEYCODE_BUTTON_B, "A")
            set(x, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(l, KeyEvent.KEYCODE_BUTTON_R1, "C")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "KOIN")
        } else if (genesisLayout) {
            // Baris bawah: A B C
            // Fungsi resmi Sega 6 tombol (core Genesis Plus GX): A=RetroPad Y, B=RetroPad B, C=RetroPad A,
            // X=RetroPad L, Y=RetroPad X, Z=RetroPad R
            set(a, KeyEvent.KEYCODE_BUTTON_Y, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_B, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_A, "C")
            // Baris atas: X Y Z
            set(y, KeyEvent.KEYCODE_BUTTON_L1, "X")
            set(l, KeyEvent.KEYCODE_BUTTON_X, "Y")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "Z")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "MODE")
            set(start, KeyEvent.KEYCODE_BUTTON_START, "START")
            sel.pillW = 2.4f; start.pillW = 2.4f          // pil abu-abu datar, tulisan di bawahnya
        } else if (snesLayout) {
            // Label = sinyal: A kirim BUTTON_A, B kirim BUTTON_B, X kirim BUTTON_X, Y kirim BUTTON_Y
            set(a, KeyEvent.KEYCODE_BUTTON_A, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_B, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_X, "X")
            set(y, KeyEvent.KEYCODE_BUTTON_Y, "Y")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "L")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "R")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "SELECT")
            set(start, KeyEvent.KEYCODE_BUTTON_START, "START")
            l.pillW = 2.4f; r.pillW = 2.4f                                  // bahu lebar
            sel.pillW = 2.3f; sel.tilt = -25f                               // pil kecil miring, ujung kanan naik
            start.pillW = 2.3f; start.tilt = -25f
        } else if (gbaLayout) {
            set(a, KeyEvent.KEYCODE_BUTTON_A, "A")   // ditukar: label A kini mengirim BUTTON_A
            set(b, KeyEvent.KEYCODE_BUTTON_B, "B")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "L")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "R")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "SELECT")
            set(start, KeyEvent.KEYCODE_BUTTON_START, "START")
            l.pillW = 2.6f; l.tilt = -12f      // bahu GBA: baji lebar, ujung dalam naik
            r.pillW = 2.6f; r.tilt = 12f
        } else {
            set(a, KeyEvent.KEYCODE_BUTTON_B, "A")
            set(b, KeyEvent.KEYCODE_BUTTON_A, "B")
            set(x, KeyEvent.KEYCODE_BUTTON_Y, "X")
            set(y, KeyEvent.KEYCODE_BUTTON_X, "Y")
            set(l, KeyEvent.KEYCODE_BUTTON_L1, "L")
            set(r, KeyEvent.KEYCODE_BUTTON_R1, "R")
            set(sel, KeyEvent.KEYCODE_BUTTON_SELECT, "SEL")
        }
    }

    /** Susunan pad Genesis: D-pad kiri, A B C + X Y Z kanan, MODE/START di tengah bawah. */
    private fun placeGenesis(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * (if (portrait) 2.7f else 3.2f), baseY, 0f, 0f)

        val rm = u * (if (portrait) 1.3f else 2.2f)     // jarak tombol C ke tepi kanan
        val sx = u * 1.85f                              // jarak antar tombol dalam baris
        val slope = u * 0.3f                            // baris naik ke kanan, seperti pad aslinya
        val rad = 0.8f * u
        val hit = 1.0f * u
        val cx = w - rm
        val bottomY = baseY + 0.6f * u
        val topY = bottomY - 1.95f * u
        place(a, cx - 2 * sx, bottomY + slope, rad, hit)
        place(b, cx - sx, bottomY, rad, hit)
        place(x, cx, bottomY - slope, rad, hit)
        place(y, cx - 2 * sx, topY + slope, rad, hit)
        place(l, cx - sx, topY, rad, hit)
        place(r, cx, topY - slope, rad, hit)

        place(sel, w / 2f - u * 1.9f, h - u * 1.9f, 0.4f * u, 0.8f * u)
        place(start, w / 2f + u * 1.9f, h - u * 1.9f, 0.4f * u, 0.8f * u)

        // Slot kombo (kosong dan tersembunyi sampai pengguna mengisinya), satu baris di atas deretan X Y Z
        val comboY = topY - 2.4f * u
        place(combo1, cx - 3.0f * u, comboY, 0.8f * u, 1.0f * u)
        place(combo2, cx - 0.1f * u, comboY, 0.8f * u, 1.0f * u)
    }

    /**
     * Susunan pad Game Boy Advance: D-pad kiri, A (kanan-atas) dan B (kiri-bawah) kanan,
     * L/R di sudut atas, SELECT dan START di bawah tombol A/B.
     */
    private fun placeGba(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * 3.2f, baseY, 0f, 0f)

        val fx = w - u * 3.0f                       // titik tengah antara A dan B
        val rad = 0.95f * u
        val hit = 1.15f * u
        place(a, fx + 1.0f * u, baseY - 0.5f * u, rad, hit)   // A: kanan, sedikit lebih tinggi
        place(b, fx - 1.0f * u, baseY + 0.5f * u, rad, hit)   // B: kiri, sedikit lebih rendah

        val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
        // Bahu L/R berbentuk baji lebar (setengah panjang = 2,6 x radius), jadi pusatnya digeser ke dalam
        place(l, u * 2.1f, shoulderY, 0.75f * u, 1.0f * u)
        place(r, w - u * 2.1f, shoulderY, 0.75f * u, 1.0f * u)

        // START (atas) dan SELECT (bawah): tombol bulat kecil bertumpuk, pelat tulisan miring di sebelah kirinya
        val sx = fx + 1.3f * u
        place(start, sx, baseY + 2.0f * u, 0.5f * u, 0.8f * u)
        place(sel, sx, baseY + 3.0f * u, 0.5f * u, 0.8f * u)

        // Slot kombo (kosong dan tersembunyi sampai pengguna mengisinya), di atas tombol A/B
        place(combo1, fx - 1.5f * u, baseY - 2.6f * u, 0.8f * u, 1.0f * u)
        place(combo2, fx + 1.5f * u, baseY - 2.6f * u, 0.8f * u, 1.0f * u)
    }

    /**
     * Susunan pad Super Nintendo: D-pad kiri, belah ketupat A (kanan) B (bawah) X (atas) Y (kiri) di kanan,
     * L/R lebar di sudut atas, SELECT dan START berupa pil miring di tengah bawah.
     */
    private fun placeSnes(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * 3.2f, baseY, 0f, 0f)

        val fx = w - u * 3.4f
        val rad = 0.95f * u
        val hit = 1.35f * u
        place(a, fx + 1.8f * u, baseY, rad, hit)
        place(b, fx, baseY + 1.8f * u, rad, hit)
        place(x, fx, baseY - 1.8f * u, rad, hit)
        place(y, fx - 1.8f * u, baseY, rad, hit)

        val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
        place(l, u * 3.0f, shoulderY, 0.7f * u, 1.0f * u)
        place(r, w - u * 3.0f, shoulderY, 0.7f * u, 1.0f * u)

        place(sel, w / 2f - u * 1.7f, h - u * 1.6f, 0.36f * u, 0.8f * u)
        place(start, w / 2f + u * 1.7f, h - u * 1.6f, 0.36f * u, 0.8f * u)

        // Tombol kombo (kapsul biru) bertumpuk di kiri belah ketupat A B X Y, bisa digeser lewat Atur tata letak
        place(combo1, fx - 5.0f * u, baseY - 1.1f * u, 0.8f * u, 1.0f * u)
        place(combo2, fx - 5.0f * u, baseY + 1.2f * u, 0.8f * u, 1.0f * u)
    }

    /** Susunan panel arcade: joystick kiri, 2 baris x 3 tombol kanan (sedikit melengkung), KOIN/START di tengah bawah. */
    private fun placeArcade(w: Int, h: Int, u: Float, portrait: Boolean) {
        val baseY = h - u * 3.6f
        place(dir, u * (if (portrait) 2.7f else 3.2f), baseY, 0f, 0f)

        val rm = u * (if (portrait) 1.3f else 2.2f)     // jarak tombol kolom kanan ke tepi kanan
        val sx = u * 1.85f                              // jarak antar kolom
        val slope = u * 0.3f                            // kolom kanan sedikit lebih tinggi, seperti lengkung panel
        val rad = 0.8f * u
        val hit = 1.0f * u
        val cx = w - rm
        val bottomY = baseY + 0.6f * u
        val topY = bottomY - 1.95f * u
        // Baris bawah: 1 2 3
        place(b, cx - 2 * sx, bottomY + slope, rad, hit)
        place(a, cx - sx, bottomY, rad, hit)
        place(r, cx, bottomY - slope, rad, hit)
        // Baris atas: 4 5 6
        place(y, cx - 2 * sx, topY + slope, rad, hit)
        place(x, cx - sx, topY, rad, hit)
        place(l, cx, topY - slope, rad, hit)

        place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)

        // Tombol kombo (kapsul biru) satu baris di atas deretan tombol 4 5 6, bisa digeser lewat Atur tata letak
        val comboY = topY - 2.4f * u
        place(combo1, cx - 3.0f * u, comboY, 0.8f * u, 1.0f * u)
        place(combo2, cx - 0.1f * u, comboY, 0.8f * u, 1.0f * u)
    }

    // Ukuran bawaan (skala tombol, skala D-pad/stik) untuk lanskap; diisi oleh applyLandscapeDefaults()
    private var defScale = 1f
    private var defDirScale = 1f

    /**
     * Tata letak BAWAAN lanskap tiap emulator (posisi = pecahan lebar/tinggi layar, sama seperti yang disimpan
     * oleh saveLayout) beserta ukuran bawaannya. Potret tidak diubah. Tata letak yang sudah disimpan pengguna
     * tetap menimpa nilai ini; tombol Reset kembali ke nilai ini.
     */
    private fun applyLandscapeDefaults(w: Int, h: Int) {
        fun at(btn: Btn, fx: Float, fy: Float) { btn.cx = fx * w; btn.cy = fy * h }
        // Semua posisi diukur dari screenshot pengguna 2400x1080 (SNES, Genesis, arcade, GBA). Tampilan pad selalu selebar
        // layar penuh (game tampil sampai area poni), jadi posisi = koordinat layar / 2400 (lebar) dan / 1080 (tinggi).
        // Ukuran tombol/D-pad tidak berubah.
        if (genesisLayout) {
            defScale = 0.7f; defDirScale = 0.7f
            at(dir, 0.1062f, 0.7583f)
            at(a, 0.8333f, 0.8667f); at(b, 0.8938f, 0.7889f); at(x, 0.9542f, 0.738f)      // A B C
            at(y, 0.8304f, 0.6648f); at(l, 0.8867f, 0.5917f); at(r, 0.9446f, 0.5333f)      // X Y Z
            at(sel, 0.1537f, 0.4611f); at(start, 0.0733f, 0.4056f)      // MODE, START
        } else if (arcadeLayout) {
            defScale = 0.7f; defDirScale = 0.7f
            at(dir, 0.1092f, 0.838f)
            at(b, 0.8396f, 0.8778f); at(a, 0.8979f, 0.8269f); at(r, 0.9542f, 0.7759f)      // X Y Z (baris bawah)
            at(y, 0.8396f, 0.7222f); at(x, 0.8929f, 0.6759f); at(l, 0.9446f, 0.613f)      // A B C (baris atas)
            at(sel, 0.1467f, 0.5769f); at(start, 0.0804f, 0.5074f)      // KOIN, START
        } else if (gbaLayout) {
            // SELECT di kiri atas dan START di kanan atas (tombol bulat kecil di samping pelat tulisan), di bawah bahu L / R.
            defScale = 0.6f; defDirScale = 0.5f
            at(dir, 0.0925f, 0.8083f)
            at(a, 0.9304f, 0.7481f); at(b, 0.8896f, 0.8676f)
            at(l, 0.0825f, 0.5398f); at(r, 0.9271f, 0.5676f)
            at(sel, 0.1146f, 0.3852f); at(start, 0.9646f, 0.4324f)
        } else if (snesLayout) {
            defScale = 0.6f; defDirScale = 0.6f
            at(dir, 0.1138f, 0.7861f)
            at(a, 0.9433f, 0.7463f); at(b, 0.8958f, 0.875f); at(x, 0.8988f, 0.6194f); at(y, 0.8554f, 0.7389f)
            at(l, 0.1071f, 0.5028f); at(r, 0.9012f, 0.4537f)
            at(sel, 0.1388f, 0.3176f); at(start, 0.0604f, 0.3222f)
        }
    }

    private fun layoutAll(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val portrait = h > w
        // Pad Genesis potret memakai unit sedikit lebih kecil supaya D-pad dan 6 tombol muat berdampingan
        val u = min(w, h) * (if ((genesisLayout || arcadeLayout) && portrait) 0.095f else 0.11f)
        unit = u
        val baseY = h - u * 3.6f

        if (genesisLayout) {
            placeGenesis(w, h, u, portrait)
        } else if (arcadeLayout) {
            placeArcade(w, h, u, portrait)
        } else if (gbaLayout) {
            placeGba(w, h, u, portrait)
        } else if (snesLayout) {
            placeSnes(w, h, u, portrait)
        } else {
            place(dir, u * 3.2f, baseY, 0f, 0f)    // radius diisi di applyScale() sesuai mode

            val fx = w - u * 3.4f
            place(a, fx + 1.8f * u, baseY, 0.95f * u, 1.35f * u)
            place(b, fx, baseY + 1.8f * u, 0.95f * u, 1.35f * u)
            place(x, fx, baseY - 1.8f * u, 0.95f * u, 1.35f * u)
            place(y, fx - 1.8f * u, baseY, 0.95f * u, 1.35f * u)

            val shoulderY = if (portrait) baseY - 3.9f * u else u * 1.4f
            place(l, u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)
            place(r, w - u * 2.2f, shoulderY, 0.95f * u, 1.2f * u)

            place(sel, w / 2f - u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
            place(start, w / 2f + u * 1.5f, h - u * 1.2f, 0.65f * u, 0.9f * u)
        }

        // Lanskap: pakai tata letak + ukuran bawaan baru; potret tetap seperti semula
        defScale = 1f; defDirScale = 1f
        if (!portrait) applyLandscapeDefaults(w, h)

        // Timpa dengan tata letak tersimpan (jika ada) untuk orientasi ini
        val o = orient(w, h)
        val hasSavedScale = prefs.contains("${o}_scale")
        scale = prefs.getFloat("${o}_scale", defScale)
        // Tata letak lama: satu skala untuk semuanya, jadi D-pad/stik ikut memakai nilai itu sampai diatur sendiri
        dirScale = prefs.getFloat("${o}_dirscale", if (hasSavedScale) scale else defDirScale)
        for (btn in layoutTargets) {
            btn.off = prefs.getBoolean("${o}_${btn.key}_off", false)
            if (prefs.contains("${o}_${btn.key}_x")) {
                btn.cx = prefs.getFloat("${o}_${btn.key}_x", 0f) * w
                btn.cy = prefs.getFloat("${o}_${btn.key}_y", 0f) * h
            }
        }
        // Migrasi: tata letak lama punya 4 tombol arah terpisah; pusatnya = (x tombol atas, y tombol kiri)
        val upX = "${o}_${KeyEvent.KEYCODE_DPAD_UP}_x"
        val leftY = "${o}_${KeyEvent.KEYCODE_DPAD_LEFT}_y"
        if (!prefs.contains("${o}_${DIR_ID}_x") && prefs.contains(upX) && prefs.contains(leftY)) {
            dir.cx = prefs.getFloat(upX, 0f) * w
            dir.cy = prefs.getFloat(leftY, 0f) * h
        }
        applyScale()
    }

    private fun applyScale() {
        // Kontrol arah menempati area yang sama dengan 4 tombol lama; stik sedikit lebih kecil
        dir.br = unit * if (stickMode) 2.3f else if (genesisLayout) 2.4f else 2.7f
        // Pad Genesis: area sentuh D-pad lebih ketat agar tidak menabrak tombol A yang berdekatan
        dir.bh = dir.br * if (genesisLayout || arcadeLayout) 1.1f else 1.2f
        for (btn in layoutTargets) {
            if (btn === dir) continue
            btn.r = btn.br * scale; btn.hit = btn.bh * scale
        }
        dir.r = dir.br * dirScale; dir.hit = dir.bh * dirScale
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = layoutAll(w, h)

    /** Buang perubahan yang belum disimpan. */
    fun reloadLayout() = layoutAll(width, height)

    fun saveLayout() {
        if (width <= 0 || height <= 0) return
        val o = orient(width, height)
        val e = prefs.edit().putFloat("${o}_scale", scale).putFloat("${o}_dirscale", dirScale)
        for (btn in layoutTargets) {
            e.putFloat("${o}_${btn.key}_x", btn.cx / width)
            e.putFloat("${o}_${btn.key}_y", btn.cy / height)
            e.putBoolean("${o}_${btn.key}_off", btn.off)
        }
        e.apply()
    }

    /** Kembali ke tata letak bawaan untuk orientasi saat ini. */
    fun resetLayout() {
        val o = orient(width, height)
        val e = prefs.edit().remove("${o}_scale").remove("${o}_dirscale")
        for (btn in layoutTargets) { e.remove("${o}_${btn.key}_x"); e.remove("${o}_${btn.key}_y"); e.remove("${o}_${btn.key}_off") }
        for (k in DPAD_KEYS) { e.remove("${o}_${k}_x"); e.remove("${o}_${k}_y") }   // sisa tata letak lama
        e.apply()
        layoutAll(width, height)
    }

    /** Ubah ukuran semua tombol (A/B/X/Y, L/R, Start/Select); D-pad/stik tidak ikut berubah. */
    fun changeScale(delta: Float) {
        scale = (scale + delta).coerceIn(0.6f, 1.6f)
        applyScale()
    }

    /** Ubah ukuran D-pad / stik saja; tombol lain tidak ikut berubah. */
    fun changeDirScale(delta: Float) {
        dirScale = (dirScale + delta).coerceIn(0.5f, 2.0f)
        applyScale()
    }

    // ------------------------------------------------------------ gambar

    private fun releaseAll() {
        for (k in pressed) onKey?.invoke(k, false)
        pressed = emptySet()
        comboOn = emptySet()
        if (stickPointer != -1 || stickX != 0f || stickY != 0f) onAnalog?.invoke(0f, 0f)
        stickPointer = -1
        stickX = 0f; stickY = 0f
    }

    /** Dipanggil saat kontrol disembunyikan (gamepad fisik terhubung) supaya tidak ada tombol yang tertahan. */
    fun releaseTouches() { releaseAll(); invalidate() }

    private val padBody = 0xFF5B6272.toInt()          // badan tombol/D-pad (konsol selain SNES)
    private val smallBody = 0xFF444B5A.toInt()        // tombol kecil Select/Start (konsol selain SNES)
    private val snesShoulder = 0xFF9A949C.toInt()     // tombol bahu SNES (abu-abu)
    private val genGray = 0xFF9C9B99.toInt()          // tombol atas X Y Z dan START/MODE pad Genesis asli (abu-abu)
    private val genBlack = 0xFF2C2D31.toInt()         // tombol bawah A B C pad Genesis asli (hitam)
    private val gbaGray = 0xFFA3A6AD.toInt()          // tombol A/B, L/R, Start/Select GBA asli (abu-abu terang)
    private val gbaDpad = 0xFF9A9EA5.toInt()          // D-pad GBA asli (abu-abu terang)
    private val gbaInk = 0xFF4A4E56.toInt()           // huruf pada tombol GBA (abu-abu gelap)
    private val gbaShoulder = 0xFFC9CBD3.toInt()      // bahu L/R GBA asli (abu-abu keputihan)
    private val wedge = Path()
    private val genDpad = 0xFF2A2A2D.toInt()          // D-pad pad Genesis asli (hitam)
    private val arcadeKnob = 0xFFC0392B.toInt()       // bola joystick arcade (merah)
    private val stickKnob = 0xFF6B7385.toInt()        // kenop stik analog
    // Warna tombol panel arcade (mengikuti kabinet Space Invaders): merah, kuning, hijau; KOIN/START putih
    private val arcRed = 0xFFE8362B.toInt()
    private val arcYellow = 0xFFFFB81C.toInt()
    private val arcGreen = 0xFF35D96B.toInt()
    private val arcWhite = 0xFFF4F4F4.toInt()
    private val arcBlue = 0xFF2F80ED.toInt()          // tombol kombo
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowCache = HashMap<String, RadialGradient>()
    // Gradien bodi tombol & joystick disimpan (dibuat di titik 0,0 lalu digeser lewat translate) supaya
    // menggerakkan joystick tidak membuat objek baru tiap frame, yang memberatkan gambar ulang kontrol.
    private val shaderCache = HashMap<String, android.graphics.Shader>()
    private fun cachedShader(key: String, make: () -> android.graphics.Shader): android.graphics.Shader {
        if (shaderCache.size > 96) shaderCache.clear()
        return shaderCache.getOrPut(key, make)
    }
    private var invalidatePending = false
    private val dirtyRect = android.graphics.Rect()
    private val shadowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val crossPath = Path()
    private val rr = RectF()

    private fun darken(color: Int, k: Float): Int {
        val ro = ((color shr 16 and 0xFF) * k).toInt(); val go = ((color shr 8 and 0xFF) * k).toInt(); val bo = ((color and 0xFF) * k).toInt()
        return (0xFF shl 24) or (ro shl 16) or (go shl 8) or bo
    }

    private fun lighten(color: Int, k: Float): Int {
        val ro = color shr 16 and 0xFF; val go = color shr 8 and 0xFF; val bo = color and 0xFF
        val r2 = (ro + (255 - ro) * k).toInt(); val g2 = (go + (255 - go) * k).toInt(); val b2 = (bo + (255 - bo) * k).toInt()
        return (0xFF shl 24) or (r2 shl 16) or (g2 shl 8) or b2
    }

    /** Warna tombol arcade: baris bawah 1 2 3 = merah, kuning, hijau; baris atas 4 5 6 = kuning, hijau, hijau. */
    private fun arcadeBody(btn: Btn): Int = when {
        btn.combo != null -> arcBlue
        btn === b -> arcRed
        btn === a -> arcYellow
        btn === r -> arcGreen
        btn === y -> arcYellow
        btn === x || btn === l -> arcGreen
        else -> arcWhite                      // KOIN dan START
    }

    private fun bodyOf(btn: Btn): Int =
        if (btn.combo != null && genesisLayout) genGray   // kombo Genesis abu-abu seperti tombol X Y Z
        else if (btn.combo != null && !gbaLayout) arcBlue      // kombo GBA tetap abu-abu ala GBA (huruf gelap terbaca)
        else if (arcadeLayout) arcadeBody(btn)
        else if (gbaLayout) gbaGray
        else if (genesisLayout) {
            // Seperti pad 6 tombol asli: X Y Z abu-abu (baris atas), A B C hitam (baris bawah), START/MODE abu-abu
            if (btn === y || btn === l || btn === r || btn === sel || btn === start) genGray else genBlack
        } else if (snesStyle) when {
            btn === x || btn === y -> SNES_LIGHT
            btn === a || btn === b -> SNES_DARK
            btn === l || btn === r -> snesShoulder
            else -> SNES_INK
        } else if (btn === sel || btn === start) smallBody else padBody

    /** Warna huruf: putih di atas tombol berwarna; gelap untuk bahu abu-abu SNES dan tulisan di bawah Select/Start. */
    private fun inkOf(btn: Btn): Int =
        if (arcadeLayout) (if (btn === b || btn.combo != null) 0xFFFFFFFF.toInt() else 0xFF1E1E1E.toInt())
        else if (gbaLayout) gbaInk
        else if (genesisLayout) {
            // Huruf gelap di tombol abu-abu, huruf terang di tombol hitam, tulisan START/MODE putih di bawah pil
            if (btn === sel || btn === start) 0xFFFFFFFF.toInt() else if (btn === y || btn === l || btn === r || btn.combo != null) 0xFF2B2B2B.toInt() else 0xFFC8C8C8.toInt()
        } else if (snesStyle && (btn === l || btn === r || btn === sel || btn === start)) SNES_INK else 0xFFFFFFFF.toInt()

    /**
     * Tombol 3D: bayangan lembut, dinding samping (tebal), permukaan atas bercahaya dari kiri-atas,
     * tepi terang di atas dan gelap di bawah. Saat ditekan permukaan turun dan dinding menipis.
     * Bentuk kapsul bila pillW > 1 (tombol bahu, Select/Start SNES); bisa dimiringkan (tilt).
     */
    private fun drawKey(c: Canvas, btn: Btn, body0: Int, ink: Int, ab: Float, on: Boolean) {
        val rad = btn.r
        val halfW = rad * btn.pillW
        val extent = halfW + rad * 2.6f
        val layer = c.saveLayerAlpha(
            btn.cx - extent, btn.cy - extent, btn.cx + extent, btn.cy + extent,
            (ab * 255).toInt().coerceIn(0, 255)
        )
        val depth = rad * 0.28f
        val push = if (on) depth * 0.7f else 0f
        val body = if (on) darken(body0, 0.88f) else body0
        val below = (snesLayout || genesisLayout) && (btn === sel || btn === start)
        val round = btn.pillW <= 1.01f

        c.save()
        c.translate(btn.cx, btn.cy)
        c.rotate(btn.tilt)

        // Sinar menyala di sekeliling tombol arcade (joystick tidak ikut), makin terang saat ditekan
        if (arcadeLayout) {
            val gr = rad * (if (on) 2.4f else 1.9f)
            val gc = body0 and 0x00FFFFFF
            // Gradien disimpan (tidak dibuat ulang tiap frame) supaya menggerakkan joystick tidak membebani
            // gambar ulang kontrol, yang bisa membuat game tersendat lalu "mengejar" frame (terlihat dipercepat)
            val key = "${gr.toInt()}_${gc}_$on"
            val g = glowCache.getOrPut(key) {
                RadialGradient(
                    0f, 0f, gr,
                    intArrayOf((if (on) 0xF0 else 0xB0) shl 24 or gc, 0x60 shl 24 or gc, gc),
                    floatArrayOf(0.4f, 0.7f, 1f), Shader.TileMode.CLAMP
                )
            }
            if (glowCache.size > 64) glowCache.clear()
            glowP.shader = g
            c.drawCircle(0f, 0f, gr, glowP)
            glowP.shader = null
        }

        // Bayangan jatuh
        shadowP.color = 0xFF000000.toInt()
        for (i in 3 downTo 1) {
            val e = rad * 0.08f * i
            shadowP.alpha = if (on) 14 else 22
            rr.set(-halfW - e, -rad - e + depth + e * 0.6f, halfW + e, rad + e + depth + e * 0.6f)
            c.drawRoundRect(rr, rad + e, rad + e, shadowP)
        }
        // Dinding samping
        bodyP.shader = null
        bodyP.pathEffect = null
        bodyP.color = darken(body, 0.5f)
        rr.set(-halfW, -rad + depth, halfW, rad + depth)
        c.drawRoundRect(rr, rad, rad, bodyP)
        rr.set(-halfW, push, halfW, depth)
        c.drawRect(rr, bodyP)

        // Permukaan atas
        c.save()
        c.translate(0f, push)
        rr.set(-halfW, -rad, halfW, rad)
        bodyP.shader = cachedShader("kf_${round}_${body}_${halfW.toInt()}_${rad.toInt()}") {
            if (round)
                RadialGradient(
                    -halfW * 0.35f, -rad * 0.4f, halfW * 1.5f,
                    intArrayOf(lighten(body, 0.4f), body, darken(body, 0.7f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
            else
                LinearGradient(
                    0f, -rad, 0f, rad,
                    intArrayOf(lighten(body, 0.32f), body, darken(body, 0.78f)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
                )
        }
        c.drawRoundRect(rr, rad, rad, bodyP)
        bodyP.shader = null

        // Tepi: terang di atas, gelap di bawah
        lineP.strokeWidth = rad * 0.08f
        lineP.shader = cachedShader("ke_${rad.toInt()}") {
            LinearGradient(
                0f, -rad, 0f, rad,
                intArrayOf(0xAAFFFFFF.toInt(), 0x00FFFFFF, 0x66000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        rr.inset(rad * 0.05f, rad * 0.05f)
        c.drawRoundRect(rr, rad, rad, lineP)
        lineP.shader = null

        if (round) {
            // Cekungan di tengah dan kilap kecil di kiri-atas
            lineP.color = darken(body, 0.55f); lineP.alpha = 90; lineP.strokeWidth = rad * 0.05f
            c.drawCircle(0f, 0f, rad * 0.68f, lineP)
            shadowP.color = 0xFFFFFFFF.toInt(); shadowP.alpha = 70
            rr.set(-rad * 0.62f, -rad * 0.8f, -rad * 0.02f, -rad * 0.35f)
            c.drawOval(rr, shadowP)
        }

        if (!below && !(gbaLayout && (btn === sel || btn === start))) {
            text.textSize = if (btn.combo != null)
                min(rad * 0.85f, halfW * 1.8f / (btn.label.length.coerceAtLeast(1) * 0.62f))   // "4+5+6" muat di dalam kapsul
            else rad * (if (btn.label.length > 1 && round) 0.55f else 0.95f)
            val ty = text.textSize * 0.35f
            text.color = 0xFF000000.toInt(); text.alpha = 90
            c.drawText(btn.label, 0f, ty + rad * 0.05f, text)
            text.color = ink
            c.drawText(btn.label, 0f, ty, text)
        }
        c.restore()

        if (below) {   // SELECT/START tercetak di bawah tombol, ikut miring, seperti pad aslinya
            text.textSize = rad * 1.05f
            text.color = ink
            c.drawText(btn.label, 0f, rad + depth + text.textSize * 1.05f, text)
        }
        c.restore()
        c.restoreToCount(layer)
    }

    /** Gambar koin emas (BC) untuk tombol KOIN arcade; dimuat sekali dari resource. */
    private val coinBmp: Bitmap? by lazy {
        try { BitmapFactory.decodeResource(resources, R.drawable.koin_button) } catch (e: Exception) { null }
    }
    private val coinP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val coinDst = RectF()

    /** Tombol KOIN arcade berupa gambar koin; saat ditekan mengecil sedikit dan menggelap. */
    private fun drawCoin(c: Canvas, btn: Btn, ab: Float, on: Boolean) {
        val bmp = coinBmp
        if (bmp == null) { drawKey(c, btn, bodyOf(btn), inkOf(btn), ab, on); return }
        val rd = btn.r * 1.2f * (if (on) 0.92f else 1f)
        val extent = btn.r * 2.2f
        val layer = c.saveLayerAlpha(
            btn.cx - extent, btn.cy - extent, btn.cx + extent, btn.cy + extent,
            (ab * 255).toInt().coerceIn(0, 255)
        )
        shadowP.color = 0xFF000000.toInt(); shadowP.alpha = 60
        c.drawCircle(btn.cx, btn.cy + rd * 0.12f, rd, shadowP)
        coinP.colorFilter = if (on) PorterDuffColorFilter(0x55000000, PorterDuff.Mode.SRC_ATOP) else null
        coinDst.set(btn.cx - rd, btn.cy - rd, btn.cx + rd, btn.cy + rd)
        c.drawBitmap(bmp, null, coinDst, coinP)
        coinP.colorFilter = null
        c.restoreToCount(layer)
    }

    /**
     * Bahu L/R GBA asli: baji abu-abu keputihan yang tebal di ujung luar dan menipis ke dalam,
     * ujung dalamnya naik (miring seperti di sudut atas badan GBA). R adalah bayangan cermin L.
     */
    private fun drawGbaShoulder(c: Canvas, btn: Btn, ab: Float, on: Boolean) {
        val rd = btn.r
        val hw = rd * btn.pillW
        val mirror = btn === r
        val body = if (on) darken(gbaShoulder, 0.86f) else gbaShoulder
        val depth = rd * 0.3f
        val push = if (on) depth * 0.7f else 0f
        val extent = hw + rd * 3f
        val layer = c.saveLayerAlpha(
            btn.cx - extent, btn.cy - extent, btn.cx + extent, btn.cy + extent,
            (ab * 255).toInt().coerceIn(0, 255)
        )
        c.save()
        c.translate(btn.cx, btn.cy)
        c.rotate(btn.tilt)
        if (mirror) c.scale(-1f, 1f)
        val corner = CornerPathEffect(rd * 0.5f)

        fun wedgeAt(dy: Float) {
            wedge.reset()
            wedge.moveTo(-hw, -0.55f * rd + dy)
            wedge.lineTo(hw, -0.9f * rd + dy)
            wedge.lineTo(hw, 0.15f * rd + dy)
            wedge.lineTo(-hw, 1.0f * rd + dy)
            wedge.close()
        }

        bodyP.pathEffect = corner
        bodyP.shader = null
        // Bayangan jatuh
        bodyP.color = 0xFF000000.toInt(); bodyP.alpha = 40
        wedgeAt(depth + rd * 0.18f)
        c.drawPath(wedge, bodyP)
        // Dinding samping
        for (i in 3 downTo 1) {
            wedgeAt(push + (depth - push) * i / 3f)
            bodyP.color = darken(body, 0.55f)
            c.drawPath(wedge, bodyP)
        }
        // Permukaan atas
        wedgeAt(push)
        bodyP.shader = cachedShader("gs_${rd.toInt()}_$body") {
            LinearGradient(
                0f, -0.9f * rd, 0f, 1.0f * rd,
                intArrayOf(lighten(body, 0.35f), body, darken(body, 0.78f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawPath(wedge, bodyP)
        bodyP.shader = null
        // Tepi terang di atas, gelap di bawah
        lineP.pathEffect = corner
        lineP.strokeWidth = rd * 0.07f
        lineP.shader = cachedShader("ge_${rd.toInt()}") {
            LinearGradient(
                0f, -0.9f * rd, 0f, 1.0f * rd,
                intArrayOf(0xAAFFFFFF.toInt(), 0x00FFFFFF, 0x55000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawPath(wedge, lineP)
        lineP.shader = null
        lineP.pathEffect = null
        bodyP.pathEffect = null
        c.restore()

        // Huruf kecil di ujung luar, digambar tanpa cermin supaya R tidak terbalik
        c.save()
        c.translate(btn.cx, btn.cy)
        c.rotate(btn.tilt)
        text.textSize = rd * 0.8f
        val lx = (if (mirror) 1f else -1f) * hw * 0.55f
        val ty = text.textSize * 0.35f + rd * 0.09f + push
        text.color = 0xFFFFFFFF.toInt(); text.alpha = 110
        c.drawText(btn.label, lx, ty + rd * 0.06f, text)
        text.color = gbaInk
        c.drawText(btn.label, lx, ty, text)
        c.restore()
        c.restoreToCount(layer)
    }

    /**
     * Start/Select GBA asli: tombol bulat abu-abu kecil dengan pelat cekung miring di sebelah kirinya;
     * tulisan START/SELECT miring (italik) di atas pelat.
     */
    private fun drawGbaSmall(c: Canvas, btn: Btn, ab: Float, on: Boolean) {
        val rd = btn.r
        val extent = rd * 7f
        val layer = c.saveLayerAlpha(
            btn.cx - extent, btn.cy - extent, btn.cx + extent, btn.cy + extent,
            (ab * 255).toInt().coerceIn(0, 255)
        )
        // Pelat: kapsul miring (turun ke kanan) dan condong seperti huruf italik
        c.save()
        c.translate(btn.cx - rd * 3.3f, btn.cy - rd * 0.25f)
        c.rotate(10f)
        c.skew(-0.2f, 0f)
        val len = rd * 4.4f
        val hh = rd * 0.85f
        rr.set(-len / 2f, -hh, len / 2f, hh)
        bodyP.shader = null
        bodyP.pathEffect = null
        bodyP.color = 0xFF000000.toInt(); bodyP.alpha = 70
        c.drawRoundRect(rr, hh, hh, bodyP)
        // Tepi timbul: gelap di bawah, terang di atas
        lineP.shader = null
        lineP.strokeWidth = rd * 0.1f
        lineP.color = 0xFF000000.toInt(); lineP.alpha = 110
        rr.offset(0f, rd * 0.07f)
        c.drawRoundRect(rr, hh, hh, lineP)
        rr.offset(0f, -rd * 0.07f)
        lineP.color = 0xFFFFFFFF.toInt(); lineP.alpha = 170
        c.drawRoundRect(rr, hh, hh, lineP)
        // Tulisan
        text.textSize = rd * 0.78f
        text.isFakeBoldText = true
        val ty = text.textSize * 0.35f
        text.color = 0xFF000000.toInt(); text.alpha = 120
        c.drawText(btn.label, 0f, ty + rd * 0.06f, text)
        text.color = 0xFFDCDDE4.toInt()
        c.drawText(btn.label, 0f, ty, text)
        text.isFakeBoldText = false
        c.restore()
        // Tombol bulatnya (tanpa huruf di dalam, lihat drawKey)
        drawKey(c, btn, gbaGray, gbaInk, 1f, on)
        c.restoreToCount(layer)
    }

    override fun onDraw(c: Canvas) {
        val base = (if (editMode) max(opacity, 60) else opacity).coerceIn(10, 100) / 100f
        for (btn in buttons) {
            if (customCombo && btn.combo == null && btn in comboButtons) {   // slot kombo kosong: hanya muncul saat mengatur
                if (editMode) drawEmptyCombo(c, btn, base)
                continue
            }
            if (btn.off && !editMode) continue          // tombol nonaktif disembunyikan saat bermain
            val ab = if (btn.off) base * 0.3f else base  // saat mengatur: tampil redup + dicoret
            val on = if (btn.combo != null) (btn in comboOn || btn === dragging) else (btn.key in pressed || btn === dragging)
            if (arcadeLayout && btn === sel) drawCoin(c, btn, ab, on)
            else if (gbaLayout && (btn === l || btn === r)) drawGbaShoulder(c, btn, ab, on)
            else if (gbaLayout && (btn === sel || btn === start)) drawGbaSmall(c, btn, ab, on)
            else drawKey(c, btn, bodyOf(btn), inkOf(btn), ab, on)
            if (btn.off) strike(c, btn)
        }
        if (!dir.off || editMode) {
            val db = if (dir.off) base * 0.3f else base
            if (stickMode) drawStick(c, db) else drawDpad(c, db)
            if (dir.off) strike(c, dir)
        }
    }

    private val dashP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }

    /** Slot kombo kosong (hanya mode atur): kapsul putus-putus bertuliskan "+ Kombo"; ketuk untuk mengisinya. */
    private fun drawEmptyCombo(c: Canvas, btn: Btn, ab: Float) {
        val halfW = btn.r * btn.pillW
        val a255 = (ab * 255).toInt().coerceIn(0, 255)
        dashP.color = 0xFFFFFFFF.toInt(); dashP.alpha = a255
        rect.set(btn.cx - halfW, btn.cy - btn.r, btn.cx + halfW, btn.cy + btn.r)
        c.drawRoundRect(rect, btn.r, btn.r, dashP)
        text.textSize = btn.r * 0.6f
        text.color = 0xFFFFFFFF.toInt(); text.alpha = a255
        c.drawText("+ Kombo", btn.cx, btn.cy + text.textSize * 0.35f, text)
    }

    /** Coretan diagonal penanda tombol nonaktif (hanya terlihat di mode atur tata letak). */
    private fun strike(c: Canvas, btn: Btn) {
        val d = btn.r * 0.7f
        stroke.color = if (snesStyle) SNES_INK else 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 5f
        stroke.alpha = 230
        c.drawLine(btn.cx - d, btn.cy - d, btn.cx + d, btn.cy + d, stroke)
    }

    /** Bola joystick/stik 3D di dalam sumur cekung; bola mengikuti jari dan turun sedikit saat disentuh. */
    private fun drawStick(c: Canvas, ab: Float) {
        val on = stickPointer != -1 || dir === dragging
        val rad = dir.r
        val cx = dir.cx; val cy = dir.cy
        val extent = rad * 1.6f
        val layer = c.saveLayerAlpha(cx - extent, cy - extent, cx + extent, cy + extent, (ab * 255).toInt().coerceIn(0, 255))

        // Sumur cekung
        bodyP.pathEffect = null
        c.save()
        c.translate(cx, cy)
        bodyP.shader = cachedShader("sw_${rad.toInt()}") {
            RadialGradient(
                0f, 0f, rad,
                intArrayOf(0xFF1B1F27.toInt(), 0xFF2A303B.toInt(), 0xFF4B5262.toInt()), floatArrayOf(0f, 0.78f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawCircle(0f, 0f, rad, bodyP)
        bodyP.shader = null
        lineP.strokeWidth = rad * 0.05f
        lineP.shader = cachedShader("sl_${rad.toInt()}") {
            LinearGradient(
                0f, -rad, 0f, rad,
                intArrayOf(0x66000000, 0x00000000, 0x55FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawCircle(0f, 0f, rad * 0.97f, lineP)
        lineP.shader = null
        c.restore()

        // Penanda 4 arah
        text.color = 0xFF9AA3B5.toInt(); text.alpha = 140
        text.textSize = rad * 0.28f
        val ty = text.textSize * 0.35f
        c.drawText("▲", cx, cy - rad * 0.72f + ty, text)
        c.drawText("▼", cx, cy + rad * 0.72f + ty, text)
        c.drawText("◀", cx - rad * 0.72f, cy + ty, text)
        c.drawText("▶", cx + rad * 0.72f, cy + ty, text)

        // Kenop
        val knob = if (arcadeLayout) arcadeKnob else stickKnob
        val kr = rad * 0.44f
        val kx = cx + stickX * (rad - kr * 0.4f)
        val ky = cy + stickY * (rad - kr * 0.4f)
        val lift = if (on) kr * 0.12f else kr * 0.3f
        shadowP.color = 0xFF000000.toInt(); shadowP.alpha = 70
        c.drawCircle(kx + kr * 0.08f, ky + lift + kr * 0.12f, kr * 1.02f, shadowP)
        bodyP.color = darken(knob, 0.5f)
        c.drawCircle(kx, ky + lift, kr, bodyP)
        c.save()
        c.translate(kx, ky)
        bodyP.shader = cachedShader("sk_${knob}_${kr.toInt()}") {
            RadialGradient(
                -kr * 0.35f, -kr * 0.4f, kr * 1.5f,
                intArrayOf(lighten(knob, 0.55f), knob, darken(knob, 0.6f)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawCircle(0f, 0f, kr, bodyP)
        bodyP.shader = null
        c.restore()
        shadowP.color = 0xFFFFFFFF.toInt(); shadowP.alpha = 90
        rr.set(kx - kr * 0.6f, ky - kr * 0.8f, kx - kr * 0.05f, ky - kr * 0.35f)
        c.drawOval(rr, shadowP)
        c.restoreToCount(layer)
    }

    /** Lintasan salib D-pad berpusat di (0, dy). */
    private fun buildCross(len: Float, arm: Float, dy: Float) {
        crossPath.reset()
        crossPath.moveTo(-arm, -len + dy); crossPath.lineTo(arm, -len + dy); crossPath.lineTo(arm, -arm + dy)
        crossPath.lineTo(len, -arm + dy); crossPath.lineTo(len, arm + dy); crossPath.lineTo(arm, arm + dy)
        crossPath.lineTo(arm, len + dy); crossPath.lineTo(-arm, len + dy); crossPath.lineTo(-arm, arm + dy)
        crossPath.lineTo(-len, arm + dy); crossPath.lineTo(-len, -arm + dy); crossPath.lineTo(-arm, -arm + dy)
        crossPath.close()
    }

    /** D-pad salib 3D: tebal dengan dinding samping, cekungan di tengah, lengan yang ditekan menggelap dan salib sedikit turun. */
    private fun drawDpad(c: Canvas, ab: Float) {
        val len = dir.r
        val arm = len * 0.34f
        val cx = dir.cx; val cy = dir.cy
        val any = dir === dragging || DPAD_KEYS.any { it in pressed }
        val depth = arm * 0.55f
        val push = if (any) depth * 0.5f else 0f
        val body = if (snesStyle) SNES_INK else if (genesisLayout) genDpad else if (gbaLayout) gbaDpad else padBody
        val extent = len * 1.7f
        val layer = c.saveLayerAlpha(cx - extent, cy - extent, cx + extent, cy + extent, (ab * 255).toInt().coerceIn(0, 255))
        c.save()
        c.translate(cx, cy)
        val corner = CornerPathEffect(arm * 0.4f)
        bodyP.pathEffect = corner
        bodyP.shader = null

        // Bayangan jatuh
        bodyP.color = 0xFF000000.toInt()
        for (i in 2 downTo 1) {
            buildCross(len + i * arm * 0.08f, arm + i * arm * 0.08f, depth + i * arm * 0.12f)
            bodyP.alpha = 24
            c.drawPath(crossPath, bodyP)
        }
        // Dinding samping: salib digeser bertahap ke bawah
        val steps = 4
        for (i in steps downTo 1) {
            buildCross(len, arm, push + (depth - push) * i / steps)
            bodyP.color = darken(body, 0.5f)
            c.drawPath(crossPath, bodyP)
        }
        // Permukaan atas
        buildCross(len, arm, push)
        bodyP.shader = LinearGradient(
            -len, -len + push, len, len + push,
            intArrayOf(lighten(body, 0.3f), body, darken(body, 0.75f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(crossPath, bodyP)
        bodyP.shader = null
        lineP.pathEffect = corner
        lineP.strokeWidth = arm * 0.08f
        lineP.shader = LinearGradient(
            0f, -len, 0f, len,
            intArrayOf(0xAAFFFFFF.toInt(), 0x00FFFFFF, 0x66000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(crossPath, lineP)
        lineP.shader = null
        lineP.pathEffect = null
        bodyP.pathEffect = null

        // Lengan yang ditekan menggelap
        if (any) {
            bodyP.color = 0xFF000000.toInt(); bodyP.alpha = 70
            c.save()
            c.translate(0f, push)
            val rc = arm * 0.3f
            if (KeyEvent.KEYCODE_DPAD_UP in pressed) { rr.set(-arm, -len, arm, -arm * 0.2f); c.drawRoundRect(rr, rc, rc, bodyP) }
            if (KeyEvent.KEYCODE_DPAD_DOWN in pressed) { rr.set(-arm, arm * 0.2f, arm, len); c.drawRoundRect(rr, rc, rc, bodyP) }
            if (KeyEvent.KEYCODE_DPAD_LEFT in pressed) { rr.set(-len, -arm, -arm * 0.2f, arm); c.drawRoundRect(rr, rc, rc, bodyP) }
            if (KeyEvent.KEYCODE_DPAD_RIGHT in pressed) { rr.set(arm * 0.2f, -arm, len, arm); c.drawRoundRect(rr, rc, rc, bodyP) }
            c.restore()
        }

        // Cekungan di tengah
        bodyP.shader = RadialGradient(
            0f, push, arm * 0.9f,
            intArrayOf(darken(body, 0.55f), body), null, Shader.TileMode.CLAMP
        )
        c.drawCircle(0f, push, arm * 0.9f, bodyP)
        bodyP.shader = null

        // Segitiga arah timbul (D-pad SNES asli polos, jadi tidak digambar di SNES)
        if (!snesStyle) {
            val t = arm * 0.5f
            val d = len - arm * 0.9f
            bodyP.color = if (gbaLayout) darken(body, 0.7f) else lighten(body, 0.6f); bodyP.alpha = 210
            fun arrow(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
                tri.reset(); tri.moveTo(x1, y1 + push); tri.lineTo(x2, y2 + push); tri.lineTo(x3, y3 + push); tri.close()
                c.drawPath(tri, bodyP)
            }
            arrow(0f, -d - t * 0.5f, -t, -d + t * 0.6f, t, -d + t * 0.6f)
            arrow(0f, d + t * 0.5f, -t, d - t * 0.6f, t, d - t * 0.6f)
            arrow(-d - t * 0.5f, 0f, -d + t * 0.6f, -t, -d + t * 0.6f, t)
            arrow(d + t * 0.5f, 0f, d - t * 0.6f, -t, d - t * 0.6f, t)
        }
        c.restore()
        c.restoreToCount(layer)
    }

    // ------------------------------------------------------------ sentuhan

    /**
     * Ubah vektor (dx, dy) menjadi arah digital 8 arah.
     * Sudut dibagi rata: tiap arah lurus dan tiap arah serong mendapat sektor 45°.
     */
    private fun dirKeys(dx: Float, dy: Float, out: MutableSet<Int>) {
        val ax = abs(dx); val ay = abs(dy)
        val diagonal = ay >= ax * DIAG_RATIO && ax >= ay * DIAG_RATIO
        val horiz = diagonal || ay < ax * DIAG_RATIO      // kiri/kanan (lurus atau serong)
        val vert = diagonal || ax < ay * DIAG_RATIO       // atas/bawah (lurus atau serong)
        if (horiz) out.add(if (dx < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        if (vert) out.add(if (dy < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editMode) return handleEdit(e)

        val now = HashSet<Int>()
        val touchedCombos = HashSet<Btn>()
        var stickChanged = false
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1

        // Stik analog: kunci ke satu jari sejak menyentuh area stik sampai dilepas
        if (stickMode && !dir.off) {
            if (ending) stickPointer = -1
            if (stickPointer != -1) {
                val idx = e.findPointerIndex(stickPointer)
                if (idx < 0 || idx == skip) stickPointer = -1
            }
            if (stickPointer == -1 && !ending &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_POINTER_DOWN)
            ) {
                val i = e.actionIndex
                if (hypot(e.getX(i) - dir.cx, e.getY(i) - dir.cy) <= dir.hit) stickPointer = e.getPointerId(i)
            }
            var sx = 0f; var sy = 0f
            if (stickPointer != -1) {
                val i = e.findPointerIndex(stickPointer)
                var vx = (e.getX(i) - dir.cx) / dir.r
                var vy = (e.getY(i) - dir.cy) / dir.r
                val m = hypot(vx, vy)
                if (m > 1f) { vx /= m; vy /= m }
                sx = vx; sy = vy
                if (hypot(sx, sy) >= STICK_DEAD) dirKeys(sx, sy, now)
            }
            if (sx != stickX || sy != stickY) {
                stickChanged = true
                stickX = sx; stickY = sy
                if (!arcadeLayout) onAnalog?.invoke(sx, sy)     // joystick arcade murni digital
            }
        }

        if (!ending) {
            for (i in 0 until e.pointerCount) {
                if (i == skip || e.getPointerId(i) == stickPointer) continue
                val px = e.getX(i); val py = e.getY(i)
                for (btn in liveButtons) {
                    if (!btn.touches(px, py, btn.hit)) continue
                    val keys = btn.combo
                    if (keys != null) { for (k in keys) now.add(k); touchedCombos.add(btn) }   // kombo: semua tombol sekaligus
                    else now.add(btn.key)
                }
                if (!stickMode && !dir.off) {
                    val dx = px - dir.cx; val dy = py - dir.cy
                    val dist = hypot(dx, dy)
                    if (dist <= dir.hit && dist >= dir.r * DPAD_DEAD) dirKeys(dx, dy, now)
                }
            }
        }
        val added = now - pressed
        for (k in pressed - now) onKey?.invoke(k, false)
        for (k in added) onKey?.invoke(k, true)
        // Getar hanya untuk tombol aksi; arah joystick tidak getar tiap berganti arah (membebani & mengganggu)
        val buzz = added.any { !(stickMode && it in DIR_KEYS) }
        if (buzz && haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        val keysChanged = added.isNotEmpty() || (pressed.size != now.size) || pressed != now || comboOn != touchedCombos
        pressed = now
        comboOn = touchedCombos
        if (keysChanged) invalidate()
        else if (stickChanged) invalidateStick()          // hanya area joystick, maksimal sekali per frame
        return true
    }

    /** Gambar ulang area joystick saja, digabung jadi satu kali per frame layar (bukan tiap event sentuh). */
    private fun invalidateStick() {
        if (invalidatePending) return
        invalidatePending = true
        val pad = (dir.r * 0.6f).toInt()
        val e = (dir.r * 1.6f).toInt() + pad
        dirtyRect.set((dir.cx - e).toInt(), (dir.cy - e).toInt(), (dir.cx + e).toInt(), (dir.cy + e).toInt())
        postOnAnimation {
            invalidatePending = false
            invalidate(dirtyRect)
        }
    }

    private var downX = 0f
    private var downY = 0f
    private var movedFar = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    /** Seret = pindahkan tombol; ketuk sekali (tanpa menyeret) = nonaktifkan / aktifkan kembali tombol itu. */
    private fun handleEdit(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; movedFar = false
                dragging = all
                    .filter { it.touches(e.x, e.y, it.r * 1.3f) }
                    .minByOrNull { hypot(e.x - it.cx, e.y - it.cy) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!movedFar && hypot(e.x - downX, e.y - downY) > slop) movedFar = true
                if (movedFar) dragging?.let {
                    val mx = it.r * it.pillW
                    it.cx = e.x.coerceIn(mx, max(mx, width - mx))
                    it.cy = e.y.coerceIn(it.r, max(it.r, height - it.r))
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!movedFar) dragging?.let {
                    // Kombo: ketuk = pilih tombol yang digabung (bukan nonaktifkan)
                    if (customCombo && it in comboButtons) onComboEdit?.invoke(comboButtons.indexOf(it))
                    else it.off = !it.off
                }
                dragging = null
            }
            MotionEvent.ACTION_CANCEL -> dragging = null
        }
        invalidate()
        return true
    }
}
