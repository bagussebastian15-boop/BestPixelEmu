package com.allinone.emulator.data

import android.content.Context
import com.swordfish.libretrodroid.ShaderConfig

class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var fastForward: Int
        get() = p.getInt("ff", 2)
        set(v) = p.edit().putInt("ff", v).apply()

    /** Hanya diterapkan pada core yang punya opsi frameskip (saat ini mGBA). */
    var frameSkip: Int
        get() = p.getInt("frameskip", 0)
        set(v) = p.edit().putInt("frameskip", v).apply()

    var skipDuplicateFrames: Boolean
        get() = p.getBoolean("skipdup", false)
        set(v) = p.edit().putBoolean("skipdup", v).apply()

    var padOpacity: Int
        get() = p.getInt("padopacity", 60)
        set(v) = p.edit().putInt("padopacity", v).apply()

    /** Kontrol arah di layar: false = D-pad 8 arah (termasuk serong), true = stik analog. */
    var analogPad: Boolean
        get() = p.getBoolean("analogpad", false)
        set(v) = p.edit().putBoolean("analogpad", v).apply()

    var autoHidePad: Boolean
        get() = p.getBoolean("autohide", true)
        set(v) = p.edit().putBoolean("autohide", v).apply()

    var haptics: Boolean
        get() = p.getBoolean("haptics", true)
        set(v) = p.edit().putBoolean("haptics", v).apply()

    /** Bahasa teks game untuk terjemahan: auto, en, latin, ja, zh, ko. */
    var translateSource: String
        get() = p.getString("tr_src", "auto") ?: "auto"
        set(v) = p.edit().putString("tr_src", v).apply()

    /** true = hanya baca 45% layar bagian bawah (tempat kotak dialog biasanya berada). */
    var translateBottomOnly: Boolean
        get() = p.getBoolean("tr_bottom", false)
        set(v) = p.edit().putBoolean("tr_bottom", v).apply()

    /** Mesin terjemahan: 0 = ML Kit offline, 1 = Gemini online (teks saja), 2 = Gemini online (teks + gambar layar, paling akurat). */
    var translateEngine: Int
        get() = p.getInt("tr_engine", 0)
        set(v) = p.edit().putInt("tr_engine", v).apply()

    /** Ragam bahasa Inggris teks game: auto, us (Amerika), uk (Britania). Dipakai mesin online agar tata bahasa/slang tepat. */
    var englishVariant: String
        get() = p.getString("tr_dialect", "auto") ?: "auto"
        set(v) = p.edit().putString("tr_dialect", v).apply()

    var geminiKey: String
        get() = p.getString("gem_key", "") ?: ""
        set(v) = p.edit().putString("gem_key", v.trim()).apply()

    var geminiModel: String
        get() = p.getString("gem_model", "gemini-flash-latest") ?: "gemini-flash-latest"
        set(v) = p.edit().putString("gem_model", v.trim().ifEmpty { "gemini-flash-latest" }).apply()

    /** Satu-satunya filter: bilinear halus (selalu aktif). */
    fun shaderConfig(): ShaderConfig = ShaderConfig.Default
}
