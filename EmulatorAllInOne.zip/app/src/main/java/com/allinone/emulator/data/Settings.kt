package com.allinone.emulator.data

import android.content.Context
import com.allinone.emulator.translate.TranslationEngine
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.Variable

class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var fastForward: Int
        get() = p.getInt("ff", 2)
        set(v) = p.edit().putInt("ff", v).apply()

    /** Hanya diterapkan pada core yang punya opsi frameskip (saat ini mGBA). */
    var frameSkip: Int
        get() = p.getInt("frameskip", 0)
        set(v) = p.edit().putInt("frameskip", v).apply()

    /** Profil performa game arcade: 0 = standar core (bawaan), 1 = seimbang, 2 = ringan, 3 = maksimal. */
    var arcadePerf: Int
        get() = p.getInt("arcadeperf", 0)
        set(v) = p.edit().putInt("arcadeperf", v).apply()

    /** Kecepatan CPU emulasi arcade (%). Di atas 100 = kurangi slowdown bawaan game, tapi lebih berat. */
    var arcadeCpu: Int
        get() = p.getInt("arcadecpu", 100)
        set(v) = p.edit().putInt("arcadecpu", v).apply()

    /**
     * Mode buffer audio: false = stabil (buffer longgar, suara mulus tapi sedikit terlambat; bawaan),
     * true = latensi rendah (suara cepat sinkron, tapi mudah kresek bila perangkat/emulasi sedang berat).
     * Berlaku saat game dimulai.
     */
    var lowLatencyAudio: Boolean
        get() = p.getBoolean("lowlatencyaudio", false)
        set(v) = p.edit().putBoolean("lowlatencyaudio", v).apply()

    var skipDuplicateFrames: Boolean
        get() = p.getBoolean("skipdup", false)
        set(v) = p.edit().putBoolean("skipdup", v).apply()

    /**
     * Kunci layar ke 60 Hz saat bermain. Game berjalan ±57-60 fps; di layar 90/120 Hz LibretroDroid memakai pengatur waktu
     * sendiri (bukan vsync) sehingga durasi tiap frame tidak rata (patah-patah) walau FPS terbaca stabil.
     * Berlaku saat game dimulai.
     */
    var lock60Hz: Boolean
        get() = p.getBoolean("lock60hz", true)
        set(v) = p.edit().putBoolean("lock60hz", v).apply()

    /** Penghitung FPS di pojok layar game (diagnostik performa). */
    var showFps: Boolean
        get() = p.getBoolean("showfps", false)
        set(v) = p.edit().putBoolean("showfps", v).apply()

    var padOpacity: Int
        get() = p.getInt("padopacity", 60)
        set(v) = p.edit().putInt("padopacity", v).apply()

    /** Kontrol arah di layar: false = D-pad 8 arah (termasuk serong), true = stik analog. */
    var analogPad: Boolean
        get() = p.getBoolean("analogpad", false)
        set(v) = p.edit().putBoolean("analogpad", v).apply()

    var autoHidePad: Boolean
        get() = p.getBoolean("autohide", true)
        set(v) = p.edit().putBoolean("autohide", v).apply()

    /** Saat gamepad fisik terhubung: gambar game memenuhi seluruh layar (tanpa latar, logo, dan tombol layar). */
    var stretchWithPad: Boolean
        get() = p.getBoolean("stretchpad", true)
        set(v) = p.edit().putBoolean("stretchpad", v).apply()

    /**
     * Isi 2 tombol kombo panel arcade, token dipisah "+", mis. "A+B+C" (tiga serangan atas) atau "X+Y+Z" (tiga tombol bawah).
     * Bawaan KOSONG: tombol kombo tidak tampil saat bermain. Pengguna membuatnya lewat mode atur tata letak
     * (ketuk slot "+ Kombo"), memilih tombol apa saja.
     */
    var arcadeCombo1: String
        get() = p.getString("arcadecombo1", "") ?: ""
        set(v) = p.edit().putString("arcadecombo1", v).apply()

    var arcadeCombo2: String
        get() = p.getString("arcadecombo2", "") ?: ""
        set(v) = p.edit().putString("arcadecombo2", v).apply()

    /**
     * Isi 2 tombol kombo pad SNES, token dipisah "+", mis. "A+B". Bawaan KOSONG: tombol kombo tidak tampil
     * saat bermain. Pengguna membuatnya lewat mode atur tata letak (ketuk slot "+ Kombo").
     */
    var snesCombo1: String
        get() = p.getString("snescombo1", "") ?: ""
        set(v) = p.edit().putString("snescombo1", v).apply()

    var snesCombo2: String
        get() = p.getString("snescombo2", "") ?: ""
        set(v) = p.edit().putString("snescombo2", v).apply()

    /**
     * Isi 2 tombol kombo pad GBA, token dipisah "+", mis. "A+B" atau "L+R". Bawaan KOSONG: tombol kombo tidak tampil
     * saat bermain. Pengguna membuatnya lewat mode atur tata letak (ketuk slot "+ Kombo"), memilih tombol apa saja.
     */
    var gbaCombo1: String
        get() = p.getString("gbacombo1", "") ?: ""
        set(v) = p.edit().putString("gbacombo1", v).apply()

    var gbaCombo2: String
        get() = p.getString("gbacombo2", "") ?: ""
        set(v) = p.edit().putString("gbacombo2", v).apply()

    /**
     * Isi 2 tombol kombo pad Genesis / Mega Drive, token dipisah "+", mis. "A+B+C" atau "X+Y+Z". Bawaan KOSONG: tombol kombo
     * tidak tampil saat bermain. Pengguna membuatnya lewat mode atur tata letak (ketuk slot "+ Kombo"), memilih tombol apa saja.
     */
    var genesisCombo1: String
        get() = p.getString("genesiscombo1", "") ?: ""
        set(v) = p.edit().putString("genesiscombo1", v).apply()

    var genesisCombo2: String
        get() = p.getString("genesiscombo2", "") ?: ""
        set(v) = p.edit().putString("genesiscombo2", v).apply()

    var haptics: Boolean
        get() = p.getBoolean("haptics", true)
        set(v) = p.edit().putBoolean("haptics", v).apply()

    /** Bahasa teks game untuk terjemahan: auto, en, latin, ja, zh, ko. */
    var translateSource: String
        get() = p.getString("tr_src", "auto") ?: "auto"
        set(v) = p.edit().putString("tr_src", v).apply()

    /** Jenis teks yang diterjemahkan: 0 = dialog (bawaan), 1 = menu awal game (tiap tulisan terpisah). Dua mode terpisah. */
    var translateKind: Int
        get() = p.getInt("tr_kind", 0)
        set(v) = p.edit().putInt("tr_kind", v).apply()

    /** Mode terjemahan: false = game dijeda selama terjemahan tampil (bawaan), true = game tetap berjalan (tanpa jeda). */
    var translateLive: Boolean
        get() = p.getBoolean("tr_live", false)
        set(v) = p.edit().putBoolean("tr_live", v).apply()

    /** Live translate (khusus dialog): true = ketuk logo terjemahan memulai/menghentikan terjemahan otomatis berkelanjutan. */
    var translateAuto: Boolean
        get() = p.getBoolean("tr_auto", false)
        set(v) = p.edit().putBoolean("tr_auto", v).apply()

    /** Mesin terjemahan: true = online (Google Translate / Groq), false = offline saja (ML Kit, bawaan). Keduanya terpisah, tanpa cadangan silang. */
    var translateOnline: Boolean
        get() = p.getBoolean("tr_online", false)
        set(v) = p.edit().putBoolean("tr_online", v).apply()

    /** Mesin untuk mode online: 0 = Google Translate (bawaan), 1 = Groq (LLM, butuh API key sendiri). */
    var onlineEngine: Int
        get() = p.getInt("tr_online_engine", 0)
        set(v) = p.edit().putInt("tr_online_engine", v).apply()

    /** API key Groq (dari console.groq.com). Disimpan lokal di perangkat; hanya dikirim ke api.groq.com. */
    var groqKey: String
        get() = p.getString("tr_groq_key", "") ?: ""
        set(v) = p.edit().putString("tr_groq_key", v.trim()).apply()

    /** Nama model Groq yang dipakai untuk terjemahan. */
    var groqModel: String
        get() = (p.getString("tr_groq_model", null) ?: "").let { if (it.isEmpty() || it in TranslationEngine.GROQ_RETIRED_MODELS) TranslationEngine.GROQ_DEFAULT_MODEL else it }
        set(v) = p.edit().putString("tr_groq_model", v.trim().ifEmpty { TranslationEngine.GROQ_DEFAULT_MODEL }).apply()

    /** Batas ukuran huruf terjemahan (dp) agar selalu terbaca: tidak lebih kecil dari min, tidak lebih besar dari max. */
    var translateFontMin: Int
        get() = p.getInt("tr_fmin", 10)
        set(v) = p.edit().putInt("tr_fmin", v).apply()
    var translateFontMax: Int
        get() = p.getInt("tr_fmax2", 16)      // kunci baru: bawaan 16 dp berlaku juga untuk yang pernah memakai bawaan lama (28)
        set(v) = p.edit().putInt("tr_fmax2", v).apply()

    /** true = hanya baca 45% layar bagian bawah (tempat kotak dialog biasanya berada). */
    var translateBottomOnly: Boolean
        get() = p.getBoolean("tr_bottom", false)
        set(v) = p.edit().putBoolean("tr_bottom", v).apply()

    /**
     * Filter gambar game: 0 = halus (bilinear, bawaan), 1 = tajam (shader Sharp: tepi piksel tegas, cocok untuk
     * font piksel dan OCR terjemahan). Langsung berlaku saat diganti.
     */
    var shaderMode: Int
        get() = p.getInt("shadermode", 0)
        set(v) = p.edit().putInt("shadermode", v).apply()

    /** Mode 2 = composite. SNES/Genesis memakai filter NTSC composite bawaan core (shader tetap bersih); konsol lain memakai CRT lembut. */
    fun shaderConfig(console: Console? = null): ShaderConfig = when (shaderMode) {
        1 -> ShaderConfig.Sharp
        2 -> if (console != null && hasCoreComposite(console)) ShaderConfig.Default else ShaderConfig.CRT
        else -> ShaderConfig.Default
    }

    private fun hasCoreComposite(c: Console) = c == Console.SNES || c == Console.GENESIS

    /**
     * Opsi core filter NTSC composite (hanya SNES dan Genesis yang punya). Selalu dikirim (composite / disabled)
     * agar berpindah dari atau ke mode composite langsung berlaku.
     */
    fun compositeVariables(console: Console): List<Variable> {
        val v = if (shaderMode == 2) "composite" else "disabled"
        return when (console) {
            Console.SNES -> listOf(Variable("snes9x_blargg", v))
            Console.GENESIS -> listOf(Variable("genesis_plus_gx_blargg_ntsc_filter", v))
            else -> emptyList()
        }
    }
}
