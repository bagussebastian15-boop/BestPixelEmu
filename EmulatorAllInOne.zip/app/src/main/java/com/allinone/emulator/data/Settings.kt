package com.allinone.emulator.data

import android.content.Context
import com.swordfish.libretrodroid.ShaderConfig

class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var fastForward: Int
        get() = p.getInt("ff", 2)
        set(v) = p.edit().putInt("ff", v).apply()

    /** Hanya diterapkan pada core yang punya opsi frameskip (saat ini mGBA). */
    var frameSkip: Int
        get() = p.getInt("frameskip", 0)
        set(v) = p.edit().putInt("frameskip", v).apply()

    var skipDuplicateFrames: Boolean
        get() = p.getBoolean("skipdup", false)
        set(v) = p.edit().putBoolean("skipdup", v).apply()

    var padOpacity: Int
        get() = p.getInt("padopacity", 60)
        set(v) = p.edit().putInt("padopacity", v).apply()

    var autoHidePad: Boolean
        get() = p.getBoolean("autohide", true)
        set(v) = p.edit().putBoolean("autohide", v).apply()

    var haptics: Boolean
        get() = p.getBoolean("haptics", true)
        set(v) = p.edit().putBoolean("haptics", v).apply()

    /** Satu-satunya filter: bilinear halus (selalu aktif). */
    fun shaderConfig(): ShaderConfig = ShaderConfig.Default
}
