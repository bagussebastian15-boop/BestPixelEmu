package com.allinone.emulator.translate

import kotlin.math.max

/**
 * Penyaring teks acak/rusak. OCR pada font retro atau frame yang sedang bertransisi kadang menghasilkan
 * huruf tak bermakna, dan penerjemah offline lalu "mengarang" kalimat aneh dari situ. Skor 0..1:
 * makin tinggi makin mirip bahasa manusia. Dipakai untuk memilih hasil OCR terbaik dan menolak terjemahan rusak.
 */
object TextQuality {

    private val COMMON_EN = (
        "the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an " +
        "will my one all would there their what so up out if about who get which go me when make can like time no just him know " +
        "take people into year your good some could them see other than then now look only come its over think also back after " +
        "use two how our work first well way even new want because any these give day most us is are was were am been has had " +
        "did does done let lets don't dont can't cant won't wont i'm im i'll ill it's its that's thats you're youre we're were " +
        "relax waste time hey hello yes okay ok please sorry thanks thank here there where why who whom go going gonna wanna " +
        "kill die dead life world city boss man woman kid kids help run stop wait look come see fight win lose game play start " +
        "press button level stage score lives continue select item items health power attack defend magic sword key door room " +
        "must should never always again still too very much many more less long little right left down away off home night " +
        "morning today tomorrow tonight fun enjoy welcome have has"
        ).split(' ').toHashSet()

    private val COMMON_ID = (
        "yang dan di ke dari ini itu dengan untuk tidak akan pada adalah juga atau saya aku kamu anda dia kami kita mereka " +
        "ada bisa sudah belum harus jangan santai saja waktu buang selamat bermain permainan ayo tolong maaf terima kasih " +
        "halo hei ya tidak bukan apa siapa mana kenapa bagaimana kapan di sini sana sekarang nanti lagi masih sangat " +
        "lebih banyak sedikit satu dua tiga kalau karena tetapi namun supaya agar oleh dalam antara semua setiap " +
        "pergi datang lihat tunggu berhenti lari bantu lawan menang kalah mulai lanjut pilih tombol tingkat skor nyawa " +
        "kota dunia hidup mati bos pria wanita anak kunci pintu ruangan malam pagi hari besok"
        ).split(' ').toHashSet()

    private val VOWELS = "aeiouAEIOU"
    private val ODD_CHARS = "¿¡§¤¶«»¬¦¥£¢°±×÷µ~^`|\\{}[]<>_=@#$%*"

    /** 0..1, dihitung per kata lalu dirata-rata berbobot jumlah huruf. */
    fun score(text: String, indonesian: Boolean = false): Float {
        val tokens = Regex("[\\p{L}][\\p{L}'’-]*").findAll(text).map { it.value }.toList()
        if (tokens.isEmpty()) return 0f
        val common = if (indonesian) COMMON_ID else COMMON_EN
        var good = 0f
        var total = 0f
        for (t in tokens) {
            val w = t.length.toFloat().coerceAtMost(8f)
            total += w
            good += w * wordScore(t, common)
        }
        var s = if (total > 0f) good / total else 0f
        // dialog sungguhan hampir selalu memuat beberapa kata umum; teks acak tidak (hanya untuk teks Inggris/OCR)
        if (!indonesian && tokens.size >= 3) {
            val hit = tokens.count { it.lowercase().trim('\'', '’', '-') in common }
            if (hit.toFloat() / tokens.size < 0.2f) s *= 0.6f
        }
        // karakter aneh dan tanda baca terbalik hampir tidak pernah muncul di dialog bahasa Inggris/Indonesia
        val odd = text.count { it in ODD_CHARS }
        if (odd > 0) s *= max(0.2f, 1f - odd * 0.35f)
        // terlalu banyak tanda baca di tengah kata ("'h", "¿nox")
        val letters = text.count { it.isLetter() }
        val punct = text.count { !it.isLetterOrDigit() && !it.isWhitespace() && it !in ".,!?'’\"-:;…" }
        if (letters > 0 && punct.toFloat() / letters > 0.15f) s *= 0.5f
        return s.coerceIn(0f, 1f)
    }

    fun isReadable(text: String, indonesian: Boolean = false, min: Float = 0.45f): Boolean {
        if (text.count { it.isLetter() } < 3) return true       // terlalu pendek untuk dinilai
        return score(text, indonesian) >= min
    }

    private fun wordScore(raw: String, common: Set<String>): Float {
        val w = raw.lowercase().trim('\'', '’', '-')
        if (w.isEmpty()) return 0f
        if (w in common) return 1f
        if (w.length == 1) return if (w == "a" || w == "i") 1f else 0.2f
        var s = 0.75f
        // campuran besar-kecil di tengah kata ("oRiOhm") = tanda OCR salah, kecuali kata sepenuhnya huruf besar
        val inner = raw.drop(1)
        if (inner.any { it.isUpperCase() } && inner.any { it.isLowerCase() }) s -= 0.35f
        val v = w.count { it in VOWELS }
        val ratio = v.toFloat() / w.length
        if (w.length >= 3 && v == 0) s -= 0.55f
        if (ratio > 0.8f && w.length >= 4) s -= 0.35f
        if (Regex("[^aeiou]{5,}").containsMatchIn(w)) s -= 0.4f
        if (Regex("(.)\\1\\1").containsMatchIn(w)) s -= 0.4f
        if (raw.contains('\'') && raw.indexOf('\'') == 1 && w.length > 2 && w.substring(2) !in setOf("s", "m", "d", "t", "ll", "re", "ve")) s -= 0.3f
        // kata yang memuat sebagian besar huruf jarang (q, x, z, j, k, w) tanpa pola wajar
        val rare = w.count { it in "qxzjv" }
        if (w.length >= 4 && rare * 2 >= w.length) s -= 0.3f
        return s.coerceIn(0f, 1f)
    }
}
