package com.allinone.emulator.data

import com.swordfish.libretrodroid.Variable

/**
 * Pengaturan performa khusus game arcade (MAME 2003-Plus).
 *
 * Nama dan nilai opsi dicocokkan langsung dengan source core (FBNeo `retro_common.cpp`,
 * MAME 2003-Plus `core_options.c`). Dua penyebab pengaturan lama "tidak berdampak":
 *
 *  1. Frameskip otomatis TIDAK PERNAH aktif. Mode "Auto"/"Manual" FBNeo dan "auto*" MAME 2003-Plus hanya jalan
 *     bila frontend menjawab RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK, dan LibretroDroid tidak
 *     mengimplementasikannya. Maka di sini hanya frameskip TETAP (angka) yang dipakai: itu satu-satunya yang berlaku.
 *  2. Kecepatan CPU MAME 2003-Plus memakai kunci per-game `mame2003-plus_<namaROM>_cpu_clock_scale` dengan nilai
 *     angka tanpa "%" (mis. "110"). Kunci umum `mame2003-plus_cpu_clock_scale` yang dipakai sebelumnya tidak pernah dibaca core.
 *
 * Profil ([perf]):
 *  0 = Standar   : opsi bawaan core, tidak diubah.
 *  1 = Seimbang  : tanpa frame dibuang; warna 16-bit, suara lebih ringan.
 *  2 = Ringan    : Seimbang + buang 1 dari tiap 2 frame gambar (CPU emulasi tetap penuh, hanya menggambar yang dihemat).
 *  3 = Maksimal  : buang 2 dari tiap 3 frame gambar + suara paling ringan. Untuk game dengan sprite sangat ramai.
 *
 * Frameskip hanya menghemat proses MENGGAMBAR sprite; kerja CPU emulasi tidak berkurang. Jika game masih lambat
 * walau di profil Maksimal, penyebabnya CPU emulasi itu sendiri.
 */
object ArcadeTuning {

    /** Core arcade yang dipakai. */
    val CORES = listOf(Console.ARCADE_MAME)

    const val PROFILE_COUNT = 4

    fun isArcade(c: Console) = c in CORES

    /** Jumlah frame yang dibuang per frame yang digambar: 0 = tidak ada, 1 = 1 dari 2, 2 = 2 dari 3. */
    private fun skipFor(perf: Int) = when (perf) { 2 -> 1; 3 -> 2; else -> 0 }

    /**
     * Variabel core untuk satu game.
     * @param romName nama file ROM tanpa ekstensi (= nama driver MAME); dibutuhkan untuk kunci CPU MAME 2003-Plus.
     */
    fun variables(console: Console, perf: Int, cpuPercent: Int, romName: String): List<Variable> {
        val v = ArrayList<Variable>()
        val skip = skipFor(perf)
        when (console) {
            Console.ARCADE_MAME -> {
                if (perf >= 1) {
                    v += Variable("mame2003-plus_frameskip", if (skip > 0) skip.toString() else "disabled")
                    v += Variable("mame2003-plus_sample_rate", if (perf >= 3) "22050" else if (perf == 2) "30000" else "44100")
                }
                // Hanya CPU utama (slot 1). CPU suara tidak disentuh agar tempo musik tidak berubah.
                if (cpuPercent != 100 && romName.isNotEmpty()) {
                    v += Variable("mame2003-plus_${romName.take(16)}_cpu_clock_scale", snapCpu(console, cpuPercent).toString())
                }
            }
            else -> {}
        }
        // Kunci yang sama bisa muncul dua kali: nilai terakhir yang berlaku
        return v.associateBy { it.key }.values.toList()
    }

    /** Pilihan kecepatan CPU untuk menu. MAME 2003-Plus hanya menerima nilai tertentu (lihat [snapCpu]). */
    val CPU_CHOICES = listOf(100, 110, 120, 130, 150, 175, 200, 250, 300)

    /** Nilai yang diterima core MAME 2003-Plus (dari core_options.c); nilai lain diabaikan core. */
    private val MAME_CPU_VALUES = listOf(25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105, 110, 115, 120, 125, 200, 250, 300)

    /** Sesuaikan persen CPU ke nilai yang benar-benar dikenal core yang dipakai. */
    fun snapCpu(console: Console, percent: Int): Int = when (console) {
        Console.ARCADE_MAME -> MAME_CPU_VALUES.minByOrNull { Math.abs(it - percent) } ?: 100
        else -> percent
    }

    /** Bagian yang bisa diubah saat game berjalan. Kecepatan CPU MAME 2003-Plus hanya dibaca saat game dimulai. */
    fun liveVariables(console: Console, perf: Int, cpuPercent: Int, romName: String): List<Variable> =
        variables(console, perf, 100, romName)
}
