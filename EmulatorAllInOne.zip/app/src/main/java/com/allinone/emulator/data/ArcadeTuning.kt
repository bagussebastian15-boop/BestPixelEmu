package com.allinone.emulator.data

import com.swordfish.libretrodroid.Variable

/**
 * Pengaturan performa khusus game arcade (MAME 2010 dan FBNeo).
 *
 * Nama dan nilai opsi dicocokkan dengan source core (FBNeo `retro_common.cpp`, MAME 2010 `libretro.c`: kunci `mame_current_*`).
 * Frameskip otomatis ("automatic"/"Auto") tidak dipakai karena bergantung pada callback status buffer audio yang
 * tidak diimplementasikan LibretroDroid; hanya frameskip TETAP (angka) yang berlaku.
 * Kecepatan CPU hanya tersedia di FBNeo; MAME 2010 tidak punya opsi tersebut.
 *
 * Profil ([perf]):
 *  0 = Standar   : opsi bawaan core, tidak diubah.
 *  1 = Seimbang  : tanpa frame dibuang; warna 16-bit, suara lebih ringan.
 *  2 = Ringan    : Seimbang + buang 1 dari tiap 2 frame gambar (CPU emulasi tetap penuh, hanya menggambar yang dihemat).
 *  3 = Maksimal  : buang 2 dari tiap 3 frame gambar + suara paling ringan. Untuk game dengan sprite sangat ramai.
 *
 * Frameskip hanya menghemat proses MENGGAMBAR sprite; kerja CPU emulasi tidak berkurang. Jika game masih lambat
 * walau di profil Maksimal, penyebabnya CPU emulasi itu sendiri.
 */
object ArcadeTuning {

    /** Core arcade yang dipakai. */
    val CORES = Console.values().filter { it.isArcade }

    const val PROFILE_COUNT = 4

    fun isArcade(c: Console) = c in CORES

    /** Jumlah frame yang dibuang per frame yang digambar: 0 = tidak ada, 1 = 1 dari 2, 2 = 2 dari 3. */
    private fun skipFor(perf: Int) = when (perf) { 2 -> 1; 3 -> 2; else -> 0 }

    /**
     * Variabel core untuk satu game.
     * @param romName nama file ROM tanpa ekstensi (= nama driver MAME); tidak dipakai MAME 2010, dipertahankan agar tanda tangan fungsi sama.
     */
    fun variables(console: Console, perf: Int, cpuPercent: Int, romName: String): List<Variable> {
        val v = ArrayList<Variable>()
        val skip = skipFor(perf)
        when (console) {
            Console.ARCADE_MAME -> {
                // Nama/nilai opsi MAME 2010 (mame_current_*). Frameskip tetap (angka); "automatic" tidak dipakai.
                // Layar peringatan/info game dilewati agar game langsung jalan tanpa perlu menekan tombol.
                v += Variable("mame_current_skip_gameinfos", "enabled")
                v += Variable("mame_current_skip_warnings", "enabled")
                if (perf >= 1) {
                    v += Variable("mame_current_frame_skip", skip.toString())
                    v += Variable("mame_current_sample_rate", if (perf >= 3) "32000Hz" else "44100Hz")   // 22050 Hz dibuang: bikin suara pecah/kresek
                }
                // MAME 2010 tidak punya opsi kecepatan CPU, jadi cpuPercent diabaikan di sini.
            }
            Console.ARCADE_FBNEO -> {
                // Nama opsi sesuai dokumentasi FBNeo terbaru; opsi yang tak dikenal core diabaikan.
                if (perf >= 1) {
                    v += Variable("fbneo-frameskip-type", if (skip > 0) "Fixed" else "disabled")
                    if (skip > 0) v += Variable("fbneo-fixed-frameskip", skip.toString())
                }
                // Selalu dikirim (termasuk 100%) supaya perubahan saat game berjalan, mis. 200% kembali ke 100%, ikut berlaku
                v += Variable("fbneo-cpu-speed-adjust", "${snapCpu(console, cpuPercent)}%")
            }
            Console.ARCADE_MAME2003P -> v += Variable("mame2003-plus_skip_warnings", "enabled")
            Console.ARCADE_MAME2003 -> v += Variable("mame2003_skip_warnings", "enabled")
            else -> {}   // core lain: opsi bawaan (opsi yang tak dikenal core diabaikan)
        }
        // Kunci yang sama bisa muncul dua kali: nilai terakhir yang berlaku
        return v.associateBy { it.key }.values.toList()
    }

    /** Pilihan kecepatan CPU untuk menu. hanya FBNeo yang memakai ini (lihat [snapCpu]). */
    val CPU_CHOICES = listOf(100, 110, 120, 130, 150, 175, 200, 250, 300)

    /** Nilai kecepatan CPU FBNeo (persen). */
    private val FBNEO_CPU_VALUES = listOf(100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, 250, 300)

    /** Sesuaikan persen CPU ke nilai yang benar-benar dikenal core yang dipakai. */
    fun snapCpu(console: Console, percent: Int): Int = when (console) {
        Console.ARCADE_MAME -> 100   // MAME 2010 tidak punya opsi kecepatan CPU
        Console.ARCADE_FBNEO -> FBNEO_CPU_VALUES.minByOrNull { Math.abs(it - percent) } ?: 100
        else -> percent
    }

    /**
     * Bagian yang bisa diubah saat game berjalan. FBNeo membaca ulang kecepatan CPU langsung; kecepatan CPU
     * hanya ada di FBNeo; MAME 2010 tidak punya opsi tersebut.
     */
    fun liveVariables(console: Console, perf: Int, cpuPercent: Int, romName: String): List<Variable> =
        if (console == Console.ARCADE_FBNEO) variables(console, perf, cpuPercent, romName)
        else variables(console, perf, 100, romName)
}
