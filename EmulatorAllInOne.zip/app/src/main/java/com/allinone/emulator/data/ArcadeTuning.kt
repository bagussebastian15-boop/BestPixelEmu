package com.allinone.emulator.data

import com.swordfish.libretrodroid.Variable

/**
 * Pengaturan performa khusus game arcade (FBNeo dan MAME 2003-Plus).
 *
 * Nama dan nilai opsi core diambil dari daftar opsi resmi kedua core. Opsi yang tidak dikenali oleh versi
 * core yang terpasang diabaikan oleh core, jadi aman jika ada yang tidak berlaku.
 *
 * Profil ([perf]):
 *  0 = Standar   : opsi bawaan core, tidak diubah.
 *  1 = Seimbang  : MAME frameskip otomatis, FBNeo warna 16-bit + interpolasi suara lebih ringan.
 *  2 = Maksimal  : Seimbang + suara lebih ringan + frameskip lebih agresif.
 *
 * [cpuPercent] = kecepatan CPU emulasi. Di atas 100 mengurangi slowdown bawaan game saat sprite ramai
 * (mesin arcade aslinya memang melambat), tetapi menambah beban HP.
 */
object ArcadeTuning {

    /** Semua core arcade, dari yang terlengkap sampai yang teringan. */
    val CORES = listOf(Console.ARCADE_FBNEO, Console.ARCADE_MAME, Console.ARCADE_FBA2012)

    fun isArcade(c: Console) = c in CORES

    fun variables(console: Console, perf: Int, cpuPercent: Int): List<Variable> {
        val v = ArrayList<Variable>()
        when (console) {
            Console.ARCADE_FBNEO -> {
                if (perf >= 1) {
                    v += Variable("fbneo-allow-depth-32", "disabled")              // warna 16-bit: lebih ringan di GPU
                    v += Variable("fbneo-sample-interpolation", "2-point 1st order")
                }
                if (perf >= 2) {
                    v += Variable("fbneo-sample-interpolation", "disabled")
                    v += Variable("fbneo-fm-interpolation", "disabled")
                    v += Variable("fbneo-frameskip-type", "Fixed")
                    v += Variable("fbneo-fixed-frameskip", "1")                    // 1 dari 2 frame tidak digambar
                }
                if (cpuPercent != 100) v += Variable("fbneo-cpu-speed-adjust", "$cpuPercent%")
            }
            Console.ARCADE_MAME -> {
                if (perf == 1) v += Variable("mame2003-plus_frameskip", "auto")
                if (perf >= 2) {
                    v += Variable("mame2003-plus_frameskip", "auto_aggressive")
                    v += Variable("mame2003-plus_sample_rate", "22050")
                }
                if (cpuPercent != 100) v += Variable("mame2003-plus_cpu_clock_scale", "$cpuPercent%")
            }
            Console.ARCADE_FBA2012 -> {
                // Core ini sudah ringan dan tidak punya opsi frameskip; hanya kecepatan CPU yang bisa diatur
                if (cpuPercent != 100) v += Variable("fbalpha2012_cpu_speed_adjust", cpuPercent.toString())
            }
            else -> {}
        }
        // Kunci yang sama bisa muncul dua kali (profil bertingkat): nilai terakhir yang berlaku
        return v.associateBy { it.key }.values.toList()
    }
}
