package com.allinone.emulator.data

import com.swordfish.libretrodroid.Variable

/**
 * Pengaturan performa khusus game arcade (FBNeo, MAME 2003-Plus, FB Alpha 2012).
 *
 * Nama dan nilai opsi dicocokkan langsung dengan source core (FBNeo `retro_common.cpp`,
 * MAME 2003-Plus `core_options.c`). Dua penyebab pengaturan lama "tidak berdampak":
 *
 *  1. Frameskip otomatis TIDAK PERNAH aktif. Mode "Auto"/"Manual" FBNeo dan "auto*" MAME 2003-Plus hanya jalan
 *     bila frontend menjawab RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK, dan LibretroDroid tidak
 *     mengimplementasikannya. Maka di sini hanya frameskip TETAP (angka) yang dipakai: itu satu-satunya yang berlaku.
 *  2. Kecepatan CPU MAME 2003-Plus memakai kunci per-game `mame2003-plus_<namaROM>_cpu_clock_scale` dengan nilai
 *     angka tanpa "%" (mis. "110"). Kunci umum `mame2003-plus_cpu_clock_scale` yang dipakai sebelumnya tidak pernah dibaca core.
 *
 * Profil ([perf]):
 *  0 = Standar   : opsi bawaan core, tidak diubah.
 *  1 = Seimbang  : tanpa frame dibuang; warna 16-bit, suara lebih ringan.
 *  2 = Ringan    : Seimbang + buang 1 dari tiap 2 frame gambar (CPU emulasi tetap penuh, hanya menggambar yang dihemat).
 *  3 = Maksimal  : buang 2 dari tiap 3 frame gambar + suara paling ringan. Untuk game dengan sprite sangat ramai.
 *
 * Frameskip hanya menghemat proses MENGGAMBAR sprite; kerja CPU emulasi tidak berkurang. Jika game masih lambat
 * walau di profil Maksimal, penyebabnya CPU emulasi itu sendiri; coba core FB Alpha 2012 (lebih ringan).
 */
object ArcadeTuning {

    /** Semua core arcade, dari yang terlengkap sampai yang teringan. */
    val CORES = listOf(Console.ARCADE_FBNEO, Console.ARCADE_MAME, Console.ARCADE_FBA2012)

    const val PROFILE_COUNT = 4

    fun isArcade(c: Console) = c in CORES

    /** Jumlah frame yang dibuang per frame yang digambar: 0 = tidak ada, 1 = 1 dari 2, 2 = 2 dari 3. */
    private fun skipFor(perf: Int) = when (perf) { 2 -> 1; 3 -> 2; else -> 0 }

    /**
     * Variabel core untuk satu game.
     * @param romName nama file ROM tanpa ekstensi (= nama driver MAME); dibutuhkan untuk kunci CPU MAME 2003-Plus.
     */
    fun variables(console: Console, perf: Int, cpuPercent: Int, romName: String): List<Variable> {
        val v = ArrayList<Variable>()
        val skip = skipFor(perf)
        when (console) {
            Console.ARCADE_FBNEO -> {
                if (perf >= 1) {
                    v += Variable("fbneo-allow-depth-32", "disabled")              // warna 16-bit: lebih ringan di GPU
                    v += Variable("fbneo-sample-interpolation", if (perf >= 3) "disabled" else "2-point 1st order")
                    v += Variable("fbneo-fm-interpolation", if (perf >= 3) "disabled" else "4-point 3rd order")
                }
                if (perf >= 1) {
                    // Tanpa dukungan audio-buffer dari frontend, FBNeo menyembunyikan "fbneo-frameskip-type" dan
                    // hanya membaca "fbneo-fixed-frameskip" (selalu berlaku). Ditulis eksplisit agar profil 1 = 0.
                    v += Variable("fbneo-fixed-frameskip", skip.toString())
                }
                if (cpuPercent != 100) v += Variable("fbneo-cpu-speed-adjust", "$cpuPercent%")
            }
            Console.ARCADE_MAME -> {
                if (perf >= 1) {
                    v += Variable("mame2003-plus_frameskip", if (skip > 0) skip.toString() else "disabled")
                    v += Variable("mame2003-plus_sample_rate", if (perf >= 3) "22050" else if (perf == 2) "30000" else "44100")
                }
                // Hanya CPU utama (slot 1). CPU suara tidak disentuh agar tempo musik tidak berubah.
                if (cpuPercent != 100 && romName.isNotEmpty()) {
                    v += Variable("mame2003-plus_${romName.take(16)}_cpu_clock_scale", cpuPercent.toString())
                }
            }
            Console.ARCADE_FBA2012 -> {
                // Core ini sudah ringan dan tidak punya opsi frameskip; hanya kecepatan CPU yang bisa diatur
                if (cpuPercent != 100) v += Variable("fbalpha2012_cpu_speed_adjust", cpuPercent.toString())
            }
            else -> {}
        }
        // Kunci yang sama bisa muncul dua kali: nilai terakhir yang berlaku
        return v.associateBy { it.key }.values.toList()
    }

    /** Hanya bagian yang aman diubah saat game berjalan (tanpa kecepatan CPU, yang dibaca saat game dimulai). */
    fun liveVariables(console: Console, perf: Int, romName: String): List<Variable> =
        variables(console, perf, 100, romName)
}
