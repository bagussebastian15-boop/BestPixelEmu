package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import com.allinone.emulator.R
import com.allinone.emulator.input.VirtualPadView
import kotlin.math.max
import kotlin.math.min

/**
 * Latar game SNES saat game berjalan: abu-abu kebiruan dengan logo Bit©ade di pojok kiri atas.
 *
 * View ini dipasang DI ATAS layar game (permukaan GL tidak bisa tembus pandang, dan sisi hitamnya ikut
 * tergambar oleh GL), tetapi bagian tempat gambar game berada dibiarkan kosong (tidak digambar), jadi game
 * tetap terlihat. Hanya area di luar gambar game yang diisi latar. Tombol kontrol dipasang di atas view ini.
 * Posisi gambar game = lebar/tinggi view game dipotong sesuai rasio [aspect] (Snes9x bawaan 4:3), di tengah.
 */
class SnesBackgroundView(ctx: Context, private val game: View, private val aspect: Float = 4f / 3f) : View(ctx) {
    private val logo: Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, R.drawable.snes_logo)
    } catch (_: Throwable) { null }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint().apply { color = VirtualPadView.SNES_BG }
    private val hole = RectF()
    private val dst = RectF()
    private val parts = Array(4) { RectF() }

    init {
        game.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> invalidate() }
    }

    /** Persegi tempat gambar game tampil (koordinat view ini). Kosong bila game belum diukur. */
    private fun gameRect(out: RectF) {
        if (game.width <= 0 || game.height <= 0) { out.setEmpty(); return }
        val sx = game.scaleX; val sy = game.scaleY
        var bw = game.width * sx
        var bh = game.height * sy
        val cx = game.left + game.width / 2f + game.translationX
        val cy = game.top + game.height / 2f + game.translationY
        // Tanpa peregangan: gambar game memakai rasio aslinya di dalam view (sisanya bilah hitam)
        if (sx == 1f && sy == 1f) {
            if (bw / bh > aspect) bw = bh * aspect else bh = bw / aspect
        }
        out.set(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        gameRect(hole)
        hole.intersect(0f, 0f, w, h)
        if (hole.isEmpty) hole.set(w / 2f, h / 2f, w / 2f, h / 2f)

        // Empat bidang di sekeliling gambar game
        parts[0].set(0f, 0f, w, hole.top)
        parts[1].set(0f, hole.bottom, w, h)
        parts[2].set(0f, hole.top, hole.left, hole.bottom)
        parts[3].set(hole.right, hole.top, w, hole.bottom)
        for (p in parts) if (!p.isEmpty) c.drawRect(p, fill)

        val bmp = logo ?: return
        val long = max(w, h)
        val short = min(w, h)
        val lw = long * 0.133f
        val lh = lw * bmp.height / bmp.width
        val left = long * 0.048f
        val top = short * 0.08f
        dst.set(left, top, left + lw, top + lh)
        // Logo hanya digambar di luar gambar game
        for (p in parts) {
            if (p.isEmpty) continue
            c.save()
            c.clipRect(p)
            c.drawBitmap(bmp, null, dst, paint)
            c.restore()
        }
    }
}
