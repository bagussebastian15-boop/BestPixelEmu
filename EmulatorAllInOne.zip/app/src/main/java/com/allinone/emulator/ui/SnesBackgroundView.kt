package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import com.allinone.emulator.R
import com.allinone.emulator.input.VirtualPadView
import kotlin.math.max
import kotlin.math.min

/**
 * Latar game SNES: abu-abu kebiruan polos dengan logo Bit©ade di pojok kiri atas (posisi dan ukuran
 * dihitung dari gambar latar asli, jadi di lanskap tampil sama persis). Dipasang paling bawah:
 * layar game dan tombol kontrol tetap tampil di atasnya.
 */
class SnesBackgroundView(ctx: Context) : View(ctx) {
    private val logo: Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, R.drawable.snes_logo)
    } catch (_: Throwable) { null }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()

    override fun onDraw(c: Canvas) {
        c.drawColor(VirtualPadView.SNES_BG)
        val bmp = logo ?: return
        val long = max(width, height).toFloat()
        val short = min(width, height).toFloat()
        val lw = long * 0.133f                      // lebar logo
        val lh = lw * bmp.height / bmp.width
        val left = long * 0.048f
        val top = short * 0.08f
        dst.set(left, top, left + lw, top + lh)
        c.drawBitmap(bmp, null, dst, paint)
    }
}
