package com.allinone.emulator.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

data class Game(val file: File, val console: Console) {
    val title: String get() = file.nameWithoutExtension
}

object RomLibrary {

    fun list(ctx: Context): List<Game> =
        Console.values().flatMap { c ->
            Paths.roms(ctx, c).listFiles().orEmpty().filter { it.isFile }.map { Game(it, c) }
        }.sortedBy { it.title.lowercase() }

    /** Menyalin file ROM pilihan pengguna ke folder app. Bekerja sama di Android 5 sampai terbaru. */
    fun import(ctx: Context, uri: Uri): Boolean {
        val name = displayName(ctx, uri) ?: return false
        val ext = name.substringAfterLast('.', "").lowercase()
        val console = Console.fromExtension(ext) ?: return false
        val dest = File(Paths.roms(ctx, console), File(name).name)
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { out -> input.copyTo(out) }
            } != null
        } catch (e: Exception) {
            dest.delete()
            false
        }
    }

    fun delete(game: Game): Boolean = game.file.delete()

    /** Core arcade lain selain yang dipakai game ini (urutan tetap: FBNeo, MAME 2003-Plus, FB Alpha 2012). */
    fun otherArcadeCores(game: Game): List<Console> =
        if (ArcadeTuning.isArcade(game.console)) ArcadeTuning.CORES.filter { it != game.console } else emptyList()

    /** File .zip arcade bisa dijalankan core arcade mana pun; pindahkan jika satu core tidak cocok dengan set ROM-nya. */
    fun switchArcadeCore(ctx: Context, game: Game, target: Console): Boolean {
        if (!ArcadeTuning.isArcade(game.console) || target !in otherArcadeCores(game)) return false
        return game.file.renameTo(File(Paths.roms(ctx, target), game.file.name))
    }

    private fun displayName(ctx: Context, uri: Uri): String? =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
}
