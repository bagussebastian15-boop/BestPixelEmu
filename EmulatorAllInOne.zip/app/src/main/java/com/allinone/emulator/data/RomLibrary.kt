package com.allinone.emulator.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

data class Game(val file: File, val console: Console) {
    val title: String get() = file.nameWithoutExtension
}

object RomLibrary {

    /** Folder core arcade lama (FBNeo dan FB Alpha 2012 sudah dihapus): ROM-nya dipindah ke folder MAME 2003-Plus. */
    private fun migrateOldArcade(ctx: Context) {
        val dest = Paths.roms(ctx, Console.ARCADE_MAME)
        for (old in listOf("arcade_fbneo", "arcade_fba2012")) {
            val dir = File(Paths.roms(ctx, Console.ARCADE_MAME).parentFile, old)
            dir.listFiles().orEmpty().filter { it.isFile }.forEach { f ->
                val t = File(dest, f.name)
                if (!t.exists()) f.renameTo(t) else f.delete()
            }
            dir.delete()
        }
    }

    private val checkedZips = HashSet<String>()

    /** Konsol pemilik sebuah file ROM, dari nama folder induknya. */
    fun consoleOf(f: File): Console? = Console.values().firstOrNull { it.name.lowercase() == f.parentFile?.name }

    /**
     * Membaca ISI sebuah file .zip untuk mengetahui peruntukannya. Semua .zip awalnya dianggap arcade,
     * tetapi bila di dalamnya ada ROM konsol (.gba, .sfc/.smc/.fig/.swc, .md/.gen/.smd, atau satu file .bin),
     * ROM itu diekstrak ke folder konsol yang benar dan zip-nya dihapus. Zip arcade (set ROM berisi banyak
     * file kecil) dibiarkan apa adanya. Mengembalikan daftar file hasil ekstrak (kosong = zip arcade / tidak berubah).
     */
    fun normalizeZip(ctx: Context, zip: File): List<File> {
        val key = "${zip.absolutePath}:${zip.length()}:${zip.lastModified()}"
        if (!checkedZips.add(key)) return emptyList()
        val out = ArrayList<File>()
        var allDone = false
        try {
            ZipFile(zip).use { zf ->
                val entries = zf.entries().asSequence().filter { !it.isDirectory }.toList()
                fun ext(e: ZipEntry) = e.name.substringAfterLast('.', "").lowercase()
                var picked = entries.filter { e ->
                    val c = Console.fromExtension(ext(e))
                    c != null && !c.isArcade && ext(e) != "bin"
                }
                if (picked.isEmpty() && entries.size == 1 && ext(entries[0]) == "bin") picked = entries
                if (picked.isEmpty()) return emptyList()
                for (e in picked) {
                    val console = Console.fromExtension(ext(e)) ?: continue
                    val base = if (picked.size == 1) zip.nameWithoutExtension else File(e.name).nameWithoutExtension
                    val dir = Paths.roms(ctx, console)
                    val dest = File(dir, "$base.${ext(e)}")
                    val part = File(dir, dest.name + ".part")
                    try {
                        zf.getInputStream(e).use { i -> part.outputStream().use { o -> i.copyTo(o) } }
                        if ((dest.delete() || !dest.exists()) && part.renameTo(dest)) out += dest else part.delete()
                    } catch (ex: Exception) { part.delete() }
                }
                allDone = out.size == picked.size
            }
        } catch (ex: Exception) {
            return out
        }
        if (allDone) zip.delete()
        return out
    }

    /** Memeriksa zip lama di folder arcade (hasil impor/unduhan sebelumnya). Panggil di thread latar. Mengembalikan jumlah zip yang dipindah. */
    fun fixZips(ctx: Context): Int {
        var moved = 0
        Paths.roms(ctx, Console.ARCADE_MAME).listFiles().orEmpty()
            .filter { it.isFile && it.extension.equals("zip", true) }
            .forEach { if (normalizeZip(ctx, it).isNotEmpty()) moved++ }
        return moved
    }

    fun list(ctx: Context): List<Game> {
        migrateOldArcade(ctx)
        return Console.values().filter { it.extensions.isNotEmpty() }.flatMap { c ->
            Paths.roms(ctx, c).listFiles().orEmpty().filter { it.isFile && !it.name.endsWith(".part") }.map { Game(it, c) }
        }.sortedBy { it.title.lowercase() }
    }

    /** Hasil impor folder. */
    data class ImportResult(val imported: Int, val skipped: Int, val failed: Int, val ignored: Int)

    private const val MAX_DEPTH = 8

    /**
     * Mengimpor semua ROM dalam sebuah folder pilihan pengguna (termasuk subfolder) ke folder app.
     * Bekerja lewat Storage Access Framework, sama di Android 5 sampai terbaru. File dengan ekstensi yang tidak dikenal
     * diabaikan; file yang sudah ada dengan ukuran sama dilewati (impor ulang cepat). [onProgress] dipanggil tiap file
     * selesai diproses (jumlah file ROM yang sudah diproses).
     */
    fun importFolder(ctx: Context, tree: Uri, onProgress: (Int) -> Unit = {}): ImportResult {
        var imported = 0; var skipped = 0; var failed = 0; var ignored = 0; var done = 0
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE
        )

        val existing = list(ctx).map { it.title.lowercase() }.toMutableSet()

        fun copyOne(docId: String, name: String, size: Long, console: Console) {
            val dest = File(Paths.roms(ctx, console), File(name).name)
            if (size > 0 && dest.isFile && dest.length() == size) { skipped++; return }
            // Zip yang isinya sudah diekstrak ke folder konsol lain: lewati
            if (name.endsWith(".zip", true) && !dest.exists() && File(name).nameWithoutExtension.lowercase() in existing) { skipped++; return }
            val part = File(dest.parentFile, dest.name + ".part")
            try {
                val src = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
                val ok = ctx.contentResolver.openInputStream(src)?.use { input ->
                    part.outputStream().use { out -> input.copyTo(out) }
                } != null
                if (ok && (dest.delete() || !dest.exists()) && part.renameTo(dest)) {
                    imported++
                    existing += dest.nameWithoutExtension.lowercase()
                    // Baca isi zip: ROM GBA/SNES/Genesis dipindah ke konsol yang tepat
                    if (dest.extension.equals("zip", true)) normalizeZip(ctx, dest).forEach { existing += it.nameWithoutExtension.lowercase() }
                } else { part.delete(); failed++ }
            } catch (e: Exception) {
                part.delete(); failed++
            }
        }

        fun walk(docId: String, depth: Int) {
            val files = ArrayList<Triple<String, String, Long>>()
            val dirs = ArrayList<String>()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            try {
                ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2)
                        val size = if (c.isNull(3)) -1L else c.getLong(3)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) dirs += id else files += Triple(id, name, size)
                    }
                }
            } catch (e: Exception) {
                return
            }
            for ((id, name, size) in files) {
                val console = Console.fromExtension(name.substringAfterLast('.', "").lowercase())
                if (console == null) { ignored++; continue }
                copyOne(id, name, size, console)
                done++; onProgress(done)
            }
            if (depth < MAX_DEPTH) dirs.forEach { walk(it, depth + 1) }
        }

        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return ImportResult(imported, skipped, failed, ignored)
    }

    fun delete(game: Game): Boolean = game.file.delete()

    /** Hapus file game sekaligus save (SRAM), save state, dan cheat miliknya. */
    fun deleteWithData(ctx: Context, game: Game): Boolean {
        val re = Regex("^" + Regex.escape(game.title) + "(\\.fbneo)?\\.(sram\\.bin|[^.]+\\.state)$")
        listOf(Paths.saves(ctx), Paths.states(ctx)).forEach { d ->
            d.listFiles().orEmpty().filter { it.isFile && re.matches(it.name) }.forEach { it.delete() }
        }
        File(Paths.cheats(ctx), "${game.title}.json").delete()
        return game.file.delete()
    }
}
