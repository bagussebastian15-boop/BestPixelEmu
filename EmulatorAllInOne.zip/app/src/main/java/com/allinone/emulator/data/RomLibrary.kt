package com.allinone.emulator.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File

data class Game(val file: File, val console: Console) {
    val title: String get() = file.nameWithoutExtension
}

object RomLibrary {

    /** Folder core arcade lama (FBNeo dan FB Alpha 2012 sudah dihapus): ROM-nya dipindah ke folder MAME 2003-Plus. */
    private fun migrateOldArcade(ctx: Context) {
        val dest = Paths.roms(ctx, Console.ARCADE_MAME)
        for (old in listOf("arcade_fbneo", "arcade_fba2012")) {
            val dir = File(Paths.roms(ctx, Console.ARCADE_MAME).parentFile, old)
            dir.listFiles().orEmpty().filter { it.isFile }.forEach { f ->
                val t = File(dest, f.name)
                if (!t.exists()) f.renameTo(t) else f.delete()
            }
            dir.delete()
        }
    }

    fun list(ctx: Context): List<Game> {
        migrateOldArcade(ctx)
        return Console.values().filter { it.extensions.isNotEmpty() }.flatMap { c ->
            Paths.roms(ctx, c).listFiles().orEmpty().filter { it.isFile && !it.name.endsWith(".part") }.map { Game(it, c) }
        }.sortedBy { it.title.lowercase() }
    }

    /** Hasil impor folder. */
    data class ImportResult(val imported: Int, val skipped: Int, val failed: Int, val ignored: Int)

    private const val MAX_DEPTH = 8

    /**
     * Mengimpor semua ROM dalam sebuah folder pilihan pengguna (termasuk subfolder) ke folder app.
     * Bekerja lewat Storage Access Framework, sama di Android 5 sampai terbaru. File dengan ekstensi yang tidak dikenal
     * diabaikan; file yang sudah ada dengan ukuran sama dilewati (impor ulang cepat). [onProgress] dipanggil tiap file
     * selesai diproses (jumlah file ROM yang sudah diproses).
     */
    fun importFolder(ctx: Context, tree: Uri, onProgress: (Int) -> Unit = {}): ImportResult {
        var imported = 0; var skipped = 0; var failed = 0; var ignored = 0; var done = 0
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE
        )

        fun copyOne(docId: String, name: String, size: Long, console: Console) {
            val dest = File(Paths.roms(ctx, console), File(name).name)
            if (size > 0 && dest.isFile && dest.length() == size) { skipped++; return }
            val part = File(dest.parentFile, dest.name + ".part")
            try {
                val src = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
                val ok = ctx.contentResolver.openInputStream(src)?.use { input ->
                    part.outputStream().use { out -> input.copyTo(out) }
                } != null
                if (ok && (dest.delete() || !dest.exists()) && part.renameTo(dest)) imported++ else { part.delete(); failed++ }
            } catch (e: Exception) {
                part.delete(); failed++
            }
        }

        fun walk(docId: String, depth: Int) {
            val files = ArrayList<Triple<String, String, Long>>()
            val dirs = ArrayList<String>()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            try {
                ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2)
                        val size = if (c.isNull(3)) -1L else c.getLong(3)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) dirs += id else files += Triple(id, name, size)
                    }
                }
            } catch (e: Exception) {
                return
            }
            for ((id, name, size) in files) {
                val console = Console.fromExtension(name.substringAfterLast('.', "").lowercase())
                if (console == null) { ignored++; continue }
                copyOne(id, name, size, console)
                done++; onProgress(done)
            }
            if (depth < MAX_DEPTH) dirs.forEach { walk(it, depth + 1) }
        }

        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return ImportResult(imported, skipped, failed, ignored)
    }

    fun delete(game: Game): Boolean = game.file.delete()
}
