package com.allinone.emulator.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

data class Game(val file: File, val console: Console) {
    val title: String get() = file.nameWithoutExtension
}

object RomLibrary {

    /** Folder core arcade lama (FBNeo dan FB Alpha 2012 sudah dihapus): ROM-nya dipindah ke folder MAME 2003-Plus. */
    private fun migrateOldArcade(ctx: Context) {
        val dest = Paths.roms(ctx, Console.ARCADE_MAME)
        for (old in listOf("arcade_fbneo", "arcade_fba2012")) {
            val dir = File(Paths.roms(ctx, Console.ARCADE_MAME).parentFile, old)
            dir.listFiles().orEmpty().filter { it.isFile }.forEach { f ->
                val t = File(dest, f.name)
                if (!t.exists()) f.renameTo(t) else f.delete()
            }
            dir.delete()
        }
    }

    fun list(ctx: Context): List<Game> {
        migrateOldArcade(ctx)
        return Console.values().flatMap { c ->
            Paths.roms(ctx, c).listFiles().orEmpty().filter { it.isFile }.map { Game(it, c) }
        }.sortedBy { it.title.lowercase() }
    }

    /** Menyalin file ROM pilihan pengguna ke folder app. Bekerja sama di Android 5 sampai terbaru. */
    fun import(ctx: Context, uri: Uri): Boolean {
        val name = displayName(ctx, uri) ?: return false
        val ext = name.substringAfterLast('.', "").lowercase()
        val console = Console.fromExtension(ext) ?: return false
        val dest = File(Paths.roms(ctx, console), File(name).name)
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { out -> input.copyTo(out) }
            } != null
        } catch (e: Exception) {
            dest.delete()
            false
        }
    }

    fun delete(game: Game): Boolean = game.file.delete()

    private fun displayName(ctx: Context, uri: Uri): String? =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
}
