package com.allinone.emulator.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.RomLibrary
import com.allinone.emulator.data.Settings
import java.io.File

class LibraryActivity : AppCompatActivity() {

    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var games: List<Game> = emptyList()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importAll(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "Library game"; textSize = 20f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply {
            text = "Impor ROM"
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        })
        bar.addView(Button(this).apply {
            text = "Atur"
            setOnClickListener { Menus.settings(this@LibraryActivity, Settings(this@LibraryActivity)) {} }
        })

        list = ListView(this)
        empty = TextView(this).apply {
            text = "Belum ada game.\nTekan \"Impor ROM\" lalu pilih file ROM milik Anda\n(.gba .sfc .smc .md .gen .zip)."
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val body = FrameLayout(this)
        body.addView(list)
        body.addView(empty, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ -> launch(games[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ -> showItemMenu(games[pos]); true }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        games = RomLibrary.list(this)
        empty.visibility = if (games.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : ArrayAdapter<Game>(
            this, android.R.layout.simple_list_item_2, android.R.id.text1, games
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val g = getItem(position)!!
                v.findViewById<TextView>(android.R.id.text1).text = g.title
                v.findViewById<TextView>(android.R.id.text2).text = g.console.label
                return v
            }
        }
    }

    private fun launch(g: Game) {
        if (!File(applicationInfo.nativeLibraryDir, g.console.core).exists()) {
            Toast.makeText(
                this, "Core ${g.console.label} belum disertakan. Jalankan scripts/fetch_cores.sh lalu build ulang.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        startActivity(
            Intent(this, EmulatorActivity::class.java)
                .putExtra(EmulatorActivity.EXTRA_ROM, g.file.absolutePath)
                .putExtra(EmulatorActivity.EXTRA_CONSOLE, g.console.name)
        )
    }

    private fun showItemMenu(g: Game) {
        val items = mutableListOf("Hapus dari library")
        val others = RomLibrary.otherArcadeCores(g)
        for (c in others) items += "Jalankan dengan core ${c.label}"
        AlertDialog.Builder(this).setTitle(g.title).setItems(items.toTypedArray()) { _, i ->
            if (i == 0) RomLibrary.delete(g) else RomLibrary.switchArcadeCore(this, g, others[i - 1])
            refresh()
        }.show()
    }

    private fun importAll(uris: List<Uri>) {
        Toast.makeText(this, "Mengimpor ${uris.size} file…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = uris.count { RomLibrary.import(this, it) }
            runOnUiThread {
                Toast.makeText(this, "$ok dari ${uris.size} file berhasil diimpor", Toast.LENGTH_LONG).show()
                refresh()
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
