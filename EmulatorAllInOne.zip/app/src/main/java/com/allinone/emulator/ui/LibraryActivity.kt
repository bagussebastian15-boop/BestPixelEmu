package com.allinone.emulator.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.RomLibrary
import com.allinone.emulator.data.Settings
import java.io.File

class LibraryActivity : AppCompatActivity() {

    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var games: List<Game> = emptyList()

    private var importing = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) importFolder(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "Library game (tekan lama untuk hapus)"; textSize = 18f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply {
            text = "Impor folder"
            setOnClickListener { if (!importing) picker.launch(null) }
        })
        bar.addView(Button(this).apply {
            text = "Game online"
            setOnClickListener { startActivity(Intent(this@LibraryActivity, WebActivity::class.java)) }
        })
        bar.addView(Button(this).apply {
            text = "Atur"
            setOnClickListener { Menus.settings(this@LibraryActivity, Settings(this@LibraryActivity)) {} }
        })

        list = ListView(this)
        empty = TextView(this).apply {
            text = "Belum ada game.\nTekan \"Impor folder\" lalu pilih folder berisi ROM milik Anda\n(.gba .sfc .smc .md .gen .zip .7z .rar). Subfolder ikut dipindai."
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val body = FrameLayout(this)
        body.addView(list)
        body.addView(empty, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        // Layar penuh sampai area kamera: beri jarak aman supaya judul/tombol tidak tertutup poni atau bilah sistem
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ -> launch(games[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ -> showItemMenu(games[pos]); true }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        // Periksa isi zip di latar belakang: ROM GBA/SNES/Genesis di dalam zip dipindah ke konsolnya
        Thread {
            if (RomLibrary.fixZips(this) > 0) runOnUiThread { if (!isDestroyed) refresh() }
        }.start()
    }

    private fun refresh() {
        games = RomLibrary.list(this)
        empty.visibility = if (games.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : ArrayAdapter<Game>(
            this, android.R.layout.simple_list_item_2, android.R.id.text1, games
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val g = getItem(position)!!
                v.findViewById<TextView>(android.R.id.text1).text = g.title
                v.findViewById<TextView>(android.R.id.text2).text = g.console.label
                return v
            }
        }
    }

    private fun launch(g: Game, console: Console = g.console) {
        val g = if (console == g.console) g else Game(g.file, console)
        if (!File(applicationInfo.nativeLibraryDir, g.console.core).exists()) {
            Toast.makeText(
                this, "Core ${g.console.label} belum disertakan. Jalankan scripts/fetch_cores.sh lalu build ulang.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        startActivity(
            Intent(this, EmulatorActivity::class.java)
                .putExtra(EmulatorActivity.EXTRA_ROM, g.file.absolutePath)
                .putExtra(EmulatorActivity.EXTRA_CONSOLE, g.console.name)
        )
    }

    private fun showItemMenu(g: Game) {
        val delete = { confirmDelete(g) }
        if (g.console.isArcade) {
            // Game arcade: pilih core. Ketuk biasa tetap memakai MAME 2003-Plus.
            val items = arrayOf("FBNeo", "MAME 2003-Plus", "Hapus file game")
            AlertDialog.Builder(this).setTitle(g.title).setItems(items) { _, i ->
                when (i) {
                    0 -> launch(g, Console.ARCADE_FBNEO)
                    1 -> launch(g, Console.ARCADE_MAME)
                    else -> delete()
                }
            }.show()
        } else {
            AlertDialog.Builder(this).setTitle(g.title).setItems(arrayOf("Hapus file game")) { _, _ -> delete() }.show()
        }
    }

    private fun confirmDelete(g: Game) {
        val done = { ok: Boolean ->
            Toast.makeText(this, if (ok) "${g.title} dihapus" else "Gagal menghapus ${g.title}", Toast.LENGTH_SHORT).show()
            refresh()
        }
        AlertDialog.Builder(this)
            .setTitle("Hapus ${g.title}?")
            .setMessage("File game akan dihapus permanen dari penyimpanan aplikasi.")
            .setPositiveButton("Hapus file saja") { _, _ -> done(RomLibrary.delete(g)) }
            .setNeutralButton("Hapus + save & state") { _, _ -> done(RomLibrary.deleteWithData(this, g)) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun importFolder(tree: Uri) {
        importing = true
        Toast.makeText(this, "Memindai dan mengimpor folder…", Toast.LENGTH_SHORT).show()
        Thread {
            val r = RomLibrary.importFolder(this, tree)
            runOnUiThread {
                importing = false
                val msg = if (r.imported + r.skipped + r.failed == 0)
                    "Tidak ada file ROM yang dikenali di folder itu (.gba .sfc .smc .md .gen .zip .7z .rar)"
                else buildString {
                    append("${r.imported} file diimpor")
                    if (r.skipped > 0) append(", ${r.skipped} sudah ada")
                    if (r.failed > 0) append(", ${r.failed} gagal")
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                refresh()
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
