package com.allinone.emulator.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.ArcadeTuning
import com.allinone.emulator.data.BiosInstaller
import com.allinone.emulator.data.RomLibrary
import com.allinone.emulator.data.Settings
import java.io.File

class LibraryActivity : AppCompatActivity() {

    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var games: List<Game> = emptyList()

    private var importing = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            // Simpan izin baca+tulis folder ini supaya berkas asli bisa ikut dihapus nanti
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            importFolder(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "Library game (tekan lama untuk hapus)"; textSize = 18f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply {
            text = "Impor folder"
            setOnClickListener { if (!importing) picker.launch(null) }
        })
        bar.addView(Button(this).apply {
            text = "Game online"
            setOnClickListener { startActivity(Intent(this@LibraryActivity, WebActivity::class.java)) }
        })
        bar.addView(Button(this).apply {
            text = "Atur"
            setOnClickListener { Menus.settings(this@LibraryActivity, Settings(this@LibraryActivity)) {} }
        })

        list = ListView(this)
        empty = TextView(this).apply {
            text = "Belum ada game.\nTekan \"Impor folder\" lalu pilih folder berisi ROM milik Anda\n(.gba .sfc .smc .md .gen .zip .7z .rar). Subfolder ikut dipindai."
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val body = FrameLayout(this)
        body.addView(list)
        body.addView(empty, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        // Layar penuh sampai area kamera: beri jarak aman supaya judul/tombol tidak tertutup poni atau bilah sistem
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ -> launch(games[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ -> showItemMenu(games[pos]); true }
        showLastCrashIfAny()
    }

    /**
     * Bila game tadi membuat aplikasi tertutup mendadak (core native crash / core memanggil exit()), Android 11+ menyimpan
     * penyebabnya. Tampilkan alasan + potongan jejak crash supaya penyebabnya bisa diketahui, dan simpan ke crash_report.txt.
     */
    private fun showLastCrashIfAny() {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            val prefs = getSharedPreferences("crash", MODE_PRIVATE)
            val seen = prefs.getLong("seen", 0L)
            val info = am.getHistoricalProcessExitReasons(packageName, 0, 8).firstOrNull { i ->
                i.timestamp > seen && i.reason in setOf(
                    android.app.ApplicationExitInfo.REASON_CRASH_NATIVE, android.app.ApplicationExitInfo.REASON_CRASH,
                    android.app.ApplicationExitInfo.REASON_EXIT_SELF, android.app.ApplicationExitInfo.REASON_SIGNALED,
                    android.app.ApplicationExitInfo.REASON_ANR, android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE
                )
            } ?: return
            prefs.edit().putLong("seen", info.timestamp).apply()
            if (System.currentTimeMillis() - info.timestamp > 30 * 60 * 1000L) return   // hanya yang baru terjadi

            val reason = when (info.reason) {
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "Crash native (core emulator error fatal)"
                android.app.ApplicationExitInfo.REASON_CRASH -> "Crash Java/Kotlin"
                android.app.ApplicationExitInfo.REASON_EXIT_SELF -> "Core/aplikasi memanggil exit() (keluar sendiri)"
                android.app.ApplicationExitInfo.REASON_SIGNALED -> "Dihentikan sinyal sistem"
                android.app.ApplicationExitInfo.REASON_ANR -> "Aplikasi tidak merespons (ANR)"
                else -> "Gagal inisialisasi"
            }
            val sb = StringBuilder()
            sb.append("Penyebab: ").append(reason).append('\n')
            sb.append("Status/sinyal: ").append(info.status).append('\n')
            info.description?.let { sb.append("Keterangan: ").append(it).append('\n') }
            val last = getSharedPreferences("crash", MODE_PRIVATE).getString("lastGame", null)
            if (last != null) sb.append("Game terakhir: ").append(last).append('\n')

            // Jejak crash native (tombstone): ambil teks yang terbaca saja (nama pustaka, pesan abort, frame)
            try {
                info.traceInputStream?.use { st ->
                    val bytes = st.readBytes()
                    val runs = Regex("[ -~]{6,}").findAll(String(bytes, Charsets.ISO_8859_1)).map { it.value }.toList()
                    val keep = runs.filter { r ->
                        r.contains("libretro", true) || r.contains("mame", true) || r.contains("abort", true) ||
                        r.contains("SIG", false) || r.contains("fault", true) || r.contains("assert", true) ||
                        r.contains("libc.so") || r.contains("libretrodroid", true)
                    }.distinct().take(40)
                    if (keep.isNotEmpty()) sb.append("\nJejak crash:\n").append(keep.joinToString("\n"))
                }
            } catch (_: Exception) {}

            try { java.io.File(getExternalFilesDir(null) ?: filesDir, "crash_report.txt").writeText(sb.toString()) } catch (_: Exception) {}

            val tv = TextView(this).apply {
                text = sb.toString() + "\n\nLaporan juga disimpan di crash_report.txt (folder data aplikasi). Kirim isi ini bila minta bantuan."
                textSize = 12f
                setTextIsSelectable(true)
                setPadding(dp(20), dp(12), dp(20), dp(12))
            }
            val sv = android.widget.ScrollView(this).apply { addView(tv) }
            AlertDialog.Builder(this)
                .setTitle("Game tadi menutup aplikasi")
                .setView(sv)
                .setPositiveButton("OK", null)
                .show()
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        refresh()
        // Periksa isi zip di latar belakang: ROM GBA/SNES/Genesis di dalam zip dipindah ke konsolnya
        Thread {
            BiosInstaller.install(this)   // salin BIOS MAME bawaan ke folder arcade
            if (RomLibrary.fixZips(this) > 0) runOnUiThread { if (!isDestroyed) refresh() }
        }.start()
    }

    private fun refresh() {
        games = RomLibrary.list(this)
        empty.visibility = if (games.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : ArrayAdapter<Game>(
            this, android.R.layout.simple_list_item_2, android.R.id.text1, games
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val g = getItem(position)!!
                v.findViewById<TextView>(android.R.id.text1).text = g.title
                v.findViewById<TextView>(android.R.id.text2).text = g.console.label
                return v
            }
        }
    }

    private fun launch(g: Game, console: Console = g.console) {
        val g = if (console == g.console) g else Game(g.file, console)
        if (!File(applicationInfo.nativeLibraryDir, g.console.core).exists()) {
            // Tampilkan diagnosis lengkap: file core yang dicari, core yang benar-benar ada di APK, dan ABI perangkat
            val have = File(applicationInfo.nativeLibraryDir).list().orEmpty()
                .filter { it.endsWith("_libretro_android.so") }.sorted()
            AlertDialog.Builder(this)
                .setTitle("Core belum disertakan di APK")
                .setMessage(
                    "Core ${g.console.label} tidak ditemukan.\n\n" +
                    "File yang dicari:\n${g.console.core}\n\n" +
                    "Core yang ada di APK ini:\n" + (if (have.isEmpty()) "(tidak ada)" else have.joinToString("\n")) + "\n\n" +
                    "ABI perangkat: ${android.os.Build.SUPPORTED_ABIS.joinToString()}\n\n" +
                    "Perbaikan: pastikan langkah \"Unduh core libretro\" di workflow menjalankan scripts/fetch_cores.sh " +
                    "(core ${g.console.core.removePrefix("lib").removeSuffix("_libretro_android.so")} harus terunduh untuk ABI di atas), " +
                    "lalu build ulang dan pasang APK baru."
                )
                .setPositiveButton("OK", null)
                .show()
            return
        }
        getSharedPreferences("crash", MODE_PRIVATE).edit()
            .putString("lastGame", "${g.file.name} (${g.console.label})").apply()
        startActivity(
            Intent(this, EmulatorActivity::class.java)
                .putExtra(EmulatorActivity.EXTRA_ROM, g.file.absolutePath)
                .putExtra(EmulatorActivity.EXTRA_CONSOLE, g.console.name)
        )
    }

    private fun showItemMenu(g: Game) {
        val delete = { confirmDelete(g) }
        if (g.console.isArcade) {
            // Game arcade: pilih core. Ketuk biasa tetap memakai MAME 2010.
            val cores = ArcadeTuning.CORES
            val items = (cores.map { it.label } + "Hapus file game").toTypedArray()
            AlertDialog.Builder(this).setTitle(g.title).setItems(items) { _, i ->
                if (i < cores.size) launch(g, cores[i]) else delete()
            }.show()
        } else {
            AlertDialog.Builder(this).setTitle(g.title).setItems(arrayOf("Hapus file game")) { _, _ -> delete() }.show()
        }
    }

    private fun confirmDelete(g: Game) {
        val done = { ok: Boolean ->
            Toast.makeText(this, if (ok) "${g.title} dihapus" else "Gagal menghapus ${g.title}", Toast.LENGTH_SHORT).show()
            refresh()
        }
        AlertDialog.Builder(this)
            .setTitle("Hapus ${g.title}?")
            .setMessage("File game dihapus permanen dari library DAN dari file manager Android (berkas asli di folder yang tadi diimpor ikut terhapus). \"Hapus + save & state\" juga menghapus save, state, dan cheat game ini.")
            .setPositiveButton("Hapus file saja") { _, _ -> done(RomLibrary.delete(this, g)) }
            .setNeutralButton("Hapus + save & state") { _, _ -> done(RomLibrary.deleteWithData(this, g)) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun importFolder(tree: Uri) {
        importing = true
        Toast.makeText(this, "Memindai dan mengimpor folder…", Toast.LENGTH_SHORT).show()
        Thread {
            val r = RomLibrary.importFolder(this, tree)
            runOnUiThread {
                importing = false
                val msg = if (r.imported + r.skipped + r.failed == 0)
                    "Tidak ada file ROM yang dikenali di folder itu (.gba .sfc .smc .md .gen .zip .7z .rar)"
                else buildString {
                    append("${r.imported} file diimpor")
                    if (r.skipped > 0) append(", ${r.skipped} sudah ada")
                    if (r.failed > 0) append(", ${r.failed} gagal")
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                refresh()
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
