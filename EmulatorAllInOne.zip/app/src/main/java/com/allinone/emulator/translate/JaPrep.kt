package com.allinone.emulator.translate

import java.io.File

/**
 * Perapian teks Jepang sebelum diterjemahkan. Penerjemah paling sering "ngawur" karena (1) OCR menyisipkan spasi
 * di antara kana, (2) tanda kurung dialog 「」 membingungkan penerjemah offline, dan (3) nama tokoh dianggap kata
 * biasa (mis. ジャイアン -> "raksasa"). Nama tokoh diganti dulu ke tulisan Latin supaya tidak ikut diterjemahkan.
 *
 * Kamus pribadi: file glosarium_ja.txt di folder data aplikasi, satu aturan per baris  jepang=padanan  (# = komentar).
 */
object JaPrep {

    private val BUILTIN = listOf(
        // Doraemon
        "ドラえもん" to "Doraemon", "ドラえも" to "Doraemon", "ドラミちゃん" to "Dorami", "ドラミ" to "Dorami",
        "のび太" to "Nobita", "ノビタ" to "Nobita", "のびた" to "Nobita",
        "しずかちゃん" to "Shizuka", "静香" to "Shizuka",
        "ジャイアン" to "Giant", "ジャイ子" to "Jaiko",
        "スネ夫" to "Suneo", "スネオ" to "Suneo", "骨川" to "Honekawa",
        // Crayon Shinchan
        "しんのすけ" to "Shinnosuke", "しんちゃん" to "Shinchan", "シンちゃん" to "Shinchan",
        "みさえ" to "Misae", "ひろし" to "Hiroshi", "ひまわり" to "Himawari",
        "かすかべ" to "Kasukabe", "春日部" to "Kasukabe", "マサオ" to "Masao", "ネネ" to "Nene",
        "ボーちゃん" to "Bo-chan", "風間" to "Kazama",
        // Tales of Phantasia (nama tokoh yang bila diterjemahkan jadi kata biasa, mis. ミント = "mint")
        "クレス" to "Cless", "ミント" to "Mint", "チェスター" to "Chester", "アーチェ" to "Arche",
        "クラース" to "Klarth", "ダオス" to "Dhaos", "ミゲール" to "Miguel", "モリスン" to "Morrison",
        "トリニクス" to "Trinicus",
        // Istilah Doraemon yang sering salah diterjemahkan mesin
        "タケコプター" to "Baling-Baling Bambu", "どこでもドア" to "Pintu Ke Mana Saja",
        "タイムマシン" to "Mesin Waktu", "ひみつどうぐ" to "alat rahasia", "ひみつ道具" to "alat rahasia",
        "ママ" to "Mama", "パパ" to "Papa"
    )

    /**
     * Memori terjemahan PRIBADI (opsional): file memori_ja.txt di folder data aplikasi, satu baris  jepang=indonesia.
     * Kosong secara bawaan; hanya untuk koreksi kalimat tertentu oleh pengguna, bukan bagian dari pembacaan umum.
     */
    private val MEMORY: List<Pair<String, String>> = emptyList()

    private const val CJK = "\\u3000-\\u303F\\u3040-\\u30FF\\u3400-\\u9FFF\\uFF00-\\uFFEF"
    private val gap = Regex("(?<=[$CJK])[ \\t]+(?=[$CJK])")

    private var userStamp = -2L
    private var user: List<Pair<String, String>> = emptyList()

    /** Aturan pribadi dari glosarium_ja.txt (kosong bila file tidak ada). */
    fun userRules(f: File?): List<Pair<String, String>> {
        var u = user
        if (f != null && f.exists()) {
            if (f.lastModified() != userStamp) {
                userStamp = f.lastModified()
                u = try {
                    f.readLines().map { it.trim() }
                        .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
                        .map { it.substringBefore('=').trim() to it.substringAfter('=').trim() }
                        .filter { it.first.isNotEmpty() }
                } catch (_: Exception) { emptyList() }
                user = u
            }
        } else u = emptyList()
        return u
    }

    private fun rules(f: File?): List<Pair<String, String>> {
        val u = userRules(f)
        // aturan pribadi didahulukan; kunci terpanjang dulu agar "しずかちゃん" tidak terpotong oleh kunci yang lebih pendek
        return (u + BUILTIN).sortedByDescending { it.first.length }
    }

    private var memStamp = -2L
    private var memUser: List<Pair<String, String>> = emptyList()

    private fun memoryRules(glossary: File?): List<Pair<String, String>> {
        val f = glossary?.parentFile?.let { File(it, "memori_ja.txt") }
        if (f != null && f.exists()) {
            if (f.lastModified() != memStamp) {
                memStamp = f.lastModified()
                memUser = try {
                    f.readLines().map { it.trim() }
                        .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
                        .map { keyOf(it.substringBefore('=')) to it.substringAfter('=').trim() }
                        .filter { it.first.isNotEmpty() && it.second.isNotEmpty() }
                } catch (_: Exception) { emptyList() }
            }
        } else memUser = emptyList()
        return memUser + MEMORY
    }

    /** Hanya huruf (kana/kanji): tanda baca, spasi, dan sisa huruf Latin/angka hasil OCR yang salah dibuang. */
    private fun keyOf(s: String): String =
        s.filter { it.code > 0x2E80 && it.isLetter() }

    private fun distance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /**
     * Terjemahan siap pakai untuk kalimat yang ada di memori (toleran salah baca OCR kecil), atau null.
     * Kalimat pendek (< 5 huruf) harus persis sama; yang lebih panjang boleh beda sekitar 1 dari 5 huruf.
     */
    fun memory(text: String, glossary: File?): String? {
        val k = keyOf(text)
        if (k.length < 3) return null
        var best: String? = null
        var bestD = Int.MAX_VALUE
        for ((key, value) in memoryRules(glossary)) {
            if (kotlin.math.abs(key.length - k.length) > 2) continue
            val allowed = if (key.length < 5) 0 else maxOf(1, key.length / 5)
            val d = distance(k, key)
            if (d <= allowed && d < bestD) { bestD = d; best = value }
        }
        return best
    }

    fun normalize(text: String, userFile: File?): String {
        var s = text
            .replace('「', '“').replace('」', '”').replace('『', '“').replace('』', '”')
            .replace("\r", "")
        s = gap.replace(s, "")
        // Titik tengah berulang (・・・) = elipsis; penerjemah offline menghasilkan kalimat ngawur bila membacanya sebagai simbol acak.
        s = s.replace(Regex("[・･·]{2,}|\\.{3,}|。{2,}"), "…")
        // baris yang dipotong di tengah kalimat digabung (Jepang tidak memakai spasi antar kata)
        s = s.replace(Regex("(?<=[$CJK])\\n+(?=[$CJK])"), "")
        for ((k, v) in rules(userFile)) if (s.contains(k)) s = s.replace(k, v)
        return s.trim()
    }
}
