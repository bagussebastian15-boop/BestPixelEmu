package com.allinone.emulator.translate

import java.io.File

/**
 * Perapian teks Jepang sebelum diterjemahkan. Penerjemah paling sering "ngawur" karena (1) OCR menyisipkan spasi
 * di antara kana, (2) tanda kurung dialog 「」 membingungkan penerjemah offline, dan (3) nama tokoh dianggap kata
 * biasa (mis. ジャイアン -> "raksasa"). Nama tokoh diganti dulu ke tulisan Latin supaya tidak ikut diterjemahkan.
 *
 * Kamus pribadi: file glosarium_ja.txt di folder data aplikasi, satu aturan per baris  jepang=padanan  (# = komentar).
 */
object JaPrep {

    private val BUILTIN = listOf(
        // Doraemon
        "ドラえもん" to "Doraemon", "ドラえも" to "Doraemon", "ドラミちゃん" to "Dorami", "ドラミ" to "Dorami",
        "のび太" to "Nobita", "ノビタ" to "Nobita", "のびた" to "Nobita",
        "しずかちゃん" to "Shizuka", "静香" to "Shizuka",
        "ジャイアン" to "Giant", "ジャイ子" to "Jaiko",
        "スネ夫" to "Suneo", "スネオ" to "Suneo", "骨川" to "Honekawa",
        // Crayon Shinchan
        "しんのすけ" to "Shinnosuke", "しんちゃん" to "Shinchan", "シンちゃん" to "Shinchan",
        "みさえ" to "Misae", "ひろし" to "Hiroshi", "ひまわり" to "Himawari",
        "かすかべ" to "Kasukabe", "春日部" to "Kasukabe", "マサオ" to "Masao", "ネネ" to "Nene",
        "ボーちゃん" to "Bo-chan", "風間" to "Kazama",
        // Tales of Phantasia (nama tokoh yang bila diterjemahkan jadi kata biasa, mis. ミント = "mint")
        "クレス" to "Cless", "ミント" to "Mint", "チェスター" to "Chester", "アーチェ" to "Arche",
        "クラース" to "Klarth", "ダオス" to "Dhaos", "ミゲール" to "Miguel", "モリスン" to "Morrison",
        "トリニクス" to "Trinicus",
        // Istilah Doraemon yang sering salah diterjemahkan mesin
        "タケコプター" to "Baling-Baling Bambu", "どこでもドア" to "Pintu Ke Mana Saja",
        "タイムマシン" to "Mesin Waktu", "ひみつどうぐ" to "alat rahasia", "ひみつ道具" to "alat rahasia",
        "ママ" to "Mama", "パパ" to "Papa",
        // Nama planet/tempat yang sering diterjemahkan jadi "Ziasta"
        "ジアスター" to "Jiastar"
    )

    /**
     * Kana -> kanji untuk kata umum di dialog game. Penerjemah mesin sangat sering ngawur pada kalimat yang seluruhnya
     * hiragana (mis. "よさそうだな" -> "Nama baik"), tetapi akurat bila kata intinya berkanji. Hanya kata >= 3 kana
     * (atau yang jelas tidak ambigu) supaya tidak mengganti potongan kata lain.
     */
    private val KANJI = listOf(
        "はてしなく" to "果てしなく", "ほしぞら" to "星空", "ひろがる" to "広がる", "わくせい" to "惑星",
        "すみきった" to "澄み切った", "あおぞら" to "青空", "あお空" to "青空", "なぞの" to "謎の",
        "ゆくて" to "行く手", "はばむ" to "阻む", "ふたりぐみ" to "二人組", "人ぐみ" to "人組",
        "まぶしい" to "眩しい", "よさそう" to "良さそう", "ゆうしゃ" to "勇者", "まおう" to "魔王",
        "まほう" to "魔法", "まじゅつ" to "魔術", "おうさま" to "王様", "おひめさま" to "お姫様",
        "おしろ" to "お城", "ほんとう" to "本当", "だいじょうぶ" to "大丈夫", "たいへん" to "大変",
        "ともだち" to "友達", "なかま" to "仲間", "せかい" to "世界", "うちゅう" to "宇宙",
        "ちきゅう" to "地球", "たいよう" to "太陽", "ひみつ" to "秘密", "ぼうけん" to "冒険",
        "たたかう" to "戦う", "たおす" to "倒す", "まもる" to "守る", "たからもの" to "宝物",
        "たからばこ" to "宝箱", "けいけんち" to "経験値", "たびだち" to "旅立ち", "わからない" to "分からない",
        "わかった" to "分かった", "きをつけて" to "気を付けて", "きをつけろ" to "気を付けろ",
        "おねがい" to "お願い", "あぶない" to "危ない", "にげろ" to "逃げろ", "にげる" to "逃げる",
        "みつけた" to "見つけた", "いこう" to "行こう", "いくぞ" to "行くぞ", "ゆるさない" to "許さない",
        "しんじて" to "信じて", "しんじる" to "信じる", "たいせつ" to "大切", "にんげん" to "人間",
        "ようせい" to "妖精", "かがやく" to "輝く", "ありがとう" to "ありがとう"
    )

    private val DIGIT = "〇一二三四五六七八九"
    private const val COUNTERS = "つ人個回匹本枚日年歳番階度体名組"

    /** 1..99 -> angka kanji (di luar itu dibiarkan). */
    private fun kanjiNum(n: Int): String? = when {
        n in 1..9 -> DIGIT[n].toString()
        n == 10 -> "十"
        n in 11..19 -> "十" + DIGIT[n - 10]
        n in 20..99 -> DIGIT[n / 10].toString() + "十" + (if (n % 10 == 0) "" else DIGIT[n % 10].toString())
        else -> null
    }

    private fun isKata(c: Char) = c in '\u30A0'..'\u30FF'
    private fun isHira(c: Char) = c in '\u3040'..'\u309F'
    private fun isKanji(c: Char) = c in '\u4E00'..'\u9FFF'

    /** Kanji yang bentuknya sama dengan katakana: "ジアスタ一" -> "ジアスター", "ス力ート" -> "スカート". */
    private val KATA_LOOK = mapOf('一' to 'ー', '力' to 'カ', '夕' to 'タ', '口' to 'ロ', '工' to 'エ', '卜' to 'ト', '二' to 'ニ', '八' to 'ハ')
    /** Hiragana/katakana berbentuk sama; salah satunya terbaca keliru bila dikelilingi aksara lain. */
    private val KANA_PAIR = mapOf('へ' to 'ヘ', 'べ' to 'ベ', 'ぺ' to 'ペ')

    /**
     * Koreksi salah baca OCR yang khas pada font piksel Jepang. Hanya pola yang hampir pasti salah, berdasarkan
     * tetangga huruf, jadi aman dipakai untuk semua game.
     */
    fun fixOcr(text: String): String {
        val t = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKC)   // ｱｲｳ -> アイウ, １ -> 1, ！ -> !
        val sb = StringBuilder(t)
        for (i in sb.indices) {
            val c = sb[i]
            val p = if (i > 0) sb[i - 1] else ' '
            val n = if (i < sb.length - 1) sb[i + 1] else ' '
            val prevKata = isKata(p)
            val nextKata = isKata(n)
            val nextPlain = !(isKanji(n) || isHira(n) || isKata(n))
            val k = KATA_LOOK[c]
            if (k != null) {
                // 一 di tengah/akhir deretan katakana = tanda panjang ー; kanji lain hanya bila dikelilingi katakana
                if ((prevKata && nextKata) || (prevKata && nextPlain) || (c != '一' && nextKata && !(isKanji(p) || isHira(p)) && p != ' ')) sb.setCharAt(i, k)
                continue
            }
            val pair = KANA_PAIR[c]
            if (pair != null && isKata(p) && isKata(n)) { sb.setCharAt(i, pair); continue }
            val back = KANA_PAIR.entries.firstOrNull { it.value == c }?.key
            if (back != null && isHira(p) && isHira(n)) sb.setCharAt(i, back)
        }
        var s = sb.toString()
        // ツ -> ッ pada seruan pendek: "ワツ" "シツ" "ヒツ" di awal kalimat sebelum tanda baca/hiragana
        s = s.replace(Regex("(?<![ァ-ヶー])([ワヒシアウエオハフ])ツ(?![ァ-ヶー])")) { it.groupValues[1] + "ッ" }
        // seruan katakana berakhiran ッ + hiragana: beri koma supaya tidak dibaca satu kata ("ワッまぶしい" -> "Wamapushi")
        s = s.replace(Regex("(?<=[ァ-ヶ]ッ)(?=[ぁ-ん])"), "、")
        // angka + penghitung -> angka kanji ("2人" -> "二人", "1つ" -> "一つ")
        s = s.replace(Regex("([0-9]{1,2})([$COUNTERS])")) { m ->
            val k = kanjiNum(m.groupValues[1].toInt())
            if (k != null) k + m.groupValues[2] else m.value
        }
        return s
    }

    /**
     * Memori terjemahan PRIBADI (opsional): file memori_ja.txt di folder data aplikasi, satu baris  jepang=indonesia.
     * Kosong secara bawaan; hanya untuk koreksi kalimat tertentu oleh pengguna, bukan bagian dari pembacaan umum.
     */
    private val MEMORY: List<Pair<String, String>> = emptyList()

    private const val CJK = "\\u3000-\\u303F\\u3040-\\u30FF\\u3400-\\u9FFF\\uFF00-\\uFFEF"
    private val gap = Regex("(?<=[$CJK])[ \\t]+(?=[$CJK])")

    private var userStamp = -2L
    private var user: List<Pair<String, String>> = emptyList()

    /** Aturan pribadi dari glosarium_ja.txt (kosong bila file tidak ada). */
    fun userRules(f: File?): List<Pair<String, String>> {
        var u = user
        if (f != null && f.exists()) {
            if (f.lastModified() != userStamp) {
                userStamp = f.lastModified()
                u = try {
                    f.readLines().map { it.trim() }
                        .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
                        .map { it.substringBefore('=').trim() to it.substringAfter('=').trim() }
                        .filter { it.first.isNotEmpty() }
                } catch (_: Exception) { emptyList() }
                user = u
            }
        } else u = emptyList()
        return u
    }

    private fun rules(f: File?): List<Pair<String, String>> {
        val u = userRules(f)
        // aturan pribadi didahulukan; kunci terpanjang dulu agar "しずかちゃん" tidak terpotong oleh kunci yang lebih pendek
        return (u + BUILTIN).sortedByDescending { it.first.length }
    }

    private var memStamp = -2L
    private var memUser: List<Pair<String, String>> = emptyList()

    private fun memoryRules(glossary: File?): List<Pair<String, String>> {
        val f = glossary?.parentFile?.let { File(it, "memori_ja.txt") }
        if (f != null && f.exists()) {
            if (f.lastModified() != memStamp) {
                memStamp = f.lastModified()
                memUser = try {
                    f.readLines().map { it.trim() }
                        .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
                        .map { keyOf(it.substringBefore('=')) to it.substringAfter('=').trim() }
                        .filter { it.first.isNotEmpty() && it.second.isNotEmpty() }
                } catch (_: Exception) { emptyList() }
            }
        } else memUser = emptyList()
        return memUser + MEMORY
    }

    /** Hanya huruf (kana/kanji): tanda baca, spasi, dan sisa huruf Latin/angka hasil OCR yang salah dibuang. */
    private fun keyOf(s: String): String =
        s.filter { it.code > 0x2E80 && it.isLetter() }

    private fun distance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /**
     * Terjemahan siap pakai untuk kalimat yang ada di memori (toleran salah baca OCR kecil), atau null.
     * Kalimat pendek (< 5 huruf) harus persis sama; yang lebih panjang boleh beda sekitar 1 dari 5 huruf.
     */
    fun memory(text: String, glossary: File?): String? {
        val k = keyOf(text)
        if (k.length < 3) return null
        var best: String? = null
        var bestD = Int.MAX_VALUE
        for ((key, value) in memoryRules(glossary)) {
            if (kotlin.math.abs(key.length - k.length) > 2) continue
            val allowed = if (key.length < 5) 0 else maxOf(1, key.length / 5)
            val d = distance(k, key)
            if (d <= allowed && d < bestD) { bestD = d; best = value }
        }
        return best
    }

    fun normalize(text: String, userFile: File?): String {
        var s = fixOcr(text)
            .replace('「', '“').replace('」', '”').replace('『', '“').replace('』', '”')
            .replace("\r", "")
        s = gap.replace(s, "")
        // Titik tengah berulang (・・・) = elipsis; penerjemah offline menghasilkan kalimat ngawur bila membacanya sebagai simbol acak.
        s = s.replace(Regex("[・･·]{2,}|\\.{3,}|。{2,}"), "…")
        // baris yang dipotong di tengah kalimat digabung (Jepang tidak memakai spasi antar kata)
        s = s.replace(Regex("(?<=[$CJK])\\n+(?=[$CJK])"), "")
        for ((k, v) in KANJI) if (s.contains(k)) s = s.replace(k, v)
        for ((k, v) in rules(userFile)) if (s.contains(k)) s = s.replace(k, v)
        return s.trim()
    }
}
