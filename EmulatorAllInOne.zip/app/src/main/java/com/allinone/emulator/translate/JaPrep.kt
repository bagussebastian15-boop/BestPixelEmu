package com.allinone.emulator.translate

import java.io.File

/**
 * Perapian teks Jepang sebelum diterjemahkan. Penerjemah paling sering "ngawur" karena (1) OCR menyisipkan spasi
 * di antara kana, (2) tanda kurung dialog 「」 membingungkan penerjemah offline, dan (3) nama tokoh dianggap kata
 * biasa (mis. ジャイアン -> "raksasa"). Nama tokoh diganti dulu ke tulisan Latin supaya tidak ikut diterjemahkan.
 *
 * Kamus pribadi: file glosarium_ja.txt di folder data aplikasi, satu aturan per baris  jepang=padanan  (# = komentar).
 */
object JaPrep {

    private val BUILTIN = listOf(
        // Doraemon
        "ドラえもん" to "Doraemon", "ドラミちゃん" to "Dorami", "ドラミ" to "Dorami",
        "のび太" to "Nobita", "ノビタ" to "Nobita", "のびた" to "Nobita",
        "しずかちゃん" to "Shizuka", "静香" to "Shizuka",
        "ジャイアン" to "Giant", "ジャイ子" to "Jaiko",
        "スネ夫" to "Suneo", "スネオ" to "Suneo", "骨川" to "Honekawa",
        // Crayon Shinchan
        "しんのすけ" to "Shinnosuke", "しんちゃん" to "Shinchan", "シンちゃん" to "Shinchan",
        "みさえ" to "Misae", "ひろし" to "Hiroshi", "ひまわり" to "Himawari",
        "かすかべ" to "Kasukabe", "春日部" to "Kasukabe", "マサオ" to "Masao", "ネネ" to "Nene",
        "ボーちゃん" to "Bo-chan", "風間" to "Kazama",
        // Tales of Phantasia (nama tokoh yang bila diterjemahkan jadi kata biasa, mis. ミント = "mint")
        "クレス" to "Cless", "ミント" to "Mint", "チェスター" to "Chester", "アーチェ" to "Arche",
        "クラース" to "Klarth", "ダオス" to "Dhaos", "ミゲール" to "Miguel", "モリスン" to "Morrison",
        "トリニクス" to "Trinicus"
    )

    private const val CJK = "\\u3000-\\u303F\\u3040-\\u30FF\\u3400-\\u9FFF\\uFF00-\\uFFEF"
    private val gap = Regex("(?<=[$CJK])[ \\t]+(?=[$CJK])")

    private var userStamp = -2L
    private var user: List<Pair<String, String>> = emptyList()

    /** Aturan pribadi dari glosarium_ja.txt (kosong bila file tidak ada). */
    fun userRules(f: File?): List<Pair<String, String>> {
        var u = user
        if (f != null && f.exists()) {
            if (f.lastModified() != userStamp) {
                userStamp = f.lastModified()
                u = try {
                    f.readLines().map { it.trim() }
                        .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
                        .map { it.substringBefore('=').trim() to it.substringAfter('=').trim() }
                        .filter { it.first.isNotEmpty() }
                } catch (_: Exception) { emptyList() }
                user = u
            }
        } else u = emptyList()
        return u
    }

    private fun rules(f: File?): List<Pair<String, String>> {
        val u = userRules(f)
        // aturan pribadi didahulukan; kunci terpanjang dulu agar "しずかちゃん" tidak terpotong oleh kunci yang lebih pendek
        return (u + BUILTIN).sortedByDescending { it.first.length }
    }

    fun normalize(text: String, userFile: File?): String {
        var s = text
            .replace('「', '“').replace('」', '”').replace('『', '“').replace('』', '”')
            .replace("\r", "")
        s = gap.replace(s, "")
        // baris yang dipotong di tengah kalimat digabung (Jepang tidak memakai spasi antar kata)
        s = s.replace(Regex("(?<=[$CJK])\\n+(?=[$CJK])"), "")
        for ((k, v) in rules(userFile)) if (s.contains(k)) s = s.replace(k, v)
        return s.trim()
    }
}
