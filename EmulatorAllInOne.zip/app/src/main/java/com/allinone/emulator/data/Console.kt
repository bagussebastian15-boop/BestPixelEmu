package com.allinone.emulator.data

/** Sistem yang didukung. `core` = nama file library core di nativeLibraryDir. */
enum class Console(val label: String, val core: String, val extensions: Set<String>) {
    GBA("Game Boy Advance", "libmgba_libretro_android.so", setOf("gba")),
    SNES("Super Nintendo (SNES)", "libsnes9x_libretro_android.so", setOf("sfc", "smc", "fig", "swc")),
    GENESIS("Sega Genesis / Mega Drive", "libgenesis_plus_gx_libretro_android.so", setOf("md", "gen", "smd", "bin")),
    /** Core arcade bawaan: semua file .zip arcade masuk library dengan core ini. */
    ARCADE_MAME("Arcade (MAME 2010)", "libmame2010_libretro_android.so", setOf("zip")),
    /**
     * Pilihan core kedua untuk game arcade yang sama (muncul saat tekan lama game arcade di library).
     * Tidak punya ekstensi/folder ROM sendiri: memakai file zip di folder arcade MAME, jadi set ROM-nya harus cocok dengan FBNeo.
     */
    ARCADE_FBNEO("Arcade (FBNeo)", "libfbneo_libretro_android.so", emptySet());

    val isArcade: Boolean get() = this == ARCADE_MAME || this == ARCADE_FBNEO

    companion object {
        /** .7z dan .rar ikut dianggap "arsip" yang awalnya masuk ke folder arcade, lalu isinya dibaca dan dipilah ke konsol yang tepat. */
        fun fromExtension(ext: String): Console? =
            values().firstOrNull { ext in it.extensions } ?: if (ext == "7z" || ext == "rar") ARCADE_MAME else null
    }
}
