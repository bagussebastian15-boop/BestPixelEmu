package com.allinone.emulator.data

/** Sistem yang didukung. `core` = nama file library core di nativeLibraryDir. */
enum class Console(val label: String, val core: String, val extensions: Set<String>) {
    GBA("Game Boy Advance", "libmgba_libretro_android.so", setOf("gba")),
    SNES("Super Nintendo (SNES)", "libsnes9x_libretro_android.so", setOf("sfc", "smc", "fig", "swc")),
    GENESIS("Sega Genesis / Mega Drive", "libgenesis_plus_gx_libretro_android.so", setOf("md", "gen", "smd", "bin")),
    ARCADE_FBNEO("Arcade (FBNeo)", "libfbneo_libretro_android.so", setOf("zip")),
    ARCADE_MAME("Arcade (MAME 2003-Plus)", "libmame2003_plus_libretro_android.so", emptySet()),
    /** Core arcade paling ringan, untuk HP yang berat menjalankan FBNeo. Butuh set ROM FBA 0.2.97.29. */
    ARCADE_FBA2012("Arcade (FB Alpha 2012, ringan)", "libfbalpha2012_libretro_android.so", emptySet());

    companion object {
        fun fromExtension(ext: String): Console? = values().firstOrNull { ext in it.extensions }
    }
}
