package com.allinone.emulator.data

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File

/**
 * Mencatat dari mana tiap game diimpor (URI berkas asli di folder pilihan pengguna / file manager).
 * Saat game dihapus dari library, berkas asli itu ikut dihapus lewat Storage Access Framework,
 * sehingga hilang juga di file manager Android. Butuh izin tulis ke folder yang diimpor
 * (diminta sekali saat "Impor folder"; izinnya dipertahankan).
 *
 * Catatan: arsip yang berisi BANYAK ROM tidak ditautkan (menghapus satu game tidak boleh menghapus arsip
 * yang masih dipakai game lain).
 */
object SourceLinks {

    private fun store(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "source_links.tsv")

    private fun key(f: File) = "${f.parentFile?.name}/${f.name}"

    @Synchronized
    private fun load(ctx: Context): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        try {
            store(ctx).takeIf { it.isFile }?.readLines()?.forEach { l ->
                val i = l.indexOf('\t')
                if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
            }
        } catch (_: Exception) {}
        return m
    }

    @Synchronized
    private fun save(ctx: Context, m: Map<String, String>) {
        try { store(ctx).writeText(m.entries.joinToString("\n") { "${it.key}\t${it.value}" }) } catch (_: Exception) {}
    }

    /** Tautkan file hasil impor [local] dengan berkas aslinya [source]. */
    fun link(ctx: Context, local: File, source: Uri) {
        val m = load(ctx)
        m[key(local)] = source.toString()
        save(ctx, m)
    }

    /** Hapus berkas asli (di file manager) milik [local], bila ada tautannya. Mengembalikan true bila terhapus. */
    fun deleteSource(ctx: Context, local: File): Boolean {
        val m = load(ctx)
        val uri = m.remove(key(local))?.let { Uri.parse(it) } ?: return false
        save(ctx, m)
        return try {
            DocumentsContract.deleteDocument(ctx.contentResolver, uri)
        } catch (e: Exception) {
            false   // sudah terhapus lebih dulu, izin dicabut, atau provider menolak
        }
    }

    /** Minta file manager/galeri menyegarkan daftar setelah file dihapus. */
    fun rescan(ctx: Context, vararg files: File) {
        try { MediaScannerConnection.scanFile(ctx, files.map { it.absolutePath }.toTypedArray(), null, null) } catch (_: Exception) {}
    }
}
