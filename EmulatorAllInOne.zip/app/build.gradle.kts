plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.allinone.emulator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.allinone.emulator"
        minSdk = 21            // Android 5.0
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Core libretro dimuat lewat path, jadi .so harus diekstrak ke nativeLibraryDir
    packaging { jniLibs { useLegacyPackaging = true } }
}

// Cek versi terbaru di https://jitpack.io/#Swordfish90/LibretroDroid
val libretroDroidVersion = "0.13.0"

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.github.Swordfish90:LibretroDroid:$libretroDroidVersion")
}
